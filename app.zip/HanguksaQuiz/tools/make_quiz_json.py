"""study.html 안의 데이터를 꺼내 잠금화면 문제용 파일 두 개를 만들어요.
- quiz.json : 연표 289줄(drill-data)
- order.json: 교과서 순서 퀴즈 300문제(oq-data) — 사건, 문제, 단원
빈칸표를 고친 뒤 study.html만 바꿔 넣으면, GitHub 빌드가 이 스크립트를 자동으로 돌려요."""
import json, os, re, sys
src = sys.argv[1] if len(sys.argv) > 1 else 'app/src/main/assets/study.html'
out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(src)
html = open(src, encoding='utf-8').read()


def block(name):
    m = re.search(r'<script type="application/json" id="' + name + r'">(.*?)</script>', html, re.S)
    return json.loads(m.group(1)) if m else None


drill = block('drill-data')
if not drill:
    sys.exit('study.html에서 drill-data를 찾지 못했어요')
rows = drill['rows']
out = []
for r in rows:
    o = {'n': r['n'], 'd': r['d'], 't': r['t'], 'c': r['ctx'], 'w': 1 if r.get('w') else 0}
    if r.get('ch'): o['ch'] = r['ch']   # 이 줄을 다루는 교과서 중단원
    if r.get('pg'): o['pg'] = r['pg']   # 이 줄을 다루는 교과서 쪽
    out.append(o)
json.dump(out, open(os.path.join(out_dir, 'quiz.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print(f'quiz.json: {len(out)}문제')

oq = block('oq-data')
if oq:
    json.dump(oq, open(os.path.join(out_dir, 'order.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print(f"order.json: 사건 {len(oq['events'])}개, 문제 {len(oq['questions'])}개")
else:
    print('study.html에 교과서 순서 퀴즈(oq-data)가 없어서 order.json은 만들지 않았어요')
