"""study.html 안의 연표 데이터(drill-data)를 꺼내 잠금화면 문제용 quiz.json을 만들어요.
빈칸표를 고친 뒤 study.html만 바꿔 넣으면, GitHub 빌드가 이 스크립트를 자동으로 돌려요."""
import json, re, sys
src = sys.argv[1] if len(sys.argv) > 1 else 'app/src/main/assets/study.html'
dst = sys.argv[2] if len(sys.argv) > 2 else 'app/src/main/assets/quiz.json'
html = open(src, encoding='utf-8').read()
m = re.search(r'<script type="application/json" id="drill-data">(.*?)</script>', html, re.S)
if not m:
    sys.exit('study.html에서 drill-data를 찾지 못했어요')
rows = json.loads(m.group(1))['rows']
out = [{'n': r['n'], 'd': r['d'], 't': r['t'], 'c': r['ctx'], 'w': 1 if r.get('w') else 0} for r in rows]
json.dump(out, open(dst, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print(f'quiz.json: {len(out)}문제')
