package com.js.hanguksaquiz;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * 공부 내용(study.html) 자동 업데이트.
 * GitHub 저장소의 study.html이 바뀌면, 앱을 열 때 인터넷으로 새 파일만 받아 와요.
 * 빈칸표·모의고사·퀴즈·잠금화면 문제가 모두 이 파일 하나에서 나오므로, APK를 다시 설치할 필요가 없어요.
 * (앱 기능 자체를 바꿀 때만 새 APK가 필요해요)
 */
final class ContentSync {

    interface Done { void done(int result); }

    static final int UNCHANGED = 0, UPDATED = 1, FAILED = 2, OFF = 3;

    private ContentSync() {}

    static File local(Context c) { return new File(c.getFilesDir(), "study.html"); }

    /** 받아 둔 내용이 있으면 그 파일, 없으면 앱에 들어 있는 기본 파일 */
    static boolean hasLocal(Context c) {
        prune(c);
        return local(c).exists();
    }

    /** 새 APK를 설치하면(그 안의 기본 내용이 더 새로울 수 있으니) 받아 둔 파일을 지우고 다시 받아요 */
    private static void prune(Context c) {
        SharedPreferences p = Quiz.prefs(c);
        if (p.getInt("content_apk", 0) != BuildConfig.VERSION_CODE) {
            local(c).delete();
            p.edit().putInt("content_apk", BuildConfig.VERSION_CODE).remove("content_etag").apply();
        }
    }

    static byte[] readLocal(Context c) throws Exception {
        return Files.readAllBytes(local(c).toPath());
    }

    static void check(Context c, Done cb) {
        final Context app = c.getApplicationContext();
        if (BuildConfig.CONTENT_URL.length() == 0) {
            if (cb != null) cb.done(OFF);
            return;
        }
        prune(app);
        new Thread(() -> {
            int result = FAILED;
            try {
                result = fetch(app);
            } catch (Exception ignored) {
            }
            if (result == UPDATED) Quiz.invalidate();
            final int r = result;
            if (cb != null) new Handler(Looper.getMainLooper()).post(() -> cb.done(r));
        }).start();
    }

    private static int fetch(Context c) throws Exception {
        SharedPreferences p = Quiz.prefs(c);
        File f = local(c);
        HttpURLConnection con = (HttpURLConnection) new URL(BuildConfig.CONTENT_URL).openConnection();
        con.setConnectTimeout(8000);
        con.setReadTimeout(20000);
        String etag = p.getString("content_etag", null);
        if (etag != null && f.exists()) con.setRequestProperty("If-None-Match", etag);
        int code = con.getResponseCode();
        if (code == 304) return UNCHANGED;
        if (code != 200) return FAILED;
        byte[] data;
        try (InputStream in = con.getInputStream()) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int k;
            while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
            data = out.toByteArray();
        }
        String text = new String(data, StandardCharsets.UTF_8);
        if (!text.contains("id=\"drill-data\"")) return FAILED;   // 엉뚱한 파일이면 쓰지 않아요
        String newTag = con.getHeaderField("ETag");

        byte[] current = f.exists() ? readLocal(c) : readAsset(c);
        boolean same = java.util.Arrays.equals(current, data);
        if (!same) {
            File tmp = new File(c.getFilesDir(), "study.html.part");
            try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(data); }
            if (!tmp.renameTo(f)) { tmp.delete(); return FAILED; }
        }
        if (newTag != null) p.edit().putString("content_etag", newTag).apply();
        return same ? UNCHANGED : UPDATED;
    }

    private static byte[] readAsset(Context c) throws Exception {
        try (InputStream in = c.getAssets().open("study.html")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int k;
            while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
            return out.toByteArray();
        }
    }
}
