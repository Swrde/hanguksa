package com.js.hanguksaquiz;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 로그인 상태 (이 기기 안에만, 앱 전용 저장소에 둬요).
 * 아이디 계정은 Firebase의 이메일/비밀번호 방식을 쓰되, 아이디를 받을 수 없는 주소(id@id.example.com)로 바꿔 넣어요.
 * 그래서 비밀번호 재설정 메일이 어디로도 가지 않고, 진짜 메일 주소가 필요 없어요.
 */
final class Account {
    private Account() {}

    /** 아이디를 Firebase 이메일 칸에 넣을 때 붙이는 주소 (example.com은 메일을 받지 않는 주소예요) */
    static final String ID_DOMAIN = "@id.example.com";
    private static final Object LOCK = new Object();

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("account", Context.MODE_PRIVATE);
    }

    static boolean loggedIn(Context c) { return Fb.ready() && !uid(c).isEmpty(); }

    static String uid(Context c) { return prefs(c).getString("uid", ""); }

    /** 아이디 (없으면 빈 글자) */
    static String loginId(Context c) { return prefs(c).getString("lid", ""); }

    static boolean hasGoogle(Context c) { return prefs(c).getBoolean("gg", false); }

    static boolean hasId(Context c) { return prefs(c).getBoolean("pw", false) && !loginId(c).isEmpty(); }

    static String googleName(Context c) { return prefs(c).getString("gname", ""); }

    /** 구글 메일은 가려서 보여 줘요 (ab***@gmail.com) */
    static String googleMailMasked(Context c) { return mask(prefs(c).getString("gmail", "")); }

    /** 화면에 보일 이름: 구글 이름 → 아이디 → '내 계정' */
    static String label(Context c) {
        String n = googleName(c);
        if (hasGoogle(c) && !n.isEmpty()) return n;
        String id = loginId(c);
        if (!id.isEmpty()) return id;
        return "내 계정";
    }

    static String mask(String mail) {
        int at = mail.indexOf('@');
        if (at <= 0) return "";
        String name = mail.substring(0, at);
        String keep = name.length() <= 2 ? name.substring(0, 1) : name.substring(0, 2);
        return keep + "***" + mail.substring(at);
    }

    // ───────── 아이디 ─────────

    /** 아이디 다듬기: 영어 소문자·숫자·밑줄·점, 4~20자. 맞지 않으면 null */
    static String cleanId(String raw) {
        if (raw == null) return null;
        String id = raw.trim().toLowerCase(Locale.ROOT);
        if (!id.matches("[a-z0-9][a-z0-9_.]{3,19}") || id.contains("..") || id.endsWith(".")) return null;
        return id;
    }

    static String idMail(String id) { return id + ID_DOMAIN; }

    /** Firebase 메일 칸에서 아이디만 (우리가 만든 주소가 아니면 빈 글자) */
    static String idFromMail(String mail) {
        if (mail == null || !mail.toLowerCase(Locale.ROOT).endsWith(ID_DOMAIN)) return "";
        return mail.substring(0, mail.length() - ID_DOMAIN.length()).toLowerCase(Locale.ROOT);
    }

    static void signUpId(Context c, String id, String pw) throws Fb.Err {
        Map<String, Object> r = Fb.auth("accounts:signUp", Fb.body("email", idMail(id), "password", pw, "returnSecureToken", true));
        save(c, r, true);
        prefs(c).edit().putString("lid", id).putBoolean("pw", true).apply();
        refreshProviders(c);
    }

    static void signInId(Context c, String id, String pw) throws Fb.Err {
        Map<String, Object> r = Fb.auth("accounts:signInWithPassword", Fb.body("email", idMail(id), "password", pw, "returnSecureToken", true));
        save(c, r, true);
        prefs(c).edit().putString("lid", id).putBoolean("pw", true).apply();
        refreshProviders(c);
    }

    /** 구글로 로그인 (구글이 준 ID 토큰을 Firebase 계정으로 바꿔요) */
    static void signInGoogle(Context c, String googleIdToken) throws Fb.Err {
        Map<String, Object> r = Fb.auth("accounts:signInWithIdp", idpBody(googleIdToken, null));
        save(c, r, true);
        refreshProviders(c);
    }

    /** 로그인한 계정에 구글을 더 붙여요. 그러면 구글로도, 아이디로도 같은 계정에 들어와요 */
    static void linkGoogle(Context c, String googleIdToken) throws Fb.Err {
        Map<String, Object> r = Fb.auth("accounts:signInWithIdp", idpBody(googleIdToken, idToken(c)));
        if (!Json.s(r, "localId").isEmpty() && !Json.s(r, "localId").equals(uid(c))) {
            throw new Fb.Err("FEDERATED_USER_ID_ALREADY_LINKED", 400, "");
        }
        save(c, r, false);
        refreshProviders(c);
    }

    /** 로그인한 계정(구글로 만든)에 아이디·비밀번호를 더 붙여요.
     *  Firebase 웹 SDK의 linkWithCredential과 같은 방법(accounts:signUp에 지금 열쇠를 같이 보냄)을 먼저 쓰고,
     *  혹시 따로 새 계정이 생기면 그 계정은 지우고 accounts:update로 다시 해요. */
    static void addId(Context c, String id, String pw) throws Fb.Err {
        String me = uid(c);
        Map<String, Object> r = Fb.auth("accounts:signUp",
                Fb.body("idToken", idToken(c), "email", idMail(id), "password", pw, "returnSecureToken", true));
        if (!me.equals(Json.s(r, "localId"))) {
            try { Fb.auth("accounts:delete", Fb.body("idToken", Json.s(r, "idToken"))); } catch (Fb.Err ignored) {}
            r = Fb.auth("accounts:update",
                    Fb.body("idToken", idToken(c), "email", idMail(id), "password", pw, "returnSecureToken", true));
        }
        save(c, r, false);
        prefs(c).edit().putString("lid", id).putBoolean("pw", true).apply();
        refreshProviders(c);
    }

    private static Map<String, Object> idpBody(String googleIdToken, String linkTo) {
        Map<String, Object> b = Fb.body(
                "postBody", "id_token=" + Fb.enc(googleIdToken) + "&providerId=google.com",
                "requestUri", "http://localhost",
                "returnIdpCredential", true,
                "returnSecureToken", true);
        if (linkTo != null) b.put("idToken", linkTo);
        return b;
    }

    /** 로그인 결과 저장. fresh면 다른 계정으로 바뀐 것일 수 있어서 이전 표시를 지워요 */
    private static void save(Context c, Map<String, Object> r, boolean fresh) throws Fb.Err {
        String uid = Json.s(r, "localId"), it = Json.s(r, "idToken"), rt = Json.s(r, "refreshToken");
        if (it.isEmpty()) throw new Fb.Err("BAD_RESPONSE", 200, "idToken 없음");
        long ttl = parseLong(Json.s(r, "expiresIn"), 3600);
        synchronized (LOCK) {
            SharedPreferences.Editor e = prefs(c).edit();
            if (fresh) {
                if (!uid.equals(uid(c))) e.remove("lid").remove("pw").remove("gg").remove("gname").remove("gmail").remove("last").remove("err");
                e.putString("uid", uid);
            }
            e.putString("it", it).putLong("exp", System.currentTimeMillis() + ttl * 1000L);
            if (!rt.isEmpty()) e.putString("rt", rt);
            if (r.get("providerId") instanceof String && "google.com".equals(r.get("providerId"))) {
                e.putBoolean("gg", true);
                String name = Json.s(r, "displayName"), mail = Json.s(r, "email");
                if (!name.isEmpty()) e.putString("gname", name);
                if (!mail.isEmpty() && idFromMail(mail).isEmpty()) e.putString("gmail", mail);
            }
            e.commit();
        }
    }

    /** 계정에 붙은 로그인 방법(구글·아이디)을 서버에서 다시 읽어요 */
    static void refreshProviders(Context c) {
        try {
            Map<String, Object> r = Fb.auth("accounts:lookup", Fb.body("idToken", idToken(c)));
            List<Object> users = Json.arr(r.get("users"));
            Map<String, Object> u = users == null || users.isEmpty() ? null : Json.obj(users.get(0));
            if (u == null) return;
            boolean gg = false, pw = false;
            String gname = "", gmail = "", lid = idFromMail(Json.s(u, "email"));
            List<Object> ps = Json.arr(u.get("providerUserInfo"));
            if (ps != null) for (Object o : ps) {
                Map<String, Object> p = Json.obj(o);
                String id = Json.s(p, "providerId");
                if ("google.com".equals(id)) {
                    gg = true;
                    gname = Json.s(p, "displayName");
                    gmail = Json.s(p, "email");
                } else if ("password".equals(id)) {
                    pw = true;
                    if (lid.isEmpty()) lid = idFromMail(Json.s(p, "email"));
                }
            }
            SharedPreferences.Editor e = prefs(c).edit().putBoolean("gg", gg).putBoolean("pw", pw && !lid.isEmpty());
            if (!lid.isEmpty()) e.putString("lid", lid);
            if (!gname.isEmpty()) e.putString("gname", gname);
            if (!gmail.isEmpty()) e.putString("gmail", gmail);
            e.apply();
        } catch (Fb.Err ignored) {
            // 못 읽어도 로그인은 그대로
        }
    }

    /** 쓸 수 있는 열쇠(ID 토큰). 5분 안에 만료되면 새로 받아요 */
    static String idToken(Context c) throws Fb.Err {
        synchronized (LOCK) {
            SharedPreferences p = prefs(c);
            String it = p.getString("it", ""), rt = p.getString("rt", "");
            if (p.getString("uid", "").isEmpty() || rt.isEmpty()) throw new Fb.Err("MISSING_REFRESH_TOKEN", 0, "");
            if (!it.isEmpty() && p.getLong("exp", 0) - System.currentTimeMillis() > 5 * 60 * 1000L) return it;
            Map<String, Object> r = Fb.refresh(rt);
            String nit = Json.s(r, "id_token"), nrt = Json.s(r, "refresh_token");
            if (nit.isEmpty()) throw new Fb.Err("BAD_RESPONSE", 200, "id_token 없음");
            long ttl = parseLong(Json.s(r, "expires_in"), 3600);
            SharedPreferences.Editor e = p.edit().putString("it", nit).putLong("exp", System.currentTimeMillis() + ttl * 1000L);
            if (!nrt.isEmpty()) e.putString("rt", nrt);
            e.commit();
            return nit;
        }
    }

    /** 로그아웃: 이 기기의 공부 기록은 그대로 두고 로그인 정보만 지워요 */
    static void logout(Context c) {
        synchronized (LOCK) {
            prefs(c).edit().remove("uid").remove("it").remove("rt").remove("exp").remove("lid").remove("pw")
                    .remove("gg").remove("gname").remove("gmail").remove("last").remove("err").commit();
        }
    }

    private static long parseLong(String s, long d) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return d; }
    }
}
