package com.js.hanguksaquiz;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * 기기끼리 기록 합치기 (안드로이드에 기대지 않는 순수 계산이라 컴퓨터에서 시험해요).
 *
 * 세 가지를 비교해요: 지난번에 맞춘 기록(base), 이 기기 기록(local), 서버 기록(remote).
 * 한쪽만 바뀐 항목은 바뀐 쪽을 따르고, 양쪽이 다 바뀐 항목만 더 꼼꼼히 합쳐요.
 *  - 공부 기록처럼 JSON 객체인 값은 안쪽 항목끼리 다시 같은 방법으로 합쳐요 (두 기기에서 다른 문제를 풀었으면 둘 다 남아요)
 *  - 글자 목록(틀린 문제 목록 같은)은 집합처럼: 더한 것은 더하고 뺀 것은 빼요
 *  - 푼 문제 수 같은 셈은 두 기기에서 늘어난 만큼을 더해요
 *  - 그 밖에는 나중에 바꾼 쪽이 이겨요 (같으면 서버 쪽)
 */
final class SyncMerge {
    private SyncMerge() {}

    /** 한 항목: 값(v, null이면 지워진 항목), 설정 값의 종류(y), 바꾼 때(t, 밀리초) */
    static final class Entry {
        final Object v;
        final String y;
        final long t;

        Entry(Object v, String y, long t) { this.v = v; this.y = y; this.t = t; }
    }

    /** 맞출 기록 전체: 공부 화면 기록(w)과 잠금화면 설정·기록(p) */
    static final class Doc {
        final TreeMap<String, Entry> w = new TreeMap<>();
        final TreeMap<String, Entry> p = new TreeMap<>();

        boolean sameValues(Doc o) { return sameMap(w, o.w) && sameMap(p, o.p); }

        Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("w", side(w, false));
            m.put("p", side(p, true));
            return m;
        }

        String toText() { return Json.str(toJson()); }

        static Doc fromText(String s) {
            Doc d = new Doc();
            Map<String, Object> m = Json.objOf(s);
            if (m == null) return d;
            read(Json.obj(m.get("w")), d.w);
            read(Json.obj(m.get("p")), d.p);
            return d;
        }

        private static Map<String, Object> side(TreeMap<String, Entry> src, boolean typed) {
            Map<String, Object> o = new LinkedHashMap<>();
            for (Map.Entry<String, Entry> e : src.entrySet()) {
                Map<String, Object> x = new LinkedHashMap<>();
                x.put("v", e.getValue().v == null ? Json.NULL : e.getValue().v);
                if (typed && e.getValue().y != null) x.put("y", e.getValue().y);
                x.put("t", e.getValue().t);
                o.put(e.getKey(), x);
            }
            return o;
        }

        private static void read(Map<String, Object> src, TreeMap<String, Entry> dst) {
            if (src == null) return;
            for (Map.Entry<String, Object> e : src.entrySet()) {
                Map<String, Object> x = Json.obj(e.getValue());
                if (x == null) continue;
                Object v = x.get("v");
                if (v == Json.NULL) v = null;
                Object y = x.get("y");
                dst.put(e.getKey(), new Entry(v, y instanceof String ? (String) y : null, Json.l(x, "t")));
            }
        }
    }

    static boolean sameMap(Map<String, Entry> a, Map<String, Entry> b) {
        Set<String> keys = new HashSet<>(a.keySet());
        keys.addAll(b.keySet());
        for (String k : keys) {
            Entry x = a.get(k), z = b.get(k);
            if (!Json.eq(x == null ? null : x.v, z == null ? null : z.v)) return false;
        }
        return true;
    }

    /** 이 기기의 지금 값에 '바꾼 때'를 붙여요. 지난번과 같으면 그때 시각, 바뀌었으면 now.
     *  처음 맞출 때(base 없음)는 0을 붙여서, 계정에 이미 있는 값과 부딪히면 계정 쪽을 따라요. */
    static TreeMap<String, Entry> stamp(TreeMap<String, Entry> base, Map<String, Object> cur, Map<String, String> types,
                                        long now, boolean first) {
        TreeMap<String, Entry> out = new TreeMap<>();
        for (Map.Entry<String, Object> e : cur.entrySet()) {
            Entry b = base.get(e.getKey());
            String y = types == null ? null : types.get(e.getKey());
            if (b != null && Json.eq(b.v, e.getValue())) out.put(e.getKey(), new Entry(e.getValue(), y, b.t));
            else out.put(e.getKey(), new Entry(e.getValue(), y, first ? 0 : now));
        }
        // 지난번엔 있었는데 지금 없으면 지운 것
        for (Map.Entry<String, Entry> e : base.entrySet()) {
            if (cur.containsKey(e.getKey())) continue;
            Entry b = e.getValue();
            out.put(e.getKey(), b.v == null ? b : new Entry(null, b.y, now));
        }
        return out;
    }

    /** 공부 화면 기록 합치기. 값은 글자(대개 JSON) */
    static TreeMap<String, Entry> mergeWeb(TreeMap<String, Entry> base, TreeMap<String, Entry> local, TreeMap<String, Entry> remote) {
        TreeMap<String, Entry> out = new TreeMap<>();
        for (String k : keys(base, local, remote)) {
            Entry b = base.get(k), l = local.get(k), r = remote.get(k);
            Entry m = mergeOne(b, l, r, (bv, lv, rv, preferLocal) -> mergeWebValue(k, bv, lv, rv, preferLocal), WEB_COUNTERS.contains(k));
            if (m != null) out.put(k, m);
        }
        return out;
    }

    /** 잠금화면 설정·기록 합치기 */
    static TreeMap<String, Entry> mergePrefs(TreeMap<String, Entry> base, TreeMap<String, Entry> local, TreeMap<String, Entry> remote) {
        TreeMap<String, Entry> out = new TreeMap<>();
        for (String k : keys(base, local, remote)) {
            if (k.equals("day_n")) continue;   // 날짜와 같이 따로 합쳐요
            Entry b = base.get(k), l = local.get(k), r = remote.get(k);
            Entry m;
            if (k.equals("day")) {
                m = mergeOne(b, l, r, (bv, lv, rv, pl) -> later(lv, rv), false);
            } else {
                final boolean counter = COUNTERS.contains(k), jsonCounter = PREF_JSON_COUNTERS.contains(k);
                m = mergeOne(b, l, r, (bv, lv, rv, pl) -> {
                    if (counter && lv instanceof Number && rv instanceof Number) return add(bv, lv, rv);
                    if (jsonCounter && lv instanceof String && rv instanceof String) return mergeWebValue("", bv, lv, rv, pl, true);
                    List<Object> la = Json.arr(lv), ra = Json.arr(rv);
                    if (la != null && ra != null && isTextSet(la) && isTextSet(ra)) return mergeSet(Json.arr(bv), la, ra);
                    return pl ? lv : rv;
                }, counter || jsonCounter);
            }
            if (m != null) out.put(k, m);
        }
        mergeDayCount(base, local, remote, out);
        return out;
    }

    /** 늘어난 만큼 더하는 셈 (잠금화면에서 푼 문제 수·맞힌 수) */
    static final Set<String> COUNTERS = new HashSet<>(java.util.Arrays.asList("total", "correct"));
    /** 안쪽 수를 늘어난 만큼 더하는 JSON 설정 (단원별 맞힌 수·푼 수) */
    static final Set<String> PREF_JSON_COUNTERS = new HashSet<>(java.util.Collections.singletonList("ust"));

    private interface Both { Object pick(Object base, Object local, Object remote, boolean preferLocal); }

    /** 한 항목 합치기. 둘 다 없으면 null.
     *  additive: 셈하는 값이라, 양쪽이 지난번과 달라졌으면 값이 같아도(둘 다 +1) 늘어난 만큼 더해요 */
    private static Entry mergeOne(Entry b, Entry l, Entry r, Both both, boolean additive) {
        Object bv = b == null ? null : b.v, lv = l == null ? null : l.v, rv = r == null ? null : r.v;
        long lt = l == null ? 0 : l.t, rt = r == null ? 0 : r.t;
        String y = r != null && r.y != null ? r.y : (l != null ? l.y : (b != null ? b.y : null));
        if (additive && lv != null && rv != null && !Json.eq(lv, bv) && !Json.eq(rv, bv)) {
            Object v = both.pick(bv, lv, rv, lt > rt);
            return new Entry(v, l.y != null ? l.y : y, Math.max(lt, rt));
        }
        if (Json.eq(lv, rv)) {
            if (lv == null && l == null && r == null) return null;
            String yy = l != null && l.y != null ? l.y : y;
            return new Entry(lv, yy, Math.max(lt, rt));
        }
        if (Json.eq(lv, bv)) return r != null ? r : new Entry(null, y, Math.max(lt, rt));   // 서버만 바뀜
        if (Json.eq(rv, bv)) return l != null ? l : new Entry(null, y, Math.max(lt, rt));   // 이 기기만 바뀜
        boolean preferLocal = lt > rt;
        if (lv == null || rv == null) return preferLocal ? l : r;    // 한쪽은 지우고 한쪽은 바꿈: 나중 쪽
        Object v = both.pick(bv, lv, rv, preferLocal);
        String yy = Json.eq(v, lv) && l.y != null ? l.y : y;
        return new Entry(v, yy, Math.max(lt, rt));
    }

    private static Object mergeWebValue(String key, Object bv, Object lv, Object rv, boolean preferLocal) {
        return mergeWebValue(key, bv, lv, rv, preferLocal, WEB_COUNTERS.contains(key));
    }

    private static Object mergeWebValue(String key, Object bv, Object lv, Object rv, boolean preferLocal, boolean counters) {
        if (lv instanceof String && rv instanceof String) {
            Object lj = Json.tryParse((String) lv), rj = Json.tryParse((String) rv);
            boolean objs = Json.obj(lj) != null && Json.obj(rj) != null;
            boolean sets = Json.arr(lj) != null && Json.arr(rj) != null && isTextSet(Json.arr(lj)) && isTextSet(Json.arr(rj));
            if (objs || sets) {
                Object bj = bv instanceof String ? Json.tryParse((String) bv) : null;
                Object mj = deep(bj, lj, rj, preferLocal, counters);
                if (Json.eq(mj, lj)) return lv;
                if (Json.eq(mj, rj)) return rv;
                return Json.str(mj);
            }
        }
        return preferLocal ? lv : rv;
    }

    /** 공부 화면 기록 가운데, 안쪽 수를 늘어난 만큼 더하는 것 (영어: 낱말마다 맞힌 횟수) */
    static final Set<String> WEB_COUNTERS = new HashSet<>(java.util.Collections.singletonList("v1800b-hits"));

    private static final Object MISSING = new Object();

    /** JSON 값 셋을 견주어 합쳐요 (객체는 안쪽까지).
     *  counters면 안쪽 수는 셈이라, 양쪽이 다 바뀌었으면 값이 같아도 늘어난 만큼 더해요 */
    static Object deep(Object b, Object l, Object r, boolean preferLocal, boolean counters) {
        if (b != null && Json.eq(l, b)) return r;
        if (b != null && Json.eq(r, b)) return l;
        if (!counters && Json.eq(l, r)) return l;
        Map<String, Object> lm = Json.obj(l), rm = Json.obj(r);
        if (lm != null && rm != null) {
            Map<String, Object> bm = Json.obj(b);
            Set<String> keys = new LinkedHashSet<>(rm.keySet());
            keys.addAll(lm.keySet());
            if (bm != null) keys.addAll(bm.keySet());
            Map<String, Object> out = new LinkedHashMap<>();
            for (String k : keys) {
                Object bv = bm != null && bm.containsKey(k) ? bm.get(k) : MISSING;
                Object lv = lm.containsKey(k) ? lm.get(k) : MISSING;
                Object rv = rm.containsKey(k) ? rm.get(k) : MISSING;
                Object v = deep3(bv, lv, rv, preferLocal, counters);
                if (v != MISSING) out.put(k, v);
            }
            return out;
        }
        List<Object> la = Json.arr(l), ra = Json.arr(r);
        if (la != null && ra != null && isTextSet(la) && isTextSet(ra)) {
            List<Object> ba = Json.arr(b);
            if (ba == null || isTextSet(ba)) return mergeSet(ba, la, ra);
        }
        if (counters && l instanceof Number && r instanceof Number && (b == null || b instanceof Number)) return add(b, l, r);
        if (Json.eq(l, r)) return l;
        return preferLocal ? l : r;
    }

    private static Object deep3(Object bv, Object lv, Object rv, boolean preferLocal, boolean counters) {
        if (same(lv, bv)) return rv;
        if (same(rv, bv)) return lv;
        if (lv == MISSING || rv == MISSING) return same(lv, rv) ? lv : (preferLocal ? lv : rv);
        boolean nums = lv instanceof Number && rv instanceof Number && (bv == MISSING || bv instanceof Number);
        if (same(lv, rv) && !(counters && nums)) return lv;
        return deep(bv == MISSING ? null : bv, lv, rv, preferLocal, counters);
    }

    private static boolean same(Object a, Object b) {
        if (a == MISSING || b == MISSING) return a == b;
        return Json.eq(a, b);
    }

    /** 늘어난 만큼 더하기: 서버 + (이 기기 - 지난번) */
    private static Object add(Object b, Object l, Object r) {
        long base = b instanceof Number ? ((Number) b).longValue() : 0;
        long v = ((Number) r).longValue() + ((Number) l).longValue() - base;
        return Math.max(0, v);
    }

    /** 겹치지 않는 글자만 든 목록인지 (그래야 집합처럼 합쳐도 돼요) */
    static boolean isTextSet(List<Object> a) {
        Set<Object> seen = new HashSet<>();
        for (Object o : a) {
            if (!(o instanceof String) || !seen.add(o)) return false;
        }
        return true;
    }

    /** 집합 합치기: 서버 목록에서 이 기기가 더한 것은 더하고, 뺀 것은 빼요 */
    static List<Object> mergeSet(List<Object> b, List<Object> l, List<Object> r) {
        Set<Object> base = b == null ? new HashSet<>() : new HashSet<>(b);
        Set<Object> loc = new HashSet<>(l);
        LinkedHashSet<Object> out = new LinkedHashSet<>(r);
        for (Object o : l) if (!base.contains(o)) out.add(o);
        for (Object o : base) if (!loc.contains(o)) out.remove(o);
        return new ArrayList<>(out);
    }

    /** 'yyyyMMdd' 날짜 중 늦은 쪽 */
    private static Object later(Object a, Object b) {
        String x = a instanceof String ? (String) a : "", z = b instanceof String ? (String) b : "";
        return x.compareTo(z) >= 0 ? a : b;
    }

    /** 오늘 푼 문제 수(day_n)는 날짜(day)를 보고 합쳐요: 같은 날이면 늘어난 만큼 더하고, 아니면 합친 날짜 쪽을 따라요 */
    private static void mergeDayCount(TreeMap<String, Entry> base, TreeMap<String, Entry> local, TreeMap<String, Entry> remote,
                                      TreeMap<String, Entry> out) {
        Entry d = out.get("day");
        Entry bn = base.get("day_n"), ln = local.get("day_n"), rn = remote.get("day_n");
        if (ln == null && rn == null) {
            if (bn != null) out.put("day_n", bn.v == null ? bn : new Entry(null, bn.y, bn.t));
            return;
        }
        String day = d != null && d.v instanceof String ? (String) d.v : "";
        String bd = val(base.get("day")), ld = val(local.get("day")), rd = val(remote.get("day"));
        Object lv = ln == null ? null : ln.v, rv = rn == null ? null : rn.v, bv = bn == null ? null : bn.v;
        long t = Math.max(ln == null ? 0 : ln.t, rn == null ? 0 : rn.t);
        String y = ln != null && ln.y != null ? ln.y : (rn != null ? rn.y : "i");
        Object v;
        if (day.equals(ld) && day.equals(rd)) {
            if (lv instanceof Number && rv instanceof Number) {
                // 같은 날: 지난번 맞춘 뒤로 양쪽에서 늘어난 만큼 더해요 (지난번이 다른 날이면 둘 다 0부터)
                if (day.equals(bd) && Json.eq(lv, bv)) v = rv;
                else if (day.equals(bd) && Json.eq(rv, bv)) v = lv;
                else v = add(day.equals(bd) ? bv : null, lv, rv);
            } else {
                v = lv != null ? lv : rv;
            }
        } else if (day.equals(ld)) {
            v = lv;
        } else if (day.equals(rd)) {
            v = rv;
        } else {
            v = lv != null ? lv : rv;
        }
        if (v instanceof Number && !(v instanceof Integer)) v = ((Number) v).longValue();
        out.put("day_n", new Entry(v, y, t));
    }

    private static String val(Entry e) { return e != null && e.v instanceof String ? (String) e.v : ""; }

    private static Set<String> keys(Map<String, ?> a, Map<String, ?> b, Map<String, ?> c) {
        Set<String> s = new java.util.TreeSet<>(a.keySet());
        s.addAll(b.keySet());
        s.addAll(c.keySet());
        return s;
    }

    /** 오래된 '지워짐' 표시는 버려요 (몇 달 지나면 다른 기기도 다 맞췄을 테니) */
    static void prune(TreeMap<String, Entry> m, long olderThan) {
        m.entrySet().removeIf(e -> e.getValue().v == null && e.getValue().t < olderThan);
    }
}
