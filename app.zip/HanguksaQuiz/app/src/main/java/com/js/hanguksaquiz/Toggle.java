package com.js.hanguksaquiz;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CheckBox;
import android.widget.Switch;

/** 설정 화면에서 쓰는 켜기 스위치와 체크 상자. 밝은 화면·어두운 화면 모두 같은 모양으로 그려요. */
final class Toggle extends View {

    interface OnChange { void changed(Toggle t, boolean on); }

    private final boolean check;          // true면 체크 상자, false면 스위치
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path tick = new Path();
    private boolean on;
    private float pos;                    // 0 꺼짐 ~ 1 켜짐 (움직이는 중간값)
    private int onColor, offColor, knobOn, knobOff;
    private OnChange listener;
    private ValueAnimator anim;

    Toggle(Context c, boolean check) {
        super(c);
        this.check = check;
        setClickable(true);
        setFocusable(true);
        setOnClickListener(v -> toggle());
    }

    /** onColor: 켜졌을 때 바탕, offColor: 꺼졌을 때 바탕(스위치)이나 테두리(체크), knob: 동그라미나 체크 표시 색 */
    Toggle colors(int onColor, int offColor, int knobOn, int knobOff) {
        this.onColor = onColor;
        this.offColor = offColor;
        this.knobOn = knobOn;
        this.knobOff = knobOff;
        invalidate();
        return this;
    }

    void setOnChange(OnChange l) { listener = l; }

    boolean isChecked() { return on; }

    /** 화면만 바꿔요 (알림 없이). 되돌릴 때도 이걸 써요. */
    void setChecked(boolean v) {
        if (anim != null) anim.cancel();
        on = v;
        pos = v ? 1f : 0f;
        invalidate();
    }

    /** 누른 것처럼 바꾸고 알려 줘요 */
    void toggle() {
        on = !on;
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(pos, on ? 1f : 0f);
        anim.setDuration(160);
        anim.addUpdateListener(a -> { pos = (Float) a.getAnimatedValue(); invalidate(); });
        anim.start();
        if (listener != null) listener.changed(this, on);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(resolveSize(Ui.dp(getContext(), check ? 40 : 56), wSpec),
                resolveSize(Ui.dp(getContext(), 40), hSpec));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        if (check) {
            float s = Ui.dp(getContext(), 22), sw = Ui.dp(getContext(), 2);
            float l = (w - s) / 2, t = (h - s) / 2;
            r.set(l, t, l + s, t + s);
            float rad = Ui.dp(getContext(), 6);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(blend(0x00FFFFFF & onColor, onColor, pos));
            cv.drawRoundRect(r, rad, rad, paint);
            if (pos < 1f) {
                r.inset(sw / 2, sw / 2);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(sw);
                paint.setColor(blend(offColor, onColor, pos));
                cv.drawRoundRect(r, rad - sw / 2, rad - sw / 2, paint);
            }
            if (pos > 0f) {
                tick.reset();
                tick.moveTo(l + s * 0.27f, t + s * 0.52f);
                tick.lineTo(l + s * 0.44f, t + s * 0.69f);
                tick.lineTo(l + s * 0.75f, t + s * 0.35f);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Ui.dp(getContext(), 2.4f));
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setColor(blend(0x00FFFFFF & knobOn, knobOn, pos));
                cv.drawPath(tick, paint);
            }
        } else {
            float tw = Ui.dp(getContext(), 48), th = Ui.dp(getContext(), 28);
            float l = (w - tw) / 2, t = (h - th) / 2;
            r.set(l, t, l + tw, t + th);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(blend(offColor, onColor, pos));
            cv.drawRoundRect(r, th / 2, th / 2, paint);
            float pad = Ui.dp(getContext(), 3), d = th - 2 * pad;
            float cx = l + pad + d / 2 + (tw - 2 * pad - d) * pos;
            paint.setColor(blend(knobOff, knobOn, pos));
            cv.drawCircle(cx, t + th / 2, d / 2, paint);
        }
    }

    private static int blend(int a, int b, float f) {
        int aa = a >>> 24, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = b >>> 24, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return (Math.round(aa + (ba - aa) * f) << 24) | (Math.round(ar + (br - ar) * f) << 16)
                | (Math.round(ag + (bg - ag) * f) << 8) | Math.round(ab + (bb - ab) * f);
    }

    @Override
    public CharSequence getAccessibilityClassName() {
        return (check ? CheckBox.class : Switch.class).getName();
    }

    @Override
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        info.setCheckable(true);
        info.setChecked(on);
    }
}
