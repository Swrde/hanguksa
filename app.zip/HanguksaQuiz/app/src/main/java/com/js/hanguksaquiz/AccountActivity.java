package com.js.hanguksaquiz;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 계정과 동기화: 구글·아이디로 로그인, 로그인 방법 더하기, 지금 동기화, 로그아웃 */
public class AccountActivity extends Activity {

    private boolean dark;
    private int cBg, cInk, cSoft, cRule, cTint, cPen, cAccent;

    private LinearLayout col;
    private TextView statusText;
    private boolean working;           // 서버와 이야기하는 동안은 단추를 또 누르지 않게
    private boolean addIdOpen;         // '아이디 만들기' 칸을 펼쳤는지
    private final Runnable onSync = this::paintStatus;

    private LinearLayout headBar;
    private TextView headTitle;
    private View headLine;
    private boolean headSolid;

    @Override
    protected void onCreate(Bundle saved) {
        palette();
        setTheme(dark ? android.R.style.Theme_Material_NoActionBar : android.R.style.Theme_Material_Light_NoActionBar);
        super.onCreate(saved);
        getWindow().getDecorView().setBackgroundColor(cBg);
        getWindow().setBackgroundDrawable(Glass.background(this, dark));

        FrameLayout root = new FrameLayout(this);
        root.setBackground(Glass.background(this, dark));
        ScrollView sv = new ScrollView(this);
        sv.setClipToPadding(false);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(52), dp(16), dp(36));
        sv.addView(col);
        root.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 떠 있는 막대: 뒤로 + 작은 제목 (설정 화면과 같게)
        headBar = new LinearLayout(this);
        headBar.setOrientation(LinearLayout.VERTICAL);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(6), 0, dp(16), 0);
        ImageView back = new ImageView(this);
        back.setImageResource(R.drawable.ic_back);
        back.setImageTintList(ColorStateList.valueOf(cAccent));
        back.setScaleType(ImageView.ScaleType.CENTER);
        back.setContentDescription("뒤로");
        back.setBackground(ripple(true));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        headTitle = Ui.text(this, "계정", 17, cInk, true);
        headTitle.setGravity(Gravity.CENTER);
        headTitle.setAlpha(0f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tp.rightMargin = dp(28);
        head.addView(headTitle, tp);
        headBar.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        headLine = new View(this);
        headLine.setBackgroundColor(cRule);
        headLine.setAlpha(0f);
        headBar.addView(headLine, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(0.5f))));
        root.addView(headBar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.setOnScrollChangeListener((v, x, y, ox, oy) -> setHeadSolid(y > dp(30)));

        setContentView(root);
        Ui.edgeToEdge(this, root, !dark);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Sync.listen(onSync);
        paintStatus();
    }

    @Override
    protected void onPause() {
        Sync.unlisten(onSync);
        super.onPause();
    }

    private void palette() {
        String t = getSharedPreferences("ui", MODE_PRIVATE).getString("theme", "auto");
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        dark = "dark".equals(t) || (!"light".equals(t) && night);
        if (dark) {
            cBg = 0xFF06070D; cInk = 0xFFFFFFFF; cSoft = 0xFFA1A1A8; cRule = 0x1AFFFFFF; cTint = 0x3D767680;
            cPen = 0xFFFF6961; cAccent = 0xFF7D7AFF;
        } else {
            cBg = 0xFFE8EBF3; cInk = 0xFF000000; cSoft = 0xFF5E5E66; cRule = 0x213C3C43; cTint = 0x1C767680;
            cPen = 0xFFD70015; cAccent = 0xFF5E5CE6;
        }
    }

    private void setHeadSolid(boolean on) {
        if (on == headSolid) return;
        headSolid = on;
        headBar.setBackgroundColor(on ? (dark ? 0xD90D0E16 : 0xD9F0F1F6) : 0);
        headTitle.animate().alpha(on ? 1f : 0f).setDuration(160).start();
        headLine.setAlpha(on ? 1f : 0f);
    }

    // ───────── 화면 그리기 ─────────

    private void render() {
        col.removeAllViews();
        statusText = null;
        TextView big = Ui.text(this, "계정", 30, cInk, true);
        big.setLetterSpacing(-0.02f);
        LinearLayout.LayoutParams bigp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bigp.setMargins(dp(4), dp(4), dp(4), dp(6));
        col.addView(big, bigp);

        if (!Fb.ready()) {
            LinearLayout c = card(col);
            ((LinearLayout.LayoutParams) c.getLayoutParams()).topMargin = dp(8);
            TextView n = note("이 버전에는 아직 서버(Firebase) 설정이 들어 있지 않아요. 서버 설정이 들어간 새 버전을 받으면 로그인할 수 있어요.");
            n.setPadding(dp(16), dp(14), dp(16), dp(14));
            c.addView(n);
            buildWhat();
            return;
        }
        if (Account.loggedIn(this)) buildIn();
        else buildOut();
        buildWhat();
    }

    /** 로그인 전: 구글로, 또는 아이디로 */
    private void buildOut() {
        LinearLayout c = card(col);
        ((LinearLayout.LayoutParams) c.getLayoutParams()).topMargin = dp(8);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        TextView lead = Ui.text(this, "로그인하면 휴대폰과 태블릿의 공부 기록이 이어져요", 16, cInk, true);
        lead.setLineSpacing(0, 1.15f);
        c.addView(lead);
        TextView s = sub("처음 로그인하면 이 기기의 기록을 계정 기록과 합쳐요. 지워지는 기록은 없어요.");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(4);
        c.addView(s, sp);
        String err = Account.prefs(this).getString("err", "");
        if (!err.isEmpty()) {
            TextView e = sub(err);
            e.setTextColor(cPen);
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ep.topMargin = dp(6);
            c.addView(e, ep);
        }
        if (Fb.googleReady()) {
            TextView g = googleButton("Google 계정으로 로그인");
            g.setOnClickListener(v -> googleSignIn(false));
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            gp.topMargin = dp(14);
            c.addView(g, gp);
        }

        LinearLayout f = section(col, "아이디로");
        final EditText id = field("아이디", false);
        final EditText pw = field("비밀번호 (6자 이상)", true);
        fieldRow(f, "아이디", id);
        divider(f);
        fieldRow(f, "비밀번호", pw);
        LinearLayout btns = new LinearLayout(this);
        btns.setPadding(dp(16), dp(6), dp(16), dp(16));
        TextView in = button("로그인", cAccent, 0xFFFFFFFF);
        TextView up = button("새로 만들기", cTint, cInk);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        btns.addView(in, bp);
        LinearLayout.LayoutParams bp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        bp2.leftMargin = dp(10);
        btns.addView(up, bp2);
        f.addView(btns);
        in.setOnClickListener(v -> idSubmit(id, pw, false));
        up.setOnClickListener(v -> idSubmit(id, pw, true));
        pw.setOnEditorActionListener((v, action, ev) -> {
            if (action == EditorInfo.IME_ACTION_DONE) { idSubmit(id, pw, false); return true; }
            return false;
        });
        TextView n = note("아이디는 영어 소문자와 숫자로 4~20자예요. 아이디로 만든 계정은 비밀번호를 잊으면 되찾을 수 없으니, "
                + "구글 계정도 같이 연결해 두면 좋아요.");
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        np.setMargins(dp(6), dp(8), dp(6), 0);
        col.addView(n, np);
    }

    /** 로그인 뒤: 이름, 동기화, 로그인 방법, 로그아웃 */
    private void buildIn() {
        LinearLayout c = card(col);
        ((LinearLayout.LayoutParams) c.getLayoutParams()).topMargin = dp(8);
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(16), dp(14), dp(16), dp(14));
        String name = Account.label(this);
        TextView av = Ui.text(this, name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(java.util.Locale.ROOT), 20, 0xFFFFFFFF, true);
        av.setGravity(Gravity.CENTER);
        av.setBackground(Ui.box(this, cAccent, 0, 24));
        top.addView(av, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(Ui.text(this, name, 18, cInk, true));
        boolean g = Account.hasGoogle(this), i = Account.hasId(this);
        String kind = g && i ? "구글 · 아이디로 들어올 수 있어요" : g ? "구글 계정" : "아이디 계정";
        tx.addView(sub(kind));
        LinearLayout.LayoutParams txp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        txp.leftMargin = dp(12);
        top.addView(tx, txp);
        c.addView(top);
        divider(c);
        statusText = sub("");
        TextView now = chip("지금 하기");
        now.setOnClickListener(v -> {
            if (Sync.busy) return;
            Sync.now(this, r -> {
                if (r.code == Sync.OK) toast(r.pulled ? "다른 기기 기록을 받아 왔어요" : "동기화했어요");
                else if (r.code == Sync.LOGGED_OUT) { toast(r.msg); render(); }
                else toast(r.msg);
                paintStatus();
            });
            paintStatus();
        });
        row(c, "동기화", statusText, now);
        paintStatus();

        LinearLayout m = section(col, "로그인 방법");
        TextView gs = sub(g ? "연결됨 · " + Account.googleMailMasked(this) : "연결하면 구글 계정으로도 들어올 수 있어요");
        TextView gb = null;
        if (!g && Fb.googleReady()) {
            gb = chip("연결");
            gb.setOnClickListener(v -> googleSignIn(true));
        }
        row(m, "Google", gs, gb);
        divider(m);
        TextView is = sub(i ? Account.loginId(this) : "만들면 아이디와 비밀번호로도 들어올 수 있어요");
        TextView ib = null;
        if (!i) {
            ib = chip(addIdOpen ? "닫기" : "만들기");
            ib.setOnClickListener(v -> { addIdOpen = !addIdOpen; render(); });
        }
        row(m, "아이디", is, ib);
        if (!i && addIdOpen) {
            divider(m);
            final EditText id = field("새 아이디", false);
            final EditText pw = field("비밀번호 (6자 이상)", true);
            fieldRow(m, "아이디", id);
            divider(m);
            fieldRow(m, "비밀번호", pw);
            TextView mk = button("아이디 만들기", cAccent, 0xFFFFFFFF);
            LinearLayout wrap = new LinearLayout(this);
            wrap.setPadding(dp(16), dp(6), dp(16), dp(16));
            wrap.addView(mk, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            m.addView(wrap);
            mk.setOnClickListener(v -> addId(id, pw));
        }

        LinearLayout o = card(col);
        ((LinearLayout.LayoutParams) o.getLayoutParams()).topMargin = dp(26);
        TextView out = Ui.text(this, "로그아웃", 16, cPen, false);
        out.setGravity(Gravity.CENTER);
        out.setMinHeight(dp(52));
        out.setForeground(ripple(false));
        out.setClickable(true);
        out.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("로그아웃할까요?")
                .setMessage("이 기기의 공부 기록은 그대로 남아요. 다시 로그인하면 이어서 맞춰요.")
                .setPositiveButton("로그아웃", (d, w) -> {
                    Sync.cancel();
                    Account.logout(this);
                    toast("로그아웃했어요");
                    render();
                })
                .setNegativeButton("취소", null)
                .show());
        o.addView(out, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    /** 무엇이 이어지는지 */
    private void buildWhat() {
        LinearLayout c = section(col, "무엇이 이어지나요");
        TextView n = note("한국사·통합사회·영어 공부 기록, 잠금화면 문제의 과목·범위 고르기와 푼 기록이 이어져요. "
                + "화면 모드, 교과서 확대 크기, 잠금화면 켜기와 얼마나 자주는 기기마다 따로예요.\n\n"
                + "앱을 열고 닫을 때, 그리고 잠금화면에서 문제를 푼 뒤 조금 있다가 저절로 맞춰요. "
                + "두 기기에서 같은 것을 따로 바꿨으면 나중에 바꾼 쪽을 따라요.");
        n.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.addView(n);
    }

    private void paintStatus() {
        if (statusText == null) return;
        String s = Sync.status(this);
        statusText.setText(s);
        String err = Account.prefs(this).getString("err", "");
        statusText.setTextColor(!Sync.busy && !err.isEmpty() ? cPen : cSoft);
    }

    // ───────── 로그인 ─────────

    private interface Job { void run(Context c) throws Fb.Err; }

    /** 서버 일은 뒤에서 하고, 끝나면 화면에서 알려 줘요 */
    private void work(String doing, Job job, Runnable ok) {
        if (working) return;
        working = true;
        toast(doing);
        final Context app = getApplicationContext();
        new Thread(() -> {
            String err = null;
            try {
                job.run(app);
            } catch (Fb.Err e) {
                err = e.say();
            } catch (RuntimeException e) {
                err = "문제가 생겼어요 (" + e.getClass().getSimpleName() + ")";
            }
            final String fe = err;
            runOnUiThread(() -> {
                working = false;
                if (isFinishing()) return;
                if (fe != null) toast(fe);
                else if (ok != null) ok.run();
                render();
            });
        }, "account").start();
    }

    /** 로그인하자마자 맞춰요 (처음이면 이 기기 기록을 계정 기록과 합쳐요) */
    private void afterLogin(String msg) {
        Account.prefs(this).edit().putString("err", "").apply();
        toast(msg);
        Sync.now(this, r -> {
            if (r.code == Sync.OK && r.pulled) toast("계정에 있던 기록을 받아 왔어요");
            else if (r.code != Sync.OK && !r.msg.isEmpty()) toast(r.msg);
            render();
        });
    }

    private void idSubmit(EditText idBox, EditText pwBox, boolean create) {
        final String id = Account.cleanId(idBox.getText().toString());
        final String pw = pwBox.getText().toString();
        if (id == null) { toast("아이디는 영어 소문자와 숫자로 4~20자예요"); idBox.requestFocus(); return; }
        if (pw.length() < 6) { toast("비밀번호는 6자 이상이어야 해요"); pwBox.requestFocus(); return; }
        if (create) {
            work("아이디를 만드는 중…", c -> Account.signUpId(c, id, pw), () -> afterLogin("아이디를 만들고 로그인했어요"));
        } else {
            work("로그인하는 중…", c -> Account.signInId(c, id, pw), () -> afterLogin("로그인했어요"));
        }
    }

    private void addId(EditText idBox, EditText pwBox) {
        final String id = Account.cleanId(idBox.getText().toString());
        final String pw = pwBox.getText().toString();
        if (id == null) { toast("아이디는 영어 소문자와 숫자로 4~20자예요"); idBox.requestFocus(); return; }
        if (pw.length() < 6) { toast("비밀번호는 6자 이상이어야 해요"); pwBox.requestFocus(); return; }
        if (working) return;
        working = true;
        toast("아이디를 만드는 중…");
        final Context app = getApplicationContext();
        new Thread(() -> {
            String err = null;
            boolean again = false;
            try {
                Account.addId(app, id, pw);
            } catch (Fb.Err e) {
                if ("CREDENTIAL_TOO_OLD_LOGIN_AGAIN".equals(e.code) && Account.hasGoogle(app)) again = true;
                else err = e.say();
            }
            final String fe = err;
            final boolean fa = again;
            runOnUiThread(() -> {
                working = false;
                if (isFinishing()) return;
                if (fa) {
                    // 오래전에 로그인했으면 구글로 한 번 더 확인한 뒤 다시 해요
                    toast("보안을 위해 구글로 한 번 더 확인할게요");
                    GoogleLogin.start(this, new GoogleLogin.Cb() {
                        @Override public void ok(String token, String name, String mail) {
                            work("아이디를 만드는 중…", c -> { Account.signInGoogle(c, token); Account.addId(c, id, pw); },
                                    () -> { addIdOpen = false; toast("아이디를 만들었어요. 이제 아이디로도 들어올 수 있어요"); });
                        }
                        @Override public void fail(String msg, boolean cancelled) { if (!cancelled) toast(msg); }
                    });
                    return;
                }
                if (fe != null) toast(fe);
                else { addIdOpen = false; toast("아이디를 만들었어요. 이제 아이디로도 들어올 수 있어요"); }
                render();
            });
        }, "account").start();
    }

    /** link: 로그인한 계정에 구글을 더 붙이기 (아니면 구글로 로그인) */
    private void googleSignIn(boolean link) {
        if (working) return;
        GoogleLogin.start(this, new GoogleLogin.Cb() {
            @Override
            public void ok(String token, String name, String mail) {
                if (link) {
                    work("구글 계정을 연결하는 중…", c -> Account.linkGoogle(c, token),
                            () -> toast("연결했어요. 이제 구글로도 들어올 수 있어요"));
                } else {
                    work("로그인하는 중…", c -> Account.signInGoogle(c, token), () -> afterLogin("로그인했어요"));
                }
            }

            @Override
            public void fail(String msg, boolean cancelled) {
                if (!cancelled) toast(msg);
            }
        });
    }

    // ───────── 작은 부품 (설정 화면과 같은 모양) ─────────

    private int dp(float v) { return Ui.dp(this, v); }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Glass.card(this, dark, 24));
        c.setClipToOutline(true);
        parent.addView(c, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return c;
    }

    private LinearLayout section(LinearLayout parent, String title) {
        TextView h = Ui.text(this, title, 13.5f, cSoft, false);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.setMargins(dp(6), dp(26), dp(6), dp(8));
        parent.addView(h, hp);
        return card(parent);
    }

    private void divider(LinearLayout card) {
        View d = new View(this);
        d.setBackgroundColor(cRule);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(0.7f)));
        p.leftMargin = dp(16);
        p.rightMargin = dp(16);
        card.addView(d, p);
    }

    private TextView sub(String s) {
        TextView t = Ui.text(this, s, 13.5f, cSoft, false);
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 13, cSoft, false);
        t.setLineSpacing(0, 1.25f);
        return t;
    }

    /** 제목(+설명) 왼쪽, 작은 단추 오른쪽 */
    private void row(LinearLayout card, String title, TextView state, TextView btn) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(60));
        r.setPadding(dp(16), dp(12), dp(14), dp(12));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(Ui.text(this, title, 16, cInk, false));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(2);
        txt.addView(state, sp);
        r.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (btn != null) {
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bp.leftMargin = dp(10);
            r.addView(btn, bp);
        }
        card.addView(r);
    }

    private EditText field(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        e.setTextColor(cInk);
        e.setHintTextColor(cSoft);
        e.setBackground(null);
        e.setPadding(0, dp(10), 0, dp(10));
        if (password) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            e.setImeOptions(EditorInfo.IME_ACTION_DONE);
            e.setAutofillHints(View.AUTOFILL_HINT_PASSWORD);
        } else {
            // 영어 자판이 뜨고 자동 고침이 안 되게
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.setImeOptions(EditorInfo.IME_ACTION_NEXT);
            e.setAutofillHints(View.AUTOFILL_HINT_USERNAME);
        }
        return e;
    }

    private void fieldRow(LinearLayout card, String label, EditText box) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(52));
        r.setPadding(dp(16), dp(2), dp(16), dp(2));
        TextView l = Ui.text(this, label, 16, cInk, false);
        r.addView(l, new LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT));
        r.addView(box, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        card.addView(r);
    }

    private TextView chip(String s) {
        TextView b = Ui.text(this, s, 14, cInk, true);
        b.setBackground(Ui.box(this, cTint, 0, 18));
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(36));
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setClickable(true);
        b.setFocusable(true);
        b.setForeground(ripple(false));
        return b;
    }

    private TextView button(String s, int fill, int ink) {
        TextView b = Ui.text(this, s, 15, ink, true);
        b.setBackground(Ui.box(this, fill, 0, 12));
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(48));
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setClickable(true);
        b.setFocusable(true);
        b.setForeground(ripple(false));
        return b;
    }

    /** 구글 단추: 흰(다크에선 어두운) 바탕에 색 G */
    private TextView googleButton(String s) {
        TextView b = button("", dark ? 0xFF2C2C2E : 0xFFFFFFFF, cInk);
        android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder("G  " + s);
        sb.setSpan(new android.text.style.ForegroundColorSpan(0xFF4285F4), 0, 1, 0);
        sb.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 0, 1, 0);
        sb.setSpan(new android.text.style.RelativeSizeSpan(1.2f), 0, 1, 0);
        b.setText(sb);
        b.setBackground(Ui.box(this, dark ? 0xFF2C2C2E : 0xFFFFFFFF, dark ? 0x33FFFFFF : 0x293C3C43, 12));
        return b;
    }

    private android.graphics.drawable.Drawable ripple(boolean borderless) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(borderless ? android.R.attr.selectableItemBackgroundBorderless
                : android.R.attr.selectableItemBackground, tv, true);
        return getDrawable(tv.resourceId);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
