package com.js.hanguksaquiz;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Firebase와 이야기하는 부분 (SDK 없이 인터넷 주소로 바로).
 * 로그인: Identity Toolkit, 열쇠 새로 받기: Secure Token, 기록: Realtime Database.
 * 서버 값은 google-services.json에서 빌드할 때 BuildConfig로 들어와요.
 */
final class Fb {
    private Fb() {}

    // 시험할 때는 가짜 서버 주소로 바꿔 써요
    static String AUTH = "https://identitytoolkit.googleapis.com/v1/";
    static String TOKEN = "https://securetoken.googleapis.com/v1/token";
    static String KEY = BuildConfig.FB_API_KEY;
    static String DB = BuildConfig.FB_DB_URL;
    static String WEB_CLIENT = BuildConfig.FB_WEB_CLIENT;

    /** 서버 값이 들어 있는 버전인지 */
    static boolean ready() { return KEY.length() > 0 && DB.length() > 0; }

    static boolean googleReady() { return ready() && WEB_CLIENT.length() > 0; }

    /** 서버가 거절했거나 인터넷이 안 될 때 */
    static final class Err extends Exception {
        final String code;      // EMAIL_EXISTS 같은 Firebase 이유, 인터넷 문제면 NETWORK
        final int http;

        Err(String code, int http, String raw) {
            super(code + (raw == null || raw.isEmpty() ? "" : ": " + raw));
            this.code = code;
            this.http = http;
        }

        boolean network() { return "NETWORK".equals(code); }

        /** 다시 로그인해야 하는 경우 (열쇠가 만료·취소됨, 계정이 지워짐) */
        boolean loggedOut() {
            return code.equals("INVALID_REFRESH_TOKEN") || code.equals("TOKEN_EXPIRED") || code.equals("USER_NOT_FOUND")
                    || code.equals("USER_DISABLED") || code.equals("INVALID_ID_TOKEN") || code.equals("MISSING_REFRESH_TOKEN");
        }

        /** 사람에게 보여 줄 말 */
        String say() {
            switch (code) {
                case "NETWORK": return "인터넷 연결을 확인해 주세요";
                case "EMAIL_EXISTS": return "이미 있는 아이디예요. 다른 아이디를 써 주세요";
                case "INVALID_LOGIN_CREDENTIALS":
                case "EMAIL_NOT_FOUND":
                case "INVALID_PASSWORD":
                    return "아이디나 비밀번호가 맞지 않아요";
                case "WEAK_PASSWORD": return "비밀번호는 6자 이상이어야 해요";
                case "INVALID_EMAIL": return "아이디는 영어 소문자·숫자로 4~20자예요";
                case "TOO_MANY_ATTEMPTS_TRY_LATER": return "너무 여러 번 시도했어요. 잠시 뒤에 다시 해 주세요";
                case "USER_DISABLED": return "사용이 멈춘 계정이에요";
                case "FEDERATED_USER_ID_ALREADY_LINKED": return "이 구글 계정은 이미 다른 계정에 연결돼 있어요";
                case "CREDENTIAL_TOO_OLD_LOGIN_AGAIN": return "보안을 위해 다시 로그인한 뒤 해 주세요";
                case "OPERATION_NOT_ALLOWED": return "Firebase에서 이 로그인 방법이 꺼져 있어요";
                case "CONFIGURATION_NOT_FOUND": return "Firebase Authentication이 아직 시작되지 않았어요";
                case "BAD_KEY": return "서버 열쇠(API 키)가 맞지 않아요";
                case "INVALID_IDP_RESPONSE": return "구글 로그인 정보를 확인하지 못했어요";
                case "PERMISSION_DENIED": return "서버가 기록을 막았어요. Realtime Database 규칙을 확인해 주세요";
                case "DB_NOT_FOUND": return "데이터베이스 주소를 찾지 못했어요";
                case "INVALID_REFRESH_TOKEN":
                case "TOKEN_EXPIRED":
                case "USER_NOT_FOUND":
                case "INVALID_ID_TOKEN":
                case "MISSING_REFRESH_TOKEN":
                    return "로그인이 풀렸어요. 다시 로그인해 주세요";
                default:
                    return "서버 오류가 났어요 (" + code + ")";
            }
        }
    }

    static final class Resp {
        int code;
        String body = "";
        String etag = "";
    }

    static int connectTimeout = 10000, readTimeout = 20000;

    static Resp http(String method, String url, String body, String type, Map<String, String> headers) throws Err {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod(method);
            con.setConnectTimeout(connectTimeout);
            con.setReadTimeout(readTimeout);
            con.setUseCaches(false);
            con.setRequestProperty("Accept", "application/json");
            if (headers != null) for (Map.Entry<String, String> h : headers.entrySet()) con.setRequestProperty(h.getKey(), h.getValue());
            if (body != null) {
                byte[] b = body.getBytes(StandardCharsets.UTF_8);
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", type == null ? "application/json; charset=utf-8" : type);
                con.setFixedLengthStreamingMode(b.length);
                try (OutputStream out = con.getOutputStream()) { out.write(b); }
            }
            Resp r = new Resp();
            r.code = con.getResponseCode();
            String et = con.getHeaderField("ETag");
            r.etag = et == null ? "" : et;
            InputStream in = r.code >= 400 ? con.getErrorStream() : con.getInputStream();
            r.body = in == null ? "" : read(in);
            return r;
        } catch (IOException e) {
            throw new Err("NETWORK", 0, e.getClass().getSimpleName());
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private static String read(InputStream in) throws IOException {
        try (InputStream x = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = x.read(b)) > 0) out.write(b, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** 서버가 보낸 오류를 짧은 이유 글자로 */
    static Err error(Resp r) {
        Map<String, Object> m = Json.objOf(r.body);
        Object e = m == null ? null : m.get("error");
        String msg = e instanceof String ? (String) e : Json.s(Json.obj(e), "message");
        if (msg.isEmpty() && m != null) msg = Json.s(m, "error_description");
        String code;
        if (msg.startsWith("API key not valid") || msg.startsWith("API_KEY_INVALID")) code = "BAD_KEY";
        else if (r.code == 401 && msg.toLowerCase(java.util.Locale.ROOT).contains("permission denied")) code = "PERMISSION_DENIED";
        else if (r.code == 404 && msg.isEmpty()) code = "DB_NOT_FOUND";
        else if (msg.isEmpty()) code = "HTTP_" + r.code;
        else {
            code = msg.split("[ :]", 2)[0].trim();
            if (code.isEmpty()) code = "HTTP_" + r.code;
        }
        return new Err(code, r.code, msg);
    }

    // ───────── 로그인 ─────────

    /** Identity Toolkit 부르기 (accounts:signUp 같은 것) */
    static Map<String, Object> auth(String op, Map<String, Object> body) throws Err {
        Resp r = http("POST", AUTH + op + "?key=" + enc(KEY), Json.str(body), null, null);
        if (r.code != 200) throw error(r);
        Map<String, Object> m = Json.objOf(r.body);
        if (m == null) throw new Err("BAD_RESPONSE", r.code, "");
        return m;
    }

    static Map<String, Object> body(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put((String) kv[i], kv[i + 1]);
        return m;
    }

    /** 새 열쇠 받기: {id_token, refresh_token, expires_in, user_id} */
    static Map<String, Object> refresh(String refreshToken) throws Err {
        String form = "grant_type=refresh_token&refresh_token=" + enc(refreshToken);
        Resp r = http("POST", TOKEN + "?key=" + enc(KEY), form, "application/x-www-form-urlencoded", null);
        if (r.code != 200) throw error(r);
        Map<String, Object> m = Json.objOf(r.body);
        if (m == null) throw new Err("BAD_RESPONSE", r.code, "");
        return m;
    }

    // ───────── 기록 ─────────

    static String userUrl(String uid, String idToken) {
        String base = DB.endsWith("/") ? DB.substring(0, DB.length() - 1) : DB;
        return base + "/users/" + enc(uid) + ".json?auth=" + enc(idToken);
    }

    static final class Got {
        Map<String, Object> value;   // 없으면 null
        String etag;
    }

    /** 내 기록 받기 (ETag를 같이 받아서, 올릴 때 그사이 바뀌었는지 알아요) */
    static Got get(String uid, String idToken) throws Err {
        Map<String, String> h = new LinkedHashMap<>();
        h.put("X-Firebase-ETag", "true");
        Resp r = http("GET", userUrl(uid, idToken), null, null, h);
        if (r.code != 200) throw error(r);
        Got g = new Got();
        g.value = Json.objOf(r.body);
        g.etag = r.etag;
        return g;
    }

    /** 내 기록 올리기. 그사이 다른 기기가 먼저 올렸으면(ETag가 다르면) false */
    static boolean put(String uid, String idToken, String json, String etag) throws Err {
        Map<String, String> h = new LinkedHashMap<>();
        if (etag != null && !etag.isEmpty()) h.put("if-match", etag);
        Resp r = http("PUT", userUrl(uid, idToken), json, null, h);
        if (r.code == 412) return false;
        if (r.code != 200) throw error(r);
        return true;
    }

    static String enc(String s) {
        try {
            return URLEncoder.encode(s == null ? "" : s, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            return "";
        }
    }
}
