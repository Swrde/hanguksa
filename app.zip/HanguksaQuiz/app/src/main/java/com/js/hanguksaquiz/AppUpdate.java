package com.js.hanguksaquiz;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/**
 * 앱 자체 업데이트 (플레이스토어처럼).
 * GitHub Actions가 새 APK를 만들면 Release에 version.json도 함께 올려요.
 * 앱을 열 때 그 파일을 보고 새 버전이 있으면 물어본 뒤, 앱 안에서 받아서 바로 설치해요.
 * 안드로이드 12 이상에서는 보통 설치 버튼 없이 깔리고, 앱이 잠깐 닫혔다가 다시 열려요.
 * (휴대폰이 허락하지 않으면 설치 버튼이 한 번 뜰 수 있어요)
 */
final class AppUpdate {

    interface Found { void found(Info info); }

    static final class Info {
        int code;
        String name;
        String apkUrl;
    }

    private static final String ACTION_DONE = "com.js.hanguksaquiz.UPDATE_DONE";
    private static final long AUTO_GAP = 6L * 60 * 60 * 1000;   // 자동 확인은 6시간에 한 번
    private static boolean busy = false;

    private AppUpdate() {}

    static String base() {
        return BuildConfig.UPDATE_URL;   // https://github.com/<저장소>/releases/latest
    }

    /** 앱을 열 때: 6시간에 한 번 확인하고, 새 버전이 있으면 업데이트할지 물어봐요 */
    static void autoCheck(Activity a) {
        if (base().length() == 0) return;
        SharedPreferences p = Quiz.prefs(a);
        long now = System.currentTimeMillis();
        if (now - p.getLong("upd_checked", 0) < AUTO_GAP) return;
        p.edit().putLong("upd_checked", now).apply();
        check(a, info -> {
            if (info == null || a.isFinishing()) return;
            // '나중에'를 누른 버전은 다음 버전이 나올 때까지 다시 묻지 않아요
            if (Quiz.prefs(a).getInt("upd_skip", 0) == info.code) return;
            ask(a, info);
        }, null);
    }

    /** 설정의 '새 버전 받기' 버튼: 바로 확인해요 */
    static void manualCheck(Activity a) {
        if (base().length() == 0) return;
        toast(a, "확인하는 중…");
        check(a, info -> {
            if (a.isFinishing()) return;
            if (info == null) toast(a, "이미 최신 버전이에요");
            else ask(a, info);
        }, () -> toast(a, "확인하지 못했어요. 인터넷 연결을 확인해 주세요"));
    }

    private static void check(Context c, Found cb, Runnable failed) {
        final Handler ui = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            Info info = null;
            boolean ok = true;
            try {
                info = fetchInfo();
            } catch (Exception e) {
                ok = false;
            }
            final Info r = info;
            final boolean fine = ok;
            ui.post(() -> {
                if (!fine) { if (failed != null) failed.run(); }
                else cb.found(r);
            });
        }).start();
    }

    /** Release의 version.json 읽기. 지금보다 새 버전일 때만 돌려줘요 (없으면 null) */
    static Info fetchInfo() throws Exception {
        String text = new String(get(base() + "/download/version.json", 64 * 1024), "UTF-8");
        return parse(text, BuildConfig.VERSION_CODE, base());
    }

    /** version.json 내용 해석 (테스트하기 쉽게 따로 떼 놓았어요) */
    static Info parse(String text, int current, String base) {
        Map<String, Object> m = Json.objOf(text);
        if (m == null) return null;
        int code = (int) Json.l(m, "code");
        String apk = Json.s(m, "apk");
        if (code <= current || apk.isEmpty() || apk.contains("/") || !apk.endsWith(".apk")) return null;
        Info i = new Info();
        i.code = code;
        i.name = Json.s(m, "name").isEmpty() ? "1." + code : Json.s(m, "name");
        // .../releases/latest → .../releases/download/<태그>/<파일>
        String root = base.endsWith("/latest") ? base.substring(0, base.length() - "/latest".length()) : base;
        String tag = Json.s(m, "tag").isEmpty() ? "v" + i.name : Json.s(m, "tag");
        i.apkUrl = root + "/download/" + Uri.encode(tag) + "/" + Uri.encode(apk);
        return i;
    }

    private static void ask(Activity a, Info info) {
        new AlertDialog.Builder(a)
                .setTitle("새 버전 " + info.name)
                .setMessage("새 버전이 나왔어요. 지금 업데이트할까요?\n\n"
                        + "앱이 잠깐 닫혔다가 다시 열려요. 공부 기록과 설정은 그대로 남아요.")
                .setPositiveButton("업데이트", (d, w) -> start(a, info))
                .setNegativeButton("나중에", (d, w) -> Quiz.prefs(a).edit().putInt("upd_skip", info.code).apply())
                .show();
    }

    /** 처음 한 번: '이 앱에서 설치 허용'을 켜야 앱이 스스로 업데이트할 수 있어요 */
    private static boolean allowed(Activity a) {
        if (a.getPackageManager().canRequestPackageInstalls()) return true;
        new AlertDialog.Builder(a)
                .setTitle("설치 허용이 필요해요 (처음 한 번)")
                .setMessage("다음 화면에서 '이 출처 허용'을 켜고 돌아와 주세요. 그다음부터는 앱이 알아서 업데이트해요.")
                .setPositiveButton("설정 열기", (d, w) -> {
                    try {
                        a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + a.getPackageName())));
                    } catch (Exception e) {
                        toast(a, "설정을 열 수 없어요");
                    }
                })
                .setNegativeButton("취소", null)
                .show();
        return false;
    }

    private static void start(Activity a, Info info) {
        if (!allowed(a)) return;
        if (busy) { toast(a, "이미 받는 중이에요"); return; }
        busy = true;
        toast(a, "새 버전을 받는 중이에요…");
        final Context app = a.getApplicationContext();
        final Handler ui = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            String err = null;
            try {
                File f = new File(app.getCacheDir(), "update.apk");
                download(info.apkUrl, f);
                // 받은 파일이 정말 이 앱의 더 새 버전인지 확인해요 (서명은 설치할 때 안드로이드가 확인해요)
                PackageInfo pi = app.getPackageManager().getPackageArchiveInfo(f.getPath(), 0);
                if (pi == null || !app.getPackageName().equals(pi.packageName)
                        || pi.getLongVersionCode() <= BuildConfig.VERSION_CODE) {
                    f.delete();
                    throw new Exception("bad apk");
                }
                Quiz.prefs(app).edit().putBoolean("upd_reopen", true).commit();
                install(app, f);
            } catch (Exception e) {
                err = "업데이트를 받지 못했어요. 인터넷 연결을 확인해 주세요";
            }
            final String msg = err;
            ui.post(() -> {
                busy = false;
                if (msg != null) toast(app, msg);
            });
        }).start();
    }

    private static void install(Context c, File apk) throws Exception {
        PackageInstaller pi = c.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        sp.setAppPackageName(c.getPackageName());
        sp.setSize(apk.length());
        if (Build.VERSION.SDK_INT >= 31) {
            // 앱이 자기 자신을 업데이트할 때는 설치 버튼 없이 깔 수 있어요 (안드로이드 12+)
            sp.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
        }
        if (Build.VERSION.SDK_INT >= 34) {
            sp.setPackageSource(PackageInstaller.PACKAGE_SOURCE_DOWNLOADED_FILE);
        }
        int id = pi.createSession(sp);
        try (PackageInstaller.Session s = pi.openSession(id)) {
            try (InputStream in = new FileInputStream(apk); OutputStream out = s.openWrite("app.apk", 0, apk.length())) {
                byte[] buf = new byte[65536];
                int k;
                while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
                s.fsync(out);
            }
            Intent done = new Intent(c, Receiver.class).setAction(ACTION_DONE);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent pend = PendingIntent.getBroadcast(c, id, done, flags);
            s.commit(pend.getIntentSender());
        }
    }

    /** 설치 결과: 휴대폰이 확인을 원하면 설치 화면을 띄우고, 실패하면 알려 줘요 */
    public static class Receiver extends BroadcastReceiver {
        @Override
        @SuppressWarnings("deprecation")
        public void onReceive(Context c, Intent intent) {
            if (!ACTION_DONE.equals(intent.getAction())) return;
            int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
            if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try { c.startActivity(confirm); } catch (Exception ignored) { }
                }
            } else if (status != PackageInstaller.STATUS_SUCCESS) {
                Quiz.prefs(c).edit().remove("upd_reopen").apply();
                if (status != PackageInstaller.STATUS_FAILURE_ABORTED) {
                    toast(c, "업데이트를 설치하지 못했어요");
                }
            }
            new File(c.getCacheDir(), "update.apk").delete();
        }
    }

    /** 업데이트가 끝나면(앱이 바뀐 직후) 앱을 다시 열어 줘요 */
    static void afterReplaced(Context c) {
        SharedPreferences p = Quiz.prefs(c);
        new File(c.getCacheDir(), "update.apk").delete();
        p.edit().remove("upd_skip").apply();
        if (!p.getBoolean("upd_reopen", false)) return;
        p.edit().remove("upd_reopen").apply();
        try {
            c.startActivity(new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {
        }
    }

    // ───────── 인터넷 ─────────

    private static HttpURLConnection open(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(30000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "HanguksaQuiz");
        int code = con.getResponseCode();
        if (code != 200) throw new Exception("http " + code);
        return con;
    }

    private static byte[] get(String url, int max) throws Exception {
        HttpURLConnection con = open(url);
        try (InputStream in = con.getInputStream()) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int k;
            while ((k = in.read(buf)) > 0) {
                out.write(buf, 0, k);
                if (out.size() > max) throw new Exception("too big");
            }
            return out.toByteArray();
        }
    }

    private static void download(String url, File f) throws Exception {
        HttpURLConnection con = open(url);
        File tmp = new File(f.getPath() + ".part");
        try (InputStream in = con.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[65536];
            int k;
            while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
        }
        if (!tmp.renameTo(f)) { tmp.delete(); throw new Exception("rename"); }
    }

    private static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }
}
