package com.js.hanguksaquiz;

import android.content.Context;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 랭킹: 서버(Realtime Database)의 ranks/내 uid 에 {n: 이름, s: 진도 점수, d: 과목별, t: 올린 때}를 두고,
 * ranks 전체를 받아 점수 순으로 보여 줘요.
 * Firebase 규칙에서 ranks 는 로그인한 사람 모두 읽기, 자기 칸만 쓰기로 열어 둬야 해요.
 */
final class Rank {
    private Rank() {}

    static String url(String path, String idToken) {
        String base = Fb.DB.endsWith("/") ? Fb.DB.substring(0, Fb.DB.length() - 1) : Fb.DB;
        return base + "/ranks" + path + ".json?auth=" + Fb.enc(idToken);
    }

    /** 내 점수 올리기. name은 20자까지 (비우면 '친구'), score는 0~1000 */
    static void submit(Context c, String name, double score, Object detail) throws Fb.Err {
        String uid = Account.uid(c), tok = Account.idToken(c);
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) n = "친구"; // 진짜 이름·메일이 남에게 보이지 않게, 비우면 '친구'
        if (n.length() > 20) n = n.substring(0, 20);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("n", n);
        m.put("s", Math.max(0, Math.min(1000, Math.round(score * 10) / 10.0)));
        if (detail != null) m.put("d", detail);
        m.put("t", System.currentTimeMillis());
        Fb.Resp r = Fb.http("PUT", url("/" + Fb.enc(uid), tok), Json.str(m), null, null);
        if (r.code != 200) throw Fb.error(r);
    }

    /** 랭킹 전체 (서버 글 그대로) */
    static String list(Context c) throws Fb.Err {
        Fb.Resp r = Fb.http("GET", url("", Account.idToken(c)), null, null, null);
        if (r.code != 200) throw Fb.error(r);
        return r.body == null || r.body.isEmpty() ? "null" : r.body;
    }
}
