package com.js.hanguksaquiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** 잠금화면 위에 뜨는 한 문제 화면. 문제를 풀고 닫으면 원래 잠금화면으로 돌아가요. */
public class LockQuizActivity extends Activity {

    private final Random rnd = new Random();
    private Quiz.Question q;
    private boolean answered;
    private final List<TextView> optionViews = new ArrayList<>();
    private TextView result;
    private TextView closeBtn;
    private TextView skipBtn;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        }
        q = Quiz.next(this, rnd);
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // 화면이 다시 켜졌는데 아직 이 문제가 떠 있으면, 같은 문제를 그대로 보여 줘요
        if (answered) {
            q = Quiz.next(this, rnd);
            build();
        }
    }

    private void build() {
        answered = false;
        optionViews.clear();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.D_BG);
        int pad = Ui.dp(this, 20);
        root.setPadding(pad, Ui.dp(this, 12), pad, Ui.dp(this, 16));

        // 위: 시간과 기록
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView clock = Ui.text(this, new SimpleDateFormat("a h:mm", Locale.KOREA).format(new Date()), 15, Ui.D_SOFT, false);
        top.addView(clock, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        int st = Quiz.streak(this);
        TextView rec = Ui.text(this, st > 0 ? "연속 정답 " + st : "오늘도 한 문제", 14, Ui.D_SOFT, false);
        top.addView(rec);
        root.addView(top);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_VERTICAL);
        sv.addView(body, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        if (q == null) {
            TextView t = Ui.text(this, "고른 범위에 낼 문제가 없어요.\n앱 설정의 '문제 범위'나 '문제 종류'를 바꿔 주세요.", 18, Ui.D_INK, true);
            t.setLineSpacing(0, 1.25f);
            body.addView(t);
        } else {
            // 문제 카드
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(Ui.box(this, Ui.D_CARD, Ui.D_RULE, 8));
            int cp = Ui.dp(this, 18);
            card.setPadding(cp, cp, cp, cp);

            card.addView(Ui.text(this, q.tag, 13, Ui.D_PEN, true));
            int big = q.type == Quiz.TYPE_WHEN ? 23 : q.type == Quiz.TYPE_ORDER ? 20 : 30;
            TextView prompt = Ui.text(this, q.prompt, big, Ui.D_INK, true);
            prompt.setLineSpacing(0, 1.2f);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            pp.topMargin = Ui.dp(this, 10);
            card.addView(prompt, pp);
            // 순서 문제: ㄱ·ㄴ·ㄷ·ㄹ 사건
            for (String line : q.lines) {
                TextView lt = Ui.text(this, line, 17, Ui.D_INK, false);
                lt.setLineSpacing(0, 1.2f);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.topMargin = Ui.dp(this, 8);
                card.addView(lt, lp);
            }
            if (q.ask.length() > 0) {
                TextView ask = Ui.text(this, q.ask, 15, Ui.D_SOFT, false);
                LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                ap.topMargin = Ui.dp(this, 8);
                card.addView(ask, ap);
            }
            body.addView(card);

            // 보기 4개
            for (int i = 0; i < q.options.size(); i++) {
                final int pick = i;
                String label = (i + 1) + "   " + q.options.get(i);
                TextView o = Ui.button(this, label, Ui.D_CARD, Ui.D_RULE, Ui.D_INK);
                o.setTypeface(android.graphics.Typeface.DEFAULT);
                o.setTextSize(q.type == Quiz.TYPE_WHAT ? 16 : 18);
                o.setOnClickListener(v -> choose(pick));
                LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                op.topMargin = Ui.dp(this, 10);
                body.addView(o, op);
                optionViews.add(o);
            }

            result = Ui.text(this, "", 16, Ui.D_INK, false);
            result.setLineSpacing(0, 1.25f);
            result.setVisibility(View.GONE);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rp.topMargin = Ui.dp(this, 14);
            body.addView(result, rp);
        }

        // 아래: 닫기 / 건너뛰기
        closeBtn = Ui.button(this, "닫기", Ui.D_INK, 0, Ui.D_BG);
        closeBtn.setGravity(Gravity.CENTER);
        closeBtn.setOnClickListener(v -> finish());
        closeBtn.setVisibility(q == null ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams cbp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cbp.topMargin = Ui.dp(this, 12);
        root.addView(closeBtn, cbp);

        skipBtn = Ui.text(this, "건너뛰기", 15, Ui.D_SOFT, false);
        skipBtn.setGravity(Gravity.CENTER);
        int sp = Ui.dp(this, 12);
        skipBtn.setPadding(sp, sp, sp, sp);
        skipBtn.setOnClickListener(v -> finish());
        skipBtn.setVisibility(q == null ? View.GONE : View.VISIBLE);
        root.addView(skipBtn, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        Ui.edgeToEdge(this, root, false);
    }

    private void choose(int pick) {
        if (answered || q == null) return;
        answered = true;
        boolean ok = pick == q.answer;
        Quiz.record(this, q.key, ok);

        for (int i = 0; i < optionViews.size(); i++) {
            TextView o = optionViews.get(i);
            o.setClickable(false);
            if (i == q.answer) {
                o.setBackground(Ui.box(this, 0x2A7DD3A0, Ui.D_OK, 6));
                o.setTextColor(Ui.D_OK);
                o.setText("✓  " + q.options.get(i));
            } else if (i == pick) {
                o.setBackground(Ui.box(this, 0x26FF8A80, Ui.D_PEN, 6));
                o.setTextColor(Ui.D_PEN);
                o.setText("✕  " + q.options.get(i));
            } else {
                o.setTextColor(Ui.D_RULE);
            }
        }

        String head = ok ? "정답이에요! " + (Quiz.streak(this) > 1 ? "연속 " + Quiz.streak(this) + "문제째예요." : "")
                         : "아쉬워요. 이 문제는 나중에 다시 나와요.";
        result.setText(head + "\n" + q.explain);
        result.setTextColor(ok ? Ui.D_OK : Ui.D_INK);
        result.setVisibility(View.VISIBLE);
        skipBtn.setVisibility(View.GONE);
        closeBtn.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        // 홈으로 나가거나 화면이 꺼지면 문제 화면을 정리해요
        if (!isChangingConfigurations()) finish();
    }
}
