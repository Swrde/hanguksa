package com.js.hanguksaquiz;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * 잠금화면 위에 뜨는 한 문제 화면.
 * 휴대폰 배경화면이 비치고(안드로이드 12부터는 흐리게), 그 위에 어두운 유리판(문제)과 유리 칸(보기)이 떠요.
 * 풀고 닫으면 원래 잠금화면으로 돌아가요.
 */
public class LockQuizActivity extends Activity {

    private static final int WHITE = 0xFFFFFFFF, SOFT = 0xB3FFFFFF, DIM = 0x66FFFFFF;
    private static final int OK = 0xFF7EE79F, BAD = 0xFFFF8A80;

    private final Random rnd = new Random();
    private Quiz.Question q;
    private boolean answered;
    private final List<TextView> optionViews = new ArrayList<>();
    private TextView resultHead, resultText, closeBtn, skipBtn, todayText;
    private LinearLayout resultPlate;
    private Glass.Ring todayRing;
    private ScrollView scroll;
    private float tileSp = 22;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        }
        // 배경화면이 비치게: 테마(windowShowWallpaper)로 배경화면을 뒤에 깔고, 창 바탕은 투명하게
        getWindow().setBackgroundDrawable(new ColorDrawable(0x00000000));
        // 안드로이드 12부터: 뒤의 배경화면을 흐리게 (휴대폰이 지원하지 않으면 그냥 어둡게만 보여요)
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                getWindow().setBackgroundBlurRadius(dp(36));
            } catch (Throwable ignored) {
            }
        }
        q = Quiz.next(this, rnd);
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // 화면이 다시 켜졌는데 아직 이 문제가 떠 있으면, 같은 문제를 그대로 보여 줘요
        if (answered) {
            q = Quiz.next(this, rnd);
            build();
        }
    }

    private int dp(float v) { return Ui.dp(this, v); }

    private LinearLayout.LayoutParams lp(int w, int h, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        return p;
    }

    private void build() {
        answered = false;
        optionViews.clear();
        final int M = ViewGroup.LayoutParams.MATCH_PARENT, W = ViewGroup.LayoutParams.WRAP_CONTENT;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Glass.lockScrim());
        root.setPadding(dp(18), dp(14), dp(18), dp(16));

        // 위: 시간 / 오늘 푼 문제 링
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView clock = Ui.text(this, new SimpleDateFormat("a h:mm", Locale.KOREA).format(new Date()), 15, WHITE, true);
        top.addView(clock, new LinearLayout.LayoutParams(0, W, 1));
        LinearLayout pill = new LinearLayout(this);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(Glass.lockPlate(this, 999));
        pill.setPadding(dp(8), dp(5), dp(12), dp(5));
        todayRing = new Glass.Ring(this, Quiz.C_KS, 3.5f);
        pill.addView(todayRing, new LinearLayout.LayoutParams(dp(20), dp(20)));
        todayText = Ui.text(this, "", 14, WHITE, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(W, W);
        tp.leftMargin = dp(7);
        pill.addView(todayText, tp);
        top.addView(pill);
        root.addView(top);
        paintToday();

        ScrollView sv = new ScrollView(this);
        scroll = sv;
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body, new ScrollView.LayoutParams(M, W));
        root.addView(sv, new LinearLayout.LayoutParams(M, 0, 1));

        if (q == null) {
            LinearLayout plate = plate();
            TextView t = Ui.text(this, "켜 둔 과목에서 낼 문제가 없어요.\n앱의 '잠금화면 문제' 설정에서 과목이나 범위를 바꿔 주세요.", 18, WHITE, true);
            t.setLineSpacing(0, 1.3f);
            plate.addView(t);
            body.addView(plate, lp(M, W, 40));
        } else {
            // 문제: 유리판 하나에
            LinearLayout plate = plate();
            TextView tag = Ui.text(this, q.tag, 13, q.color != 0 ? q.color : Quiz.C_KS, true);
            plate.addView(tag);
            TextView prompt = Ui.text(this, q.prompt, promptSize(), WHITE, true);
            prompt.setLineSpacing(0, 1.18f);
            prompt.setLetterSpacing(-0.02f);
            plate.addView(prompt, lp(M, W, 6));
            // 순서 문제: ㄱ·ㄴ·ㄷ·ㄹ 사건
            for (String line : q.lines) {
                TextView lt = Ui.text(this, line, 17, WHITE, false);
                lt.setLineSpacing(0, 1.25f);
                plate.addView(lt, lp(M, W, 8));
            }
            if (q.ask.length() > 0) plate.addView(Ui.text(this, q.ask, 16, SOFT, false), lp(M, W, 10));
            body.addView(plate, lp(M, W, 24));

            // 보기: 짧으면 2×2 큰 칸, 길면 한 줄씩
            boolean grid = q.options.size() == 4;
            int longest = 0;
            for (String o : q.options) longest = Math.max(longest, o.length());
            if (longest > 8) grid = false;
            tileSp = longest <= 4 ? 22 : longest <= 6 ? 20 : 18;   // 칸 안에서 두 줄을 넘지 않게
            if (grid) {
                for (int row = 0; row < 2; row++) {
                    LinearLayout r = new LinearLayout(this);
                    for (int col = 0; col < 2; col++) {
                        int i = row * 2 + col;
                        TextView o = option(i, true);
                        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(0, dp(76), 1);
                        if (col == 1) op.leftMargin = dp(10);
                        r.addView(o, op);
                    }
                    body.addView(r, lp(M, W, row == 0 ? 14 : 10));
                }
            } else {
                for (int i = 0; i < q.options.size(); i++) body.addView(option(i, false), lp(M, W, i == 0 ? 14 : 8));
            }

            // 결과: 고르면 나타나는 유리판
            resultPlate = plate();
            resultHead = Ui.text(this, "", 26, OK, true);
            resultPlate.addView(resultHead);
            resultText = Ui.text(this, "", 15, 0xD9FFFFFF, false);
            resultText.setLineSpacing(0, 1.4f);
            resultPlate.addView(resultText, lp(M, W, 6));
            resultPlate.setVisibility(View.GONE);
            body.addView(resultPlate, lp(M, W, 14));
        }

        // 아래: 닫기(유리 알약) / 건너뛰기
        closeBtn = Ui.text(this, "닫기", 17, WHITE, true);
        closeBtn.setGravity(Gravity.CENTER);
        closeBtn.setMinHeight(dp(54));
        closeBtn.setBackground(Glass.lockPlate(this, 27));
        closeBtn.setOnClickListener(v -> finish());
        closeBtn.setVisibility(q == null ? View.VISIBLE : View.GONE);
        root.addView(closeBtn, lp(M, W, 12));

        skipBtn = Ui.text(this, "건너뛰기", 15, SOFT, false);
        skipBtn.setGravity(Gravity.CENTER);
        skipBtn.setMinHeight(dp(48));
        skipBtn.setOnClickListener(v -> finish());
        skipBtn.setVisibility(q == null ? View.GONE : View.VISIBLE);
        root.addView(skipBtn, lp(M, W, 8));

        setContentView(root);
        Ui.edgeToEdge(this, root, false);
    }

    /** 어두운 유리판 */
    private LinearLayout plate() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackground(Glass.lockPlate(this, 26));
        p.setPadding(dp(20), dp(18), dp(20), dp(20));
        return p;
    }

    /** 문제 글자 크기: 짧은 사건 이름·연도·단어는 크게, 긴 문장은 읽기 좋게 */
    private float promptSize() {
        int n = q.prompt.length();
        if (q.promptSp >= 28) return 38;                // 영어 단어 하나
        if (q.type == Quiz.TYPE_WHAT) return 42;          // 연도
        if (q.type == Quiz.TYPE_ORDER) return 21;
        if (n <= 12) return 36;
        if (n <= 28) return 28;
        if (n <= 60) return 21;
        return 18;
    }

    private TextView option(int i, boolean tile) {
        final int pick = i;
        TextView o = Ui.text(this, q.options.get(i), tile ? tileSp : 17, WHITE, tile);
        o.setGravity(tile ? Gravity.CENTER : Gravity.CENTER_VERTICAL);
        if (tile) {
            o.setPadding(dp(8), 0, dp(8), 0);
        } else {
            o.setMinHeight(dp(56));
            o.setPadding(dp(18), dp(12), dp(16), dp(12));
            o.setLineSpacing(0, 1.2f);
        }
        o.setBackground(Glass.lockPlate(this, tile ? 22 : 18));
        o.setOnClickListener(v -> choose(pick));
        optionViews.add(o);
        return o;
    }

    private void paintToday() {
        int n = Quiz.today(this);
        todayRing.set(n / (float) Quiz.DAY_GOAL);
        todayText.setText(n <= Quiz.DAY_GOAL ? "오늘 " + n + "/" + Quiz.DAY_GOAL : "오늘 " + n + "문제");
    }

    private void choose(int pick) {
        if (answered || q == null) return;
        answered = true;
        boolean ok = pick == q.answer;
        Quiz.record(this, q.key, ok);
        paintToday();

        for (int i = 0; i < optionViews.size(); i++) {
            TextView o = optionViews.get(i);
            o.setClickable(false);
            boolean tile = o.getGravity() == Gravity.CENTER;
            if (i == q.answer) {
                o.setBackground(Glass.panel(this, 0x6630D158, 0xCC30D158, tile ? 22 : 18));
                o.setText("✓ " + q.options.get(i));
                o.setTypeface(Typeface.DEFAULT_BOLD);
            } else if (i == pick) {
                o.setBackground(Glass.panel(this, 0x59FF453A, 0xCCFF6961, tile ? 22 : 18));
                o.setText("✕ " + q.options.get(i));
            } else {
                o.setTextColor(DIM);
            }
        }

        int st = Quiz.streak(this);
        resultHead.setText(ok ? (st > 1 ? "정답! 연속 " + st + "문제" : "정답!") : "아쉬워요");
        resultHead.setTextColor(ok ? OK : BAD);
        resultHead.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        resultText.setText((ok ? "" : "이 문제는 나중에 다시 나와요.\n") + q.explain);
        resultPlate.setVisibility(View.VISIBLE);
        skipBtn.setVisibility(View.GONE);
        closeBtn.setVisibility(View.VISIBLE);
        // 해설이 화면 밖에 있으면 보이게 내려 줘요
        if (scroll != null) scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, resultPlate.getTop() - dp(120))));
    }

    @Override
    protected void onStop() {
        super.onStop();
        // 홈으로 나가거나 화면이 꺼지면 문제 화면을 정리해요
        if (!isChangingConfigurations()) finish();
    }
}
