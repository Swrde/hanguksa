package com.js.hanguksaquiz;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * 기기끼리 공부 기록 맞추기.
 *
 * 서버(Realtime Database)의 users/내 uid 아래에 기록 한 벌을 두고, 앱을 열고 닫을 때와 잠금화면에서 푼 뒤에 맞춰요.
 * 1) 서버 기록을 받아 2) 이 기기 기록과 합치고(SyncMerge) 3) 바뀐 것은 이 기기에 넣고 4) 합친 것을 서버에 올려요.
 * 올리는 사이에 다른 기기가 먼저 올렸으면(ETag가 다르면) 처음부터 다시 해요.
 *
 * 공부 화면이 열려 있을 때 다른 기기 기록을 넣으려면, 화면이 들고 있던 기록이 나중에 덮어쓰지 않게
 * 화면을 잠깐 비운 뒤(Host.unloadPage) 넣고 다시 열어요(Host.reloadPage).
 */
final class Sync {
    private Sync() {}

    // ───────── 무엇을 맞출지 ─────────

    /** 기기마다 따로 두는 공부 화면 값: 화면 모드, 확대 크기, 마지막으로 연 탭·과목, 접은 메뉴 */
    static boolean localWebKey(String k) {
        return k.startsWith("__") || k.equals("app-theme") || k.equals("k2-subject") || k.equals("en-mode")
                || k.endsWith("-zoom") || k.endsWith("-tab") || k.endsWith("-fold");
    }

    /** 맞추는 잠금화면 값: 과목·범위·문제 종류 고르기와 푼 기록. (켜기, 얼마나 자주, 마지막에 뜬 때는 기기마다 따로) */
    private static final Set<String> P_KEYS = new HashSet<>(Arrays.asList(
            Quiz.S_KS, Quiz.S_SA, Quiz.S_EN, "rmode", "rchs", "rp0", "rp1", "ry0", "ry1",
            "t_order", "t_text", "t_what", "t_when", "world", "sa_units", "en_days", Quiz.EN_UNKNOWN,
            "wrong", "total", "correct", "streak", "day", "day_n", Quiz.RV, Quiz.UST));

    static boolean syncPref(String k) { return P_KEYS.contains(k) || k.startsWith("sa_c_") || k.startsWith("en_k"); }

    private static final int MAX_VALUE = 512 * 1024;            // 이보다 큰 값은 안 올려요 (그럴 일은 없지만)
    private static final long TOMB_DAYS = 120;                  // '지워짐' 표시를 남겨 두는 날 수

    // ───────── 공부 화면과 이야기하기 ─────────

    /** 공부 화면(MainActivity)이 열려 있는 동안 등록돼요 */
    interface Host {
        /** 공부 화면을 잠깐 빈 화면으로 바꿔요. 화면이 들고 있던 기록을 다 내놓으면 ready를 불러요 */
        void unloadPage(Runnable ready);

        /** 빈 화면에서 지울 기록을 지우고 공부 화면을 다시 열어요 */
        void reloadPage(List<String> deleted, boolean fromOther);
    }

    private static final Object HOST_LOCK = new Object();
    private static WeakReference<Host> host = new WeakReference<>(null);

    static void setHost(Host h) { synchronized (HOST_LOCK) { host = new WeakReference<>(h); } }

    static void clearHost(Host h) { synchronized (HOST_LOCK) { if (host.get() == h) host = new WeakReference<>(null); } }

    private static Host host() { synchronized (HOST_LOCK) { return host.get(); } }

    // ───────── 결과 ─────────

    static final int OK = 0, OFF = 1, FAIL = 2, LOGGED_OUT = 3;

    static final class Result {
        final int code;
        final String msg;
        final boolean pulled;     // 다른 기기 기록이 이 기기에 들어왔는지

        Result(int code, String msg, boolean pulled) { this.code = code; this.msg = msg; this.pulled = pulled; }
    }

    interface Done { void done(Result r); }

    /** 화면에 '동기화 중' 같은 상태를 알리는 곳 (화면 쓰레드에서 불러요) */
    private static final List<Runnable> listeners = new ArrayList<>();
    static volatile boolean busy;

    static void listen(Runnable r) { synchronized (listeners) { if (!listeners.contains(r)) listeners.add(r); } }

    static void unlisten(Runnable r) { synchronized (listeners) { listeners.remove(r); } }

    private static void notifyUi() {
        List<Runnable> ls;
        synchronized (listeners) { ls = new ArrayList<>(listeners); }
        if (ls.isEmpty()) return;
        main(() -> { for (Runnable r : ls) r.run(); });
    }

    private static void main(Runnable r) {
        try {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(r);
        } catch (Throwable t) {
            r.run();   // 컴퓨터에서 시험할 때
        }
    }

    // ───────── 언제 맞출지 ─────────

    private static ScheduledExecutorService ex;
    private static ScheduledFuture<?> pending;
    private static long pendingAt;

    private static synchronized ScheduledExecutorService ex() {
        if (ex == null) {
            ex = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "sync");
                t.setDaemon(true);
                return t;
            });
        }
        return ex;
    }

    /** 조금 뒤에 맞춰요. 이미 더 이른 예약이 있으면 그걸로 같이 해요 */
    static synchronized void soon(Context c, long delayMs) {
        final Context app = c.getApplicationContext();
        if (!Account.loggedIn(app)) return;
        long at = System.currentTimeMillis() + delayMs;
        if (pending != null && !pending.isDone() && pendingAt <= at) return;
        if (pending != null) pending.cancel(false);
        pendingAt = at;
        pending = ex().schedule(() -> run(app), delayMs, TimeUnit.MILLISECONDS);
    }

    /** 마지막으로 맞춘 지 gapMs가 지났을 때만 (앱으로 돌아올 때 너무 자주 하지 않게) */
    static void soonIfStale(Context c, long delayMs, long gapMs) {
        if (System.currentTimeMillis() - Account.prefs(c).getLong("tried", 0) < gapMs) return;
        soon(c, delayMs);
    }

    /** 지금 바로 맞추고, 끝나면 화면 쓰레드에서 알려 줘요 */
    static void now(Context c, Done cb) {
        final Context app = c.getApplicationContext();
        ex().execute(() -> {
            Result r = run(app);
            if (cb != null) main(() -> cb.done(r));
        });
    }

    static synchronized void cancel() {
        if (pending != null) pending.cancel(false);
        pending = null;
    }

    private static Result run(Context c) {
        busy = true;
        notifyUi();
        try {
            return runOnce(c);
        } finally {
            busy = false;
            notifyUi();
        }
    }

    // ───────── 맞추기 ─────────

    /** 한 번 맞추기 (일하는 쓰레드에서. 시험에서는 바로 불러요) */
    static Result runOnce(Context c) {
        if (!Account.loggedIn(c)) return new Result(OFF, "", false);
        SharedPreferences ap = Account.prefs(c);
        ap.edit().putLong("tried", System.currentTimeMillis()).apply();
        String uid = Account.uid(c);
        boolean pulled = false;
        try {
            String tok = Account.idToken(c);
            for (int attempt = 0; attempt < 4; attempt++) {
                Fb.Got g = Fb.get(uid, tok);
                SyncMerge.Doc remote = SyncMerge.Doc.fromText(Json.s(g.value, "doc"));
                SyncMerge.Doc base = readBase(c, uid);
                boolean first = base == null;
                // 서버가 비었으면(처음이거나 누가 지웠으면) 이 기기 기록을 그대로 올려요. 지난번 기록과 견주면 다 지워질 테니까요
                if (base == null || (remote.w.isEmpty() && remote.p.isEmpty())) {
                    base = new SyncMerge.Doc();
                    first = true;
                }
                long now = System.currentTimeMillis();

                // 1) 공부 화면 기록
                TreeMap<String, SyncMerge.Entry> mw = null;
                Host h;
                synchronized (HOST_LOCK) {
                    h = host.get();
                    if (h == null) {
                        // 공부 화면이 닫혀 있으면 사본 파일에 바로 넣어요 (잠금화면에서 푼 영어 기록부터 합치고)
                        Quiz.flushEnEventsToStore(c);
                        Map<String, Object> all = readWeb(c);
                        TreeMap<String, SyncMerge.Entry> lw = SyncMerge.stamp(base.w, syncedWeb(all), null, now, first);
                        mw = SyncMerge.mergeWeb(base.w, lw, remote.w);
                        List<String> del = applyWeb(c, all, mw);
                        if (del != null) {
                            pulled = true;
                            addPendingDeletes(c, del);
                        }
                    }
                }
                if (h != null) {
                    Map<String, Object> all = readWeb(c);
                    TreeMap<String, SyncMerge.Entry> lw = SyncMerge.stamp(base.w, syncedWeb(all), null, now, first);
                    mw = SyncMerge.mergeWeb(base.w, lw, remote.w);
                    if (webDiffers(all, mw)) {
                        // 화면이 들고 있는 기록을 다 내놓게 한 다음, 그 기록까지 넣어 다시 합쳐요
                        CountDownLatch ready = new CountDownLatch(1);
                        h.unloadPage(ready::countDown);
                        if (!ready.await(8, TimeUnit.SECONDS)) {
                            h.reloadPage(Collections.<String>emptyList(), false);
                            return fail(c, "화면을 정리하지 못해서 다음에 다시 할게요");
                        }
                        all = readWeb(c);
                        lw = SyncMerge.stamp(base.w, syncedWeb(all), null, now, first);
                        mw = SyncMerge.mergeWeb(base.w, lw, remote.w);
                        List<String> del = applyWeb(c, all, mw);
                        pulled |= del != null;
                        h.reloadPage(del == null ? Collections.<String>emptyList() : del, del != null);
                    }
                }

                // 2) 잠금화면 설정·기록
                TreeMap<String, SyncMerge.Entry> mp;
                synchronized (Quiz.PLOCK) {
                    Map<String, String> types = new LinkedHashMap<>();
                    Map<String, Object> pv = readPrefs(c, types);
                    TreeMap<String, SyncMerge.Entry> lp = SyncMerge.stamp(base.p, pv, types, now, first);
                    mp = SyncMerge.mergePrefs(base.p, lp, remote.p);
                    if (applyPrefs(c, pv, mp)) pulled = true;
                }

                // 이 기기는 이제 서버 기록(remote)을 다 담고 있어요. 올리기가 실패해도 다음 비교가 맞게, 지난번 기록을 remote로 바꿔 둬요
                // (그러지 않으면 셈하는 값(푼 문제 수)이 두 번 더해질 수 있어요)
                if (g.value != null) writeBase(c, uid, remote);

                // 3) 합친 것을 올리기
                SyncMerge.Doc merged = new SyncMerge.Doc();
                merged.w.putAll(mw);
                merged.p.putAll(mp);
                long old = now - TOMB_DAYS * 24 * 3600 * 1000L;
                SyncMerge.prune(merged.w, old);
                SyncMerge.prune(merged.p, old);
                boolean need = g.value == null || !merged.sameValues(remote) || !sameTombs(merged, remote);
                if (need) {
                    Map<String, Object> body = new LinkedHashMap<>();
                    body.put("v", 1);
                    body.put("doc", merged.toText());
                    body.put("at", now);
                    body.put("dev", deviceName());
                    if (!Fb.put(uid, tok, Json.str(body), g.etag)) continue;   // 그사이 다른 기기가 올림: 다시
                }
                writeBase(c, uid, merged);
                ap.edit().putLong("last", now).putString("err", "").apply();
                return new Result(OK, "", pulled);
            }
            return fail(c, "다른 기기와 동시에 올리는 중이라 다음에 다시 할게요");
        } catch (Fb.Err e) {
            if (e.loggedOut()) {
                Account.logout(c);
                ap.edit().putString("err", e.say()).apply();
                return new Result(LOGGED_OUT, e.say(), pulled);
            }
            return fail(c, e.say());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return fail(c, "중간에 멈췄어요");
        } catch (RuntimeException e) {
            return fail(c, "동기화하다 문제가 생겼어요 (" + e.getClass().getSimpleName() + ")");
        }
    }

    private static Result fail(Context c, String msg) {
        Account.prefs(c).edit().putString("err", msg).apply();
        return new Result(FAIL, msg, false);
    }

    /** 값은 같아도 '지워짐' 표시가 서버에 아직 없으면 올려야 다른 기기도 지워요 */
    private static boolean sameTombs(SyncMerge.Doc a, SyncMerge.Doc b) {
        return tombs(a.w).equals(tombs(b.w)) && tombs(a.p).equals(tombs(b.p));
    }

    private static Set<String> tombs(Map<String, SyncMerge.Entry> m) {
        Set<String> s = new HashSet<>();
        for (Map.Entry<String, SyncMerge.Entry> e : m.entrySet()) if (e.getValue().v == null) s.add(e.getKey());
        return s;
    }

    // ───────── 공부 화면 기록 (webstore.json) ─────────

    private static Map<String, Object> readWeb(Context c) {
        Map<String, Object> m = Json.objOf(WebStore.read(c));
        return m == null ? new LinkedHashMap<>() : m;
    }

    private static Map<String, Object> syncedWeb(Map<String, Object> all) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : all.entrySet()) {
            if (localWebKey(e.getKey()) || !(e.getValue() instanceof String)) continue;
            if (((String) e.getValue()).length() > MAX_VALUE) continue;
            out.put(e.getKey(), e.getValue());
        }
        return out;
    }

    private static boolean webDiffers(Map<String, Object> all, TreeMap<String, SyncMerge.Entry> mw) {
        Map<String, Object> cur = syncedWeb(all);
        for (Map.Entry<String, SyncMerge.Entry> e : mw.entrySet()) {
            Object v = e.getValue().v;
            if (v == null ? cur.containsKey(e.getKey()) : !v.equals(cur.get(e.getKey()))) return true;
        }
        for (String k : cur.keySet()) if (!mw.containsKey(k)) return true;
        return false;
    }

    /** 합친 기록을 사본 파일에 넣어요. 바뀐 게 없으면 null, 있으면 지운 열쇠 목록 */
    private static List<String> applyWeb(Context c, Map<String, Object> all, TreeMap<String, SyncMerge.Entry> mw) {
        if (!webDiffers(all, mw)) return null;
        Map<String, Object> out = new LinkedHashMap<>();
        List<String> del = new ArrayList<>();
        for (Map.Entry<String, Object> e : all.entrySet()) {
            String k = e.getKey();
            if (localWebKey(k) || !(e.getValue() instanceof String) || ((String) e.getValue()).length() > MAX_VALUE) {
                out.put(k, e.getValue());   // 기기마다 따로인 값은 그대로
                continue;
            }
            SyncMerge.Entry m = mw.get(k);
            if (m == null || m.v == null) del.add(k);
            else out.put(k, m.v);
        }
        for (Map.Entry<String, SyncMerge.Entry> e : mw.entrySet()) {
            if (e.getValue().v != null && !out.containsKey(e.getKey())) out.put(e.getKey(), e.getValue().v);
        }
        WebStore.write(c, Json.str(out));
        return del;
    }

    /** 공부 화면이 닫혀 있을 때 지운 기록: 다음에 화면을 열 때 WebView 저장소에서도 지워요 */
    private static void addPendingDeletes(Context c, List<String> del) {
        if (del.isEmpty()) return;
        SharedPreferences p = Account.prefs(c);
        Set<String> s = new HashSet<>(p.getStringSet("pdel", new HashSet<String>()));
        s.addAll(del);
        p.edit().putStringSet("pdel", s).commit();
    }

    /** 화면을 열기 전에 지울 기록 (가져가면 비워요) */
    static List<String> takePendingDeletes(Context c) {
        SharedPreferences p = Account.prefs(c);
        Set<String> s = p.getStringSet("pdel", new HashSet<String>());
        if (s.isEmpty()) return Collections.emptyList();
        p.edit().remove("pdel").commit();
        return new ArrayList<>(s);
    }

    // ───────── 잠금화면 설정·기록 (SharedPreferences "quiz") ─────────

    private static Map<String, Object> readPrefs(Context c, Map<String, String> types) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (Map.Entry<String, ?> e : Quiz.prefs(c).getAll().entrySet()) {
            String k = e.getKey();
            Object v = e.getValue();
            if (!syncPref(k) || v == null) continue;
            if (v instanceof Boolean) { out.put(k, v); types.put(k, "b"); }
            else if (v instanceof Integer) { out.put(k, ((Integer) v).longValue()); types.put(k, "i"); }
            else if (v instanceof Long) { out.put(k, v); types.put(k, "l"); }
            else if (v instanceof Float) { out.put(k, ((Float) v).doubleValue()); types.put(k, "f"); }
            else if (v instanceof String) { out.put(k, v); types.put(k, "s"); }
            else if (v instanceof Set) {
                List<Object> l = new ArrayList<>();
                for (Object o : (Set<?>) v) l.add(String.valueOf(o));
                Collections.sort(l, (a, b) -> ((String) a).compareTo((String) b));
                out.put(k, l);
                types.put(k, "S");
            }
        }
        return out;
    }

    /** 합친 값 중 이 기기와 다른 것만 넣어요. 바뀐 게 있으면 true */
    private static boolean applyPrefs(Context c, Map<String, Object> cur, TreeMap<String, SyncMerge.Entry> mp) {
        SharedPreferences.Editor e = Quiz.prefs(c).edit();
        boolean ch = false;
        for (Map.Entry<String, SyncMerge.Entry> m : mp.entrySet()) {
            String k = m.getKey();
            if (!syncPref(k)) continue;
            Object v = m.getValue().v;
            if (v == null) {
                if (cur.containsKey(k)) { e.remove(k); ch = true; }
                continue;
            }
            if (Json.eq(v, cur.get(k))) continue;
            if (!put(e, k, m.getValue().y, v)) continue;
            ch = true;
        }
        for (String k : cur.keySet()) {
            if (!mp.containsKey(k)) { e.remove(k); ch = true; }
        }
        if (ch) e.commit();
        return ch;
    }

    private static boolean put(SharedPreferences.Editor e, String k, String y, Object v) {
        if (y == null) {
            if (v instanceof Boolean) y = "b";
            else if (v instanceof Number) y = ((Number) v).doubleValue() == Math.rint(((Number) v).doubleValue()) ? "i" : "f";
            else if (v instanceof String) y = "s";
            else if (v instanceof List) y = "S";
            else return false;
        }
        switch (y) {
            case "b": if (!(v instanceof Boolean)) return false; e.putBoolean(k, (Boolean) v); return true;
            case "i": if (!(v instanceof Number)) return false; e.putInt(k, (int) ((Number) v).longValue()); return true;
            case "l": if (!(v instanceof Number)) return false; e.putLong(k, ((Number) v).longValue()); return true;
            case "f": if (!(v instanceof Number)) return false; e.putFloat(k, ((Number) v).floatValue()); return true;
            case "s": if (!(v instanceof String)) return false; e.putString(k, (String) v); return true;
            case "S": {
                List<Object> l = Json.arr(v);
                if (l == null) return false;
                Set<String> s = new HashSet<>();
                for (Object o : l) s.add(String.valueOf(o));
                e.putStringSet(k, s);
                return true;
            }
            default: return false;
        }
    }

    // ───────── 지난번 맞춘 기록 ─────────

    private static File baseFile(Context c, String uid) {
        return new File(c.getFilesDir(), "sync_base_" + uid.replaceAll("[^A-Za-z0-9_-]", "_") + ".json");
    }

    private static SyncMerge.Doc readBase(Context c, String uid) {
        File f = baseFile(c, uid);
        if (!f.exists()) return null;
        try {
            byte[] b = java.nio.file.Files.readAllBytes(f.toPath());
            return SyncMerge.Doc.fromText(new String(b, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    private static void writeBase(Context c, String uid, SyncMerge.Doc d) {
        File f = baseFile(c, uid), tmp = new File(f.getPath() + ".part");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(d.toText().getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (Exception e) {
            tmp.delete();
            return;
        }
        if (!tmp.renameTo(f)) {
            f.delete();
            tmp.renameTo(f);
        }
    }

    private static String deviceName() {
        try {
            String m = android.os.Build.MODEL;
            return m == null ? "" : m;
        } catch (Throwable t) {
            return "";
        }
    }

    // ───────── 화면에 보일 말 ─────────

    static String status(Context c) {
        if (!Fb.ready()) return "아직 서버가 연결되지 않은 버전이에요";
        if (!Account.loggedIn(c)) {
            String err = Account.prefs(c).getString("err", "");
            return err.isEmpty() ? "로그인하면 기기끼리 기록이 이어져요" : err;
        }
        if (busy) return "동기화하는 중…";
        SharedPreferences p = Account.prefs(c);
        String err = p.getString("err", "");
        if (!err.isEmpty()) return err;
        long last = p.getLong("last", 0);
        if (last == 0) return "아직 동기화하지 않았어요";
        return ago(last);
    }

    static String ago(long t) {
        long s = Math.max(0, (System.currentTimeMillis() - t) / 1000);
        if (s < 60) return "방금 동기화했어요";
        if (s < 3600) return (s / 60) + "분 전에 동기화했어요";
        if (s < 86400) return (s / 3600) + "시간 전에 동기화했어요";
        return (s / 86400) + "일 전에 동기화했어요";
    }
}
