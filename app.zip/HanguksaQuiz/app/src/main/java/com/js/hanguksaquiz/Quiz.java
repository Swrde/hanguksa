package com.js.hanguksaquiz;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * 잠금화면 문제를 만들고, 설정과 기록을 저장해요.
 * - 연표 문제: assets/quiz.json (빈칸표 289줄)
 * - 교과서 순서 문제: assets/order.json (교과서 사건 3~4개 순서 맞히기 300문제)
 * 둘 다 '문제 범위'(연도 / 교과서 단원 / 교과서 쪽) 안에서만 나와요.
 */
final class Quiz {

    static final class Row {
        int n;          // 빈칸표 번호 (1~289)
        String date;    // 빈칸표에 적힌 날짜 칸 ("1948. 5.", "→" 등)
        String text;    // 사건
        String ctx;     // 실제 시기 ("→"는 위 칸의 날짜로 채워 둠)
        boolean world;  // 세계사 줄
        int year;       // ctx 앞 네 자리
    }

    /** 교과서 순서 문제에 나오는 사건 하나 */
    static final class OEvent {
        String id, text, disp;  // disp: "1946. 3. 20." 같은 날짜 표시
        int year;
        int[] pages;            // 교과서 쪽
        Set<String> ch = new HashSet<>();   // 중단원 번호 "1"~"6"
    }

    /** 교과서 순서 문제 하나: 사건이 일어난 순서대로 들어 있어요 */
    static final class OQ {
        String id;
        List<OEvent> ev = new ArrayList<>();
    }

    static final class Chapter {
        String c, name;
        int from, to;
    }

    static final class Question {
        Row row;                // 연표 문제일 때
        OQ oq;                  // 순서 문제일 때
        int type;               // TYPE_WHEN / TYPE_WHAT / TYPE_ORDER
        String key;             // 기록용 이름 (연표: "12", 순서: "o:q012")
        String tag;             // 카드 맨 위 작은 글씨
        String prompt;          // 큰 글씨 문제
        String ask;             // 작은 질문 문구
        List<String> lines = new ArrayList<>();   // 순서 문제의 ㄱ·ㄴ·ㄷ·ㄹ 사건
        List<String> options = new ArrayList<>();
        int answer;             // options 안의 정답 위치
        String explain;         // 푼 뒤 보여 줄 설명
    }

    static final int TYPE_WHEN = 0;  // 사건을 보고 시기 맞히기
    static final int TYPE_WHAT = 1;  // 시기를 보고 사건 맞히기
    static final int TYPE_ORDER = 2; // 교과서 사건 순서 맞히기

    static final String MODE_ALL = "all", MODE_YEAR = "year", MODE_CH = "ch", MODE_PAGE = "pg";
    static final int YEAR_MIN = 1919, YEAR_MAX = 2022;
    static final int[] PAGES = makePages();
    private static final String[] KL = {"ㄱ", "ㄴ", "ㄷ", "ㄹ"};

    private static List<Row> cache;
    private static List<OQ> orderCache;
    private static List<Chapter> chapterCache;

    private Quiz() {}

    private static int[] makePages() {
        int[] p = new int[(123 - 66 + 1) + (137 - 134 + 1)];
        int k = 0;
        for (int i = 66; i <= 123; i++) p[k++] = i;
        for (int i = 134; i <= 137; i++) p[k++] = i;
        return p;
    }

    private static String readAsset(Context c, String name) throws Exception {
        try (InputStream in = c.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int k;
            while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** 공부 내용이 새로 받아지면 다음 문제부터 새 내용으로 */
    static synchronized void invalidate() {
        cache = null;
        orderCache = null;
        chapterCache = null;
        studyCache = null;
    }

    private static String studyCache;

    /** 지금 쓰는 study.html (자동 업데이트로 받은 파일이 있으면 그것) */
    private static synchronized String study(Context c) {
        if (studyCache != null) return studyCache;
        try {
            byte[] b = ContentSync.hasLocal(c) ? ContentSync.readLocal(c) : null;
            studyCache = b != null ? new String(b, StandardCharsets.UTF_8) : readAsset(c, "study.html");
        } catch (Exception e) {
            studyCache = "";
        }
        return studyCache;
    }

    private static String block(String html, String id) {
        String open = "<script type=\"application/json\" id=\"" + id + "\">";
        int a = html.indexOf(open);
        if (a < 0) return null;
        a += open.length();
        int b = html.indexOf("</script>", a);
        return b < 0 ? null : html.substring(a, b);
    }

    static synchronized List<Row> rows(Context c) {
        if (cache != null) return cache;
        List<Row> list = new ArrayList<>();
        try {
            String drill = block(study(c), "drill-data");
            if (drill != null) {
                JSONArray arr = new JSONObject(drill).getJSONArray("rows");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    Row r = new Row();
                    r.n = o.getInt("n");
                    r.date = o.getString("d");
                    r.text = o.getString("t");
                    r.ctx = o.getString("ctx");
                    r.world = o.optBoolean("w", false);
                    r.year = yearOf(r.ctx);
                    list.add(r);
                }
            } else {
                JSONArray arr = new JSONArray(readAsset(c, "quiz.json"));
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    Row r = new Row();
                    r.n = o.getInt("n");
                    r.date = o.getString("d");
                    r.text = o.getString("t");
                    r.ctx = o.getString("c");
                    r.world = o.optInt("w", 0) == 1;
                    r.year = yearOf(r.ctx);
                    list.add(r);
                }
            }
        } catch (Exception e) {
            list.clear();   // 데이터가 깨졌을 때는 빈 목록 (화면에서 안내)
        }
        cache = list;
        return list;
    }

    private static synchronized void loadOrder(Context c) {
        if (orderCache != null) return;
        List<OQ> qs = new ArrayList<>();
        List<Chapter> chs = new ArrayList<>();
        try {
            String oq = block(study(c), "oq-data");
            JSONObject root = new JSONObject(oq != null ? oq : readAsset(c, "order.json"));
            Map<String, OEvent> byId = new HashMap<>();
            JSONArray evs = root.getJSONArray("events");
            for (int i = 0; i < evs.length(); i++) {
                JSONObject o = evs.getJSONObject(i);
                OEvent e = new OEvent();
                e.id = o.getString("id");
                e.text = o.getString("t");
                e.disp = o.getString("disp");
                e.year = o.getInt("y");
                JSONArray pg = o.getJSONArray("pages");
                e.pages = new int[pg.length()];
                for (int k = 0; k < pg.length(); k++) e.pages[k] = pg.getInt(k);
                JSONArray ch = o.getJSONArray("ch");
                for (int k = 0; k < ch.length(); k++) e.ch.add(ch.getString(k));
                byId.put(e.id, e);
            }
            JSONArray arr = root.getJSONArray("questions");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                OQ q = new OQ();
                q.id = o.getString("id");
                JSONArray ids = o.getJSONArray("ev");
                for (int k = 0; k < ids.length(); k++) {
                    OEvent e = byId.get(ids.getString(k));
                    if (e != null) q.ev.add(e);
                }
                if (q.ev.size() >= 3) qs.add(q);
            }
            JSONArray ca = root.getJSONArray("chapters");
            for (int i = 0; i < ca.length(); i++) {
                JSONObject o = ca.getJSONObject(i);
                Chapter ch = new Chapter();
                ch.c = o.getString("c");
                ch.name = o.getString("name");
                ch.from = o.getInt("a");
                ch.to = o.getInt("b");
                chs.add(ch);
            }
        } catch (Exception e) {
            // order.json이 없거나 깨졌으면 순서 문제 없이 연표 문제만 내요
        }
        orderCache = qs;
        chapterCache = chs;
    }

    static List<OQ> orders(Context c) { loadOrder(c); return orderCache; }

    static List<Chapter> chapters(Context c) { loadOrder(c); return chapterCache; }

    private static int yearOf(String s) {
        int y = 0, digits = 0;
        for (int i = 0; i < s.length() && digits < 4; i++) {
            char ch = s.charAt(i);
            if (ch >= '0' && ch <= '9') {
                y = y * 10 + (ch - '0');
                digits++;
            } else if (digits > 0) {
                break;
            }
        }
        return digits == 4 ? y : 0;
    }

    // ───────── 문제 범위 ─────────

    static final class Range {
        String mode;
        int y0, y1, p0, p1;
        Set<String> chs;
        int ymin, ymax;     // 단원·쪽으로 고를 때 연표 문제에 쓰는 시기 (고른 범위의 교과서 사건 연도)
    }

    static Range range(Context c) {
        SharedPreferences p = prefs(c);
        Range g = new Range();
        g.mode = p.getString("rmode", MODE_ALL);
        g.y0 = p.getInt("ry0", 1945);
        g.y1 = p.getInt("ry1", YEAR_MAX);
        if (g.y0 > g.y1) { int t = g.y0; g.y0 = g.y1; g.y1 = t; }
        g.p0 = p.getInt("rp0", 66);
        g.p1 = p.getInt("rp1", 137);
        if (g.p0 > g.p1) { int t = g.p0; g.p0 = g.p1; g.p1 = t; }
        Set<String> def = new HashSet<>(Arrays.asList("1", "2", "3", "4", "5", "6"));
        g.chs = new HashSet<>(p.getStringSet("rchs", def));
        g.ymin = Integer.MAX_VALUE;
        g.ymax = Integer.MIN_VALUE;
        if (MODE_CH.equals(g.mode) || MODE_PAGE.equals(g.mode)) {
            for (OQ q : orders(c)) {
                for (OEvent e : q.ev) {
                    if (evIn(e, g)) {
                        g.ymin = Math.min(g.ymin, e.year);
                        g.ymax = Math.max(g.ymax, e.year);
                    }
                }
            }
        }
        return g;
    }

    static boolean evIn(OEvent e, Range g) {
        switch (g.mode) {
            case MODE_YEAR:
                return e.year >= g.y0 && e.year <= g.y1;
            case MODE_CH:
                for (String s : e.ch) if (g.chs.contains(s)) return true;
                return false;
            case MODE_PAGE:
                for (int pg : e.pages) if (pg >= g.p0 && pg <= g.p1) return true;
                return false;
            default:
                return true;
        }
    }

    static boolean oqIn(OQ q, Range g) {
        for (OEvent e : q.ev) if (!evIn(e, g)) return false;
        return true;
    }

    static boolean rowIn(Row r, Range g) {
        switch (g.mode) {
            case MODE_YEAR:
                return r.year != 0 && r.year >= g.y0 && r.year <= g.y1;
            case MODE_CH:
            case MODE_PAGE:
                return r.year != 0 && r.year >= g.ymin && r.year <= g.ymax;
            default:
                return true;
        }
    }

    private static List<Integer> rowPool(Context c, Range g) {
        List<Row> all = rows(c);
        boolean withWorld = prefs(c).getBoolean("world", true);
        List<Integer> pool = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) {
            Row r = all.get(i);
            if ((withWorld || !r.world) && rowIn(r, g)) pool.add(i);
        }
        return pool;
    }

    private static List<OQ> orderPool(Context c, Range g) {
        List<OQ> out = new ArrayList<>();
        for (OQ q : orders(c)) if (oqIn(q, g)) out.add(q);
        return out;
    }

    /** 지금 범위 안의 문제 수: {연표, 교과서 순서} */
    static int[] countInRange(Context c) {
        Range g = range(c);
        return new int[]{rowPool(c, g).size(), orderPool(c, g).size()};
    }

    // ───────── 문제 만들기 ─────────

    static Question next(Context c, Random rnd) {
        List<Row> all = rows(c);
        SharedPreferences p = prefs(c);
        Range g = range(c);
        boolean when = p.getBoolean("t_when", true);
        boolean what = p.getBoolean("t_what", true);
        boolean ord = p.getBoolean("t_order", true);

        List<Integer> pool = (when || what) && all.size() >= 8 ? rowPool(c, g) : new ArrayList<Integer>();
        List<OQ> opool = ord ? orderPool(c, g) : new ArrayList<OQ>();
        boolean useRows = !pool.isEmpty(), useOrder = !opool.isEmpty();
        if (!useRows && !useOrder) return null;
        if (useRows && useOrder) {
            if (rnd.nextBoolean()) useRows = false; else useOrder = false;
        }

        Set<String> wrong = p.getStringSet("wrong", new HashSet<String>());
        List<String> recent = recent(p);
        Question q;

        if (useOrder) {
            OQ pick = null;
            // 틀린 문제는 35% 확률로 다시 나와요
            if (!wrong.isEmpty() && rnd.nextInt(100) < 35) {
                List<OQ> w = new ArrayList<>();
                for (OQ o : opool) if (wrong.contains("o:" + o.id)) w.add(o);
                if (!w.isEmpty()) pick = w.get(rnd.nextInt(w.size()));
            }
            if (pick == null) {
                for (int tries = 0; tries < 30; tries++) {
                    pick = opool.get(rnd.nextInt(opool.size()));
                    if (!recent.contains("o:" + pick.id)) break;
                }
            }
            q = buildOrder(pick, rnd);
        } else {
            int idx = -1;
            if (!wrong.isEmpty() && rnd.nextInt(100) < 35) {
                List<Integer> w = new ArrayList<>();
                for (int i : pool) if (wrong.contains(String.valueOf(all.get(i).n))) w.add(i);
                if (!w.isEmpty()) idx = w.get(rnd.nextInt(w.size()));
            }
            if (idx < 0) {
                for (int tries = 0; tries < 30; tries++) {
                    idx = pool.get(rnd.nextInt(pool.size()));
                    if (!recent.contains(String.valueOf(all.get(idx).n))) break;
                }
            }
            int type;
            if (when && what) type = rnd.nextBoolean() ? TYPE_WHEN : TYPE_WHAT;
            else if (what) type = TYPE_WHAT;
            else type = TYPE_WHEN;
            q = build(all, idx, type, rnd);
            if (q == null) q = build(all, idx, type == TYPE_WHEN ? TYPE_WHAT : TYPE_WHEN, rnd);
        }
        if (q != null) remember(p, q.key);
        return q;
    }

    private static Question build(List<Row> all, int idx, int type, Random rnd) {
        Row row = all.get(idx);
        Question q = new Question();
        q.row = row;
        q.type = type;
        q.key = String.valueOf(row.n);
        q.tag = "한국사2 연표 " + row.n + "번" + (row.world ? " · 세계사" : "");
        String correct;
        if (type == TYPE_WHEN) {
            q.prompt = row.text;
            q.ask = "언제 있었던 일일까요?";
            correct = row.ctx;
        } else {
            q.prompt = row.ctx;
            q.ask = "이때 있었던 일은 무엇일까요?";
            correct = row.text;
        }

        // 오답 후보: 가까운 줄부터, 정답과 연도가 다른 것만 (헷갈리되 답이 둘이 되지 않게)
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) if (i != idx) order.add(i);
        final int center = idx;
        Collections.sort(order, (a, b) -> Integer.compare(Math.abs(a - center), Math.abs(b - center)));

        List<String> cands = new ArrayList<>();
        for (int i : order) {
            Row o = all.get(i);
            if (row.year != 0 && o.year == row.year) continue;
            if (row.year == 0 && o.ctx.equals(row.ctx)) continue;
            String label = type == TYPE_WHEN ? o.ctx : o.text;
            if (label.equals(correct) || cands.contains(label)) continue;
            cands.add(label);
            if (cands.size() >= 12) break;
        }
        if (cands.size() < 3) return null;
        Collections.shuffle(cands, rnd);

        q.options.add(correct);
        q.options.addAll(cands.subList(0, 3));
        Collections.shuffle(q.options, rnd);
        q.answer = q.options.indexOf(correct);
        q.explain = row.ctx + "  " + row.text;
        return q;
    }

    /** 순서 문제: 사건을 섞어 ㄱ·ㄴ·ㄷ(·ㄹ)을 붙이고, 시험처럼 순서 보기 5개 중에서 고르게 해요 */
    private static Question buildOrder(OQ oq, Random rnd) {
        int n = oq.ev.size();
        List<Integer> disp = new ArrayList<>();          // disp.get(k) = 화면 k번째 사건의 실제 순서
        for (int i = 0; i < n; i++) disp.add(i);
        Collections.shuffle(disp, rnd);
        List<Integer> answer = new ArrayList<>();        // 정답: 일어난 순서대로 화면 번호
        for (int r = 0; r < n; r++) answer.add(disp.indexOf(r));

        List<List<Integer>> wrongs = new ArrayList<>();
        permute(new ArrayList<Integer>(), new ArrayList<>(answer), wrongs);
        wrongs.removeIf(x -> x.equals(answer));
        List<List<Integer>> near = new ArrayList<>();
        for (List<Integer> x : wrongs) {
            int diff = 0;
            for (int i = 0; i < n; i++) if (!x.get(i).equals(answer.get(i))) diff++;
            if (diff == 2) near.add(x);
        }
        Collections.shuffle(near, rnd);
        Collections.shuffle(wrongs, rnd);
        List<List<Integer>> picks = new ArrayList<>();
        for (List<Integer> x : near) if (picks.size() < 2) picks.add(x);
        for (List<Integer> x : wrongs) if (picks.size() < 4 && !picks.contains(x)) picks.add(x);
        picks.add(answer);
        Collections.sort(picks, (a, b) -> seq(a).compareTo(seq(b)));

        Question q = new Question();
        q.oq = oq;
        q.type = TYPE_ORDER;
        q.key = "o:" + oq.id;
        q.tag = "교과서 순서 · 사건 " + n + "개";
        q.prompt = "일어난 순서대로 옳게 나열한 것은?";
        q.ask = "";
        for (int k = 0; k < n; k++) q.lines.add(KL[k] + ". " + oq.ev.get(disp.get(k)).text);
        for (List<Integer> x : picks) q.options.add(seq(x));
        q.answer = picks.indexOf(answer);
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < n; r++) {
            OEvent e = oq.ev.get(r);
            if (r > 0) sb.append('\n');
            sb.append(KL[answer.get(r)]).append("  ").append(e.disp).append("  ").append(e.text)
              .append(" (교과서 ").append(pagesText(e.pages)).append("쪽)");
        }
        q.explain = sb.toString();
        return q;
    }

    private static void permute(List<Integer> pre, List<Integer> rest, List<List<Integer>> out) {
        if (rest.isEmpty()) { out.add(new ArrayList<>(pre)); return; }
        for (int i = 0; i < rest.size(); i++) {
            List<Integer> p2 = new ArrayList<>(pre);
            p2.add(rest.get(i));
            List<Integer> r2 = new ArrayList<>(rest);
            r2.remove(i);
            permute(p2, r2, out);
        }
    }

    private static String seq(List<Integer> s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.size(); i++) {
            if (i > 0) b.append(" → ");
            b.append(KL[s.get(i)]);
        }
        return b.toString();
    }

    private static String pagesText(int[] pages) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < pages.length; i++) {
            if (i > 0) b.append('·');
            b.append(pages[i]);
        }
        return b.toString();
    }

    private static List<String> recent(SharedPreferences p) {
        List<String> out = new ArrayList<>();
        String s = p.getString("recent", "");
        if (s.length() == 0) return out;
        Collections.addAll(out, s.split(","));
        return out;
    }

    private static void remember(SharedPreferences p, String key) {
        List<String> r = recent(p);
        r.remove(key);
        r.add(key);
        while (r.size() > 40) r.remove(0);
        p.edit().putString("recent", String.join(",", r)).apply();
    }

    // ───────── 기록 ─────────

    static void record(Context c, String key, boolean ok) {
        SharedPreferences p = prefs(c);
        Set<String> wrong = new HashSet<>(p.getStringSet("wrong", new HashSet<String>()));
        if (ok) wrong.remove(key);
        else wrong.add(key);
        p.edit()
                .putInt("total", p.getInt("total", 0) + 1)
                .putInt("correct", p.getInt("correct", 0) + (ok ? 1 : 0))
                .putInt("streak", ok ? p.getInt("streak", 0) + 1 : 0)
                .putStringSet("wrong", wrong)
                .apply();
    }

    static int total(Context c) { return prefs(c).getInt("total", 0); }
    static int correct(Context c) { return prefs(c).getInt("correct", 0); }
    static int streak(Context c) { return prefs(c).getInt("streak", 0); }
    static int wrongCount(Context c) { return prefs(c).getStringSet("wrong", new HashSet<String>()).size(); }

    static void resetStats(Context c) {
        prefs(c).edit().remove("total").remove("correct").remove("streak").remove("wrong").remove("recent").apply();
    }

    // ───────── 설정 ─────────

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("quiz", Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) { return prefs(c).getBoolean("enabled", false); }

    static void setEnabled(Context c, boolean on) { prefs(c).edit().putBoolean("enabled", on).apply(); }

    /** 문제 사이 최소 간격(분). 0이면 화면을 켤 때마다. */
    static int intervalMin(Context c) { return prefs(c).getInt("interval", 0); }

    static void setIntervalMin(Context c, int m) { prefs(c).edit().putInt("interval", m).apply(); }

    static boolean dueNow(Context c) {
        long last = prefs(c).getLong("last", 0);
        long gap = intervalMin(c) * 60_000L;
        long now = System.currentTimeMillis();
        return gap == 0 || now - last >= gap || now < last;
    }

    static void markShown(Context c) { prefs(c).edit().putLong("last", System.currentTimeMillis()).apply(); }
}
