package com.js.hanguksaquiz;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * 잠금화면 문제를 만들고, 설정과 기록을 저장해요.
 * - 연표 문제: study.html의 drill-data (빈칸표 289줄, 줄마다 교과서 단원·쪽)
 * - 교과서 순서 문제: assets/order.json (교과서 사건 3~4개 순서 맞히기 300문제)
 * 둘 다 '문제 범위'(연도 / 교과서 단원 / 교과서 쪽) 안에서만 나와요.
 */
final class Quiz {

    static final class Row {
        int n;          // 빈칸표 번호 (1~289)
        String date;    // 빈칸표에 적힌 날짜 칸 ("1948. 5.", "→" 등)
        String text;    // 사건
        String ctx;     // 실제 시기 ("→"는 위 칸의 날짜로 채워 둠)
        boolean world;  // 세계사 줄
        int year;       // ctx 앞 네 자리
        int yearTo;     // '(~1978)'처럼 이어진 사건이면 끝난 해, 아니면 year
        boolean exact = true;   // '1970년대 말'처럼 해가 딱 정해지지 않은 줄은 false (study.html의 y가 비어 있음)
        Set<String> ch = new HashSet<>();   // 이 줄을 다루는 교과서 중단원 "1"~"6"
        int[] pages = new int[0];           // 이 줄을 다루는 교과서 쪽
    }

    /** 교과서 순서 문제에 나오는 사건 하나 */
    static final class OEvent {
        String id, text, disp;  // disp: "1946. 3. 20." 같은 날짜 표시
        int year, month;        // month: 모르면 0
        int[] pages;            // 교과서 쪽
        Set<String> ch = new HashSet<>();   // 중단원 번호 "1"~"6"
    }

    /** 교과서 순서 문제 하나: 사건이 일어난 순서대로 들어 있어요 */
    static final class OQ {
        String id;
        List<OEvent> ev = new ArrayList<>();
    }

    static final class Chapter {
        String c, name;
        int from, to;
    }

    /** 교과서 문제(일반·용어·어느 정부·몇 년·O/X): study.html의 tq-data */
    static final class TItem {
        String id, type, q, ask, x;
        String tn = "";         // 유형 이름(있으면 그대로 써서, 새 유형도 앱을 고치지 않고 이름이 나와요)
        List<String> o = new ArrayList<>();
        int a, year;
        Set<String> ch = new HashSet<>();
        int[] pages = new int[0];
    }

    static final class Question {
        Row row;                // 연표 문제일 때
        OQ oq;                  // 순서 문제일 때
        TItem item;             // 교과서 문제일 때
        int type;               // TYPE_WHEN / TYPE_WHAT / TYPE_ORDER
        String key;             // 기록용 이름 (연표: "12", 순서: "o:q012")
        String tag;             // 카드 맨 위 작은 글씨
        String prompt;          // 큰 글씨 문제
        String ask;             // 작은 질문 문구
        List<String> lines = new ArrayList<>();   // 순서 문제의 ㄱ·ㄴ·ㄷ·ㄹ 사건
        List<String> options = new ArrayList<>();
        int answer;             // options 안의 정답 위치
        String explain;         // 푼 뒤 보여 줄 설명
        int color;              // 카드 위 작은 글씨 색 (과목 색, 0이면 기본)
        float promptSp;         // 문제 글자 크기 (0이면 기본 규칙)
        String unit = "";       // 단원 (정답률 셈): "ks:3", "sa:2", "en:47"
        boolean review;         // 복습할 날이 된 문제
    }

    /** 통합사회 문제 하나 (study.html의 lq-sa) */
    static final class PItem {
        String id, tag, q, ask, x;
        String cat;             // 종류: rn 롤스·노직, lc 자유주의·공동체주의, cd 시민 불복종, bl 교과서 빈칸
        int unit = -1;          // 단원 번호 (모르면 -1: 늘 나옴)
        List<String> o = new ArrayList<>();
        int a;
        boolean fixed;          // O/X처럼 보기 순서를 섞지 않음
        float sp;
    }

    /** 영어 낱말 하나 (study.html의 lq-en) */
    static final class Word {
        int id, day;
        String w, m, ex, ko, pos;
        int sa = -1, sb = -1;   // 예문 속 { } 자리
        boolean canS;           // 예문 빈칸 문제를 낼 수 있음
        Set<String> keys = new HashSet<>();   // 뜻의 핵심 말 (보기끼리 뜻이 겹치지 않게)
    }

    /** 뜻의 핵심 말: 품사 표시·괄호를 빼고 쉼표로 나눈 두 글자 이상 조각 ('묘사하다' → '묘사').
     *  'portray(묘사하다, 그리다)'와 'depict(묘사하다, 그리다)'처럼 뜻이 겹치는 낱말이 한 문제에 같이 나오면 답이 둘이 돼서 걸러요 */
    static Set<String> meaningKeys(String m) {
        Set<String> out = new HashSet<>();
        String body = m.replaceAll("\\([^)]*\\)", " ").replaceAll("(^|\\s)(n|v|a|ad|adv|prep|conj|pron|int)\\.\\s*", ",");
        for (String part : body.split("[,;/·]")) {
            String t = part.trim().replaceAll("(하다|되다|스러운|적인|적|한|하는|의)$", "").trim();
            if (t.length() >= 2) out.add(t);
        }
        return out;
    }

    private static boolean overlaps(Word a, Word b) {
        for (String k : a.keys) if (b.keys.contains(k)) return true;
        return false;
    }

    // 과목 켜기·끄기
    static final String S_KS = "s_ks", S_SA = "s_sa", S_EN = "s_en";
    // 잠금화면(어두운 화면)에서 쓰는 과목 색
    static final int C_KS = 0xFFA9A7FF, C_SA = 0xFF7EE79F, C_EN = 0xFFFFB340;   // 어두운 잠금화면에서 읽기 좋은 과목 색

    static final int TYPE_WHEN = 0;  // 사건을 보고 시기 맞히기
    static final int TYPE_WHAT = 1;  // 시기를 보고 사건 맞히기
    static final int TYPE_ORDER = 2; // 교과서 사건 순서 맞히기
    static final int TYPE_TEXT = 3;  // 교과서 문제(일반·용어·어느 정부·몇 년·O/X)

    static final String MODE_ALL = "all", MODE_YEAR = "year", MODE_CH = "ch", MODE_PAGE = "pg";
    static final int YEAR_MIN = 1919, YEAR_MAX = 2022;
    static final int[] PAGES = makePages();
    private static final String[] KL = {"ㄱ", "ㄴ", "ㄷ", "ㄹ"};

    private static List<Row> cache;
    private static List<OQ> orderCache;
    private static List<Chapter> chapterCache;
    private static List<TItem> textCache;
    private static List<PItem> saCache;
    private static List<String[]> saCats = new ArrayList<>(), saUnits = new ArrayList<>();
    private static List<Word> enCache;

    private Quiz() {}

    private static int[] makePages() {
        int[] p = new int[(123 - 66 + 1) + (137 - 134 + 1)];
        int k = 0;
        for (int i = 66; i <= 123; i++) p[k++] = i;
        for (int i = 134; i <= 137; i++) p[k++] = i;
        return p;
    }

    private static String readAsset(Context c, String name) throws Exception {
        try (InputStream in = c.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int k;
            while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** 공부 내용이 새로 받아지면 다음 문제부터 새 내용으로 */
    static synchronized void invalidate() {
        saCache = null;
        enCache = null;
        cache = null;
        orderCache = null;
        chapterCache = null;
        textCache = null;
        studyCache = null;
    }

    private static String studyCache;

    /** 지금 쓰는 study.html (자동 업데이트로 받은 파일이 있으면 그것) */
    private static synchronized String study(Context c) {
        if (studyCache != null) return studyCache;
        try {
            byte[] b = ContentSync.hasLocal(c) ? ContentSync.readLocal(c) : null;
            studyCache = b != null ? new String(b, StandardCharsets.UTF_8) : readAsset(c, "study.html");
        } catch (Exception e) {
            studyCache = "";
        }
        return studyCache;
    }

    private static String block(String html, String id) {
        String open = "<script type=\"application/json\" id=\"" + id + "\">";
        int a = html.indexOf(open);
        if (a < 0) return null;
        a += open.length();
        int b = html.indexOf("</script>", a);
        return b < 0 ? null : html.substring(a, b);
    }

    static synchronized List<Row> rows(Context c) {
        if (cache != null) return cache;
        List<Row> list = new ArrayList<>();
        try {
            String drill = block(study(c), "drill-data");
            if (drill != null) {
                JSONArray arr = new JSONObject(drill).getJSONArray("rows");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    Row r = new Row();
                    r.n = o.getInt("n");
                    r.date = o.getString("d");
                    r.text = o.getString("t");
                    r.ctx = o.getString("ctx");
                    r.world = o.optBoolean("w", false);
                    r.year = yearOf(r.ctx);
                    r.yearTo = spanEnd(r.text, r.year);
                    r.exact = !o.has("y") || !o.isNull("y");
                    readPlace(r, o);
                    list.add(r);
                }
            } else {
                JSONArray arr = new JSONArray(readAsset(c, "quiz.json"));
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    Row r = new Row();
                    r.n = o.getInt("n");
                    r.date = o.getString("d");
                    r.text = o.getString("t");
                    r.ctx = o.getString("c");
                    r.world = o.optInt("w", 0) == 1;
                    r.year = yearOf(r.ctx);
                    r.yearTo = spanEnd(r.text, r.year);
                    readPlace(r, o);
                    list.add(r);
                }
            }
        } catch (Exception e) {
            list.clear();   // 데이터가 깨졌을 때는 빈 목록 (화면에서 안내)
        }
        cache = list;
        return list;
    }

    /** 연표 줄에 붙은 교과서 단원(ch)과 쪽(pg) */
    private static void readPlace(Row r, JSONObject o) {
        JSONArray ch = o.optJSONArray("ch");
        if (ch != null) for (int k = 0; k < ch.length(); k++) r.ch.add(ch.optString(k));
        JSONArray pg = o.optJSONArray("pg");
        if (pg != null) {
            r.pages = new int[pg.length()];
            for (int k = 0; k < pg.length(); k++) r.pages[k] = pg.optInt(k);
        }
    }

    private static final java.util.regex.Pattern NAME_DATE =
            java.util.regex.Pattern.compile("(?<!\\d)(\\d{1,2})\\s*·\\s*(\\d{1,2})(?!\\d)|(\\d{1,2})월");

    /** 같은 해 사건인데 이름 속 날짜(3·15, 4·19, 6월 …)만 보고도 순서가 다 나오는 문제는 잠금화면에 안 내요 */
    static boolean orderGiveaway(OQ q) {
        int year = q.ev.get(0).year, dated = 0;
        for (OEvent e : q.ev) {
            if (e.year != year) return false;
            java.util.regex.Matcher m = NAME_DATE.matcher(e.text);
            if (m.find()) {
                int mo = Integer.parseInt(m.group(1) != null ? m.group(1) : m.group(3));
                if (mo == e.month) dated++;
            }
        }
        return dated >= q.ev.size() - 1;
    }

    private static synchronized void loadOrder(Context c) {
        if (orderCache != null) return;
        List<OQ> qs = new ArrayList<>();
        List<Chapter> chs = new ArrayList<>();
        try {
            String oq = block(study(c), "oq-data");
            JSONObject root = new JSONObject(oq != null ? oq : readAsset(c, "order.json"));
            Map<String, OEvent> byId = new HashMap<>();
            JSONArray evs = root.getJSONArray("events");
            for (int i = 0; i < evs.length(); i++) {
                JSONObject o = evs.getJSONObject(i);
                OEvent e = new OEvent();
                e.id = o.getString("id");
                e.text = o.getString("t");
                e.disp = o.getString("disp");
                e.year = o.getInt("y");
                e.month = o.optInt("m", 0);
                JSONArray pg = o.getJSONArray("pages");
                e.pages = new int[pg.length()];
                for (int k = 0; k < pg.length(); k++) e.pages[k] = pg.getInt(k);
                JSONArray ch = o.getJSONArray("ch");
                for (int k = 0; k < ch.length(); k++) e.ch.add(ch.getString(k));
                byId.put(e.id, e);
            }
            JSONArray arr = root.getJSONArray("questions");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                OQ q = new OQ();
                q.id = o.getString("id");
                JSONArray ids = o.getJSONArray("ev");
                for (int k = 0; k < ids.length(); k++) {
                    OEvent e = byId.get(ids.getString(k));
                    if (e != null) q.ev.add(e);
                }
                if (q.ev.size() >= 3 && !orderGiveaway(q)) qs.add(q);
            }
            JSONArray ca = root.getJSONArray("chapters");
            for (int i = 0; i < ca.length(); i++) {
                JSONObject o = ca.getJSONObject(i);
                Chapter ch = new Chapter();
                ch.c = o.getString("c");
                ch.name = o.getString("name");
                ch.from = o.getInt("a");
                ch.to = o.getInt("b");
                chs.add(ch);
            }
        } catch (Exception e) {
            // order.json이 없거나 깨졌으면 순서 문제 없이 연표 문제만 내요
        }
        orderCache = qs;
        chapterCache = chs;
    }

    static List<OQ> orders(Context c) { loadOrder(c); return orderCache; }

    static synchronized List<TItem> texts(Context c) {
        if (textCache != null) return textCache;
        List<TItem> list = new ArrayList<>();
        try {
            String tq = block(study(c), "tq-data");
            if (tq != null) {
                JSONArray arr = new JSONObject(tq).getJSONArray("items");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    TItem t = new TItem();
                    t.id = o.getString("id");
                    t.type = o.getString("t");
                    t.q = o.getString("q");
                    t.ask = o.optString("ask", "");
                    t.tn = o.optString("tn", "");
                    t.x = o.optString("x", "");
                    JSONArray op = o.getJSONArray("o");
                    for (int k = 0; k < op.length(); k++) t.o.add(op.getString(k));
                    t.a = o.getInt("a");
                    t.year = o.optInt("y", 0);
                    JSONArray ch = o.optJSONArray("ch");
                    if (ch != null) for (int k = 0; k < ch.length(); k++) t.ch.add(ch.optString(k));
                    JSONArray pg = o.optJSONArray("pg");
                    if (pg != null) {
                        t.pages = new int[pg.length()];
                        for (int k = 0; k < pg.length(); k++) t.pages[k] = pg.optInt(k);
                    }
                    if (t.a >= 0 && t.a < t.o.size()) list.add(t);
                }
            }
        } catch (Exception e) {
            list.clear();   // 없거나 깨졌으면 교과서 문제 없이
        }
        textCache = list;
        return list;
    }

    static List<Chapter> chapters(Context c) { loadOrder(c); return chapterCache; }

    private static int yearOf(String s) {
        int y = 0, digits = 0;
        for (int i = 0; i < s.length() && digits < 4; i++) {
            char ch = s.charAt(i);
            if (ch >= '0' && ch <= '9') {
                y = y * 10 + (ch - '0');
                digits++;
            } else if (digits > 0) {
                break;
            }
        }
        return digits == 4 ? y : 0;
    }

    // ───────── 문제 범위 ─────────

    static final class Range {
        String mode;
        int y0, y1, p0, p1;
        Set<String> chs;
        int ymin, ymax;     // 연표 줄에 단원·쪽 정보가 없는 예전 데이터일 때만 쓰는 시기
    }

    static Range range(Context c) {
        SharedPreferences p = prefs(c);
        Range g = new Range();
        g.mode = p.getString("rmode", MODE_ALL);
        g.y0 = p.getInt("ry0", 1945);
        g.y1 = p.getInt("ry1", YEAR_MAX);
        if (g.y0 > g.y1) { int t = g.y0; g.y0 = g.y1; g.y1 = t; }
        g.p0 = p.getInt("rp0", 66);
        g.p1 = p.getInt("rp1", 137);
        if (g.p0 > g.p1) { int t = g.p0; g.p0 = g.p1; g.p1 = t; }
        Set<String> def = new HashSet<>(Arrays.asList("1", "2", "3", "4", "5", "6"));
        g.chs = new HashSet<>(p.getStringSet("rchs", def));
        g.ymin = Integer.MAX_VALUE;
        g.ymax = Integer.MIN_VALUE;
        if (MODE_CH.equals(g.mode) || MODE_PAGE.equals(g.mode)) {
            for (OQ q : orders(c)) {
                for (OEvent e : q.ev) {
                    if (evIn(e, g)) {
                        g.ymin = Math.min(g.ymin, e.year);
                        g.ymax = Math.max(g.ymax, e.year);
                    }
                }
            }
        }
        return g;
    }

    static boolean evIn(OEvent e, Range g) {
        switch (g.mode) {
            case MODE_YEAR:
                return e.year >= g.y0 && e.year <= g.y1;
            case MODE_CH:
                for (String s : e.ch) if (g.chs.contains(s)) return true;
                return false;
            case MODE_PAGE:
                for (int pg : e.pages) if (pg >= g.p0 && pg <= g.p1) return true;
                return false;
            default:
                return true;
        }
    }

    static boolean oqIn(OQ q, Range g) {
        for (OEvent e : q.ev) if (!evIn(e, g)) return false;
        return true;
    }

    static boolean rowIn(Row r, Range g) {
        switch (g.mode) {
            case MODE_YEAR:
                return r.year != 0 && r.year >= g.y0 && r.year <= g.y1;
            case MODE_CH:
                if (!r.ch.isEmpty()) {
                    for (String s : r.ch) if (g.chs.contains(s)) return true;
                    return false;
                }
                return r.year != 0 && r.year >= g.ymin && r.year <= g.ymax;   // 예전 데이터일 때만
            case MODE_PAGE:
                if (r.pages.length > 0) {
                    for (int pg : r.pages) if (pg >= g.p0 && pg <= g.p1) return true;
                    return false;
                }
                return r.year != 0 && r.year >= g.ymin && r.year <= g.ymax;   // 예전 데이터일 때만
            default:
                return true;
        }
    }

    private static List<Integer> rowPool(Context c, Range g) {
        List<Row> all = rows(c);
        boolean withWorld = prefs(c).getBoolean("world", true);
        List<Integer> pool = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) {
            Row r = all.get(i);
            if ((withWorld || !r.world) && rowIn(r, g)) pool.add(i);
        }
        return pool;
    }

    static boolean textIn(TItem t, Range g) {
        switch (g.mode) {
            case MODE_YEAR:
                return t.year != 0 && t.year >= g.y0 && t.year <= g.y1;
            case MODE_CH:
                for (String s : t.ch) if (g.chs.contains(s)) return true;
                return false;
            case MODE_PAGE:
                for (int pg : t.pages) if (pg >= g.p0 && pg <= g.p1) return true;
                return false;
            default:
                return true;
        }
    }

    private static List<TItem> textPool(Context c, Range g) {
        List<TItem> out = new ArrayList<>();
        for (TItem t : texts(c)) if (textIn(t, g)) out.add(t);
        return out;
    }

    private static List<OQ> orderPool(Context c, Range g) {
        List<OQ> out = new ArrayList<>();
        for (OQ q : orders(c)) if (oqIn(q, g)) out.add(q);
        return out;
    }

    /** 지금 범위 안의 문제 수: {연표, 교과서 순서, 교과서 문제} */
    static int[] countInRange(Context c) {
        Range g = range(c);
        return new int[]{rowPool(c, g).size(), orderPool(c, g).size(), textPool(c, g).size()};
    }

    // ───────── 문제 만들기 ─────────

    static boolean subjectOn(Context c, String k) { return prefs(c).getBoolean(k, true); }

    static void setSubject(Context c, String k, boolean on) { prefs(c).edit().putBoolean(k, on).apply(); }

    /** 켜 둔 과목 가운데 하나를 고르게 골라 문제를 내요. 그 과목에 낼 문제가 없으면 다른 과목으로. */
    static Question next(Context c, Random rnd) {
        List<Integer> subs = new ArrayList<>();
        if (subjectOn(c, S_KS)) subs.add(0);
        if (subjectOn(c, S_SA)) subs.add(1);
        if (subjectOn(c, S_EN)) subs.add(2);
        Collections.shuffle(subs, rnd);
        for (int s : subs) {
            Question q = s == 0 ? nextKs(c, rnd) : s == 1 ? nextSa(c, rnd) : nextEn(c, rnd);
            if (q != null) {
                if (s == 0 && q.color == 0) q.color = C_KS;
                return q;
            }
        }
        return null;
    }

    /** 과목별로 지금 고른 종류·범위에서 낼 수 있는 문제 수: {한국사, 통합사회, 영어 낱말} */
    static int[] subjectCounts(Context c) {
        SharedPreferences p = prefs(c);
        int[] n = countInRange(c);
        boolean rowsOn = p.getBoolean("t_when", true) || p.getBoolean("t_what", true);
        int ks = (rowsOn ? n[0] : 0) + (p.getBoolean("t_order", true) ? n[1] : 0) + (p.getBoolean("t_text", true) ? n[2] : 0);
        return new int[]{ks, saPool(c).size(), enPool(c).size()};
    }

    // ── 통합사회: 문제 종류(cats)와 단원(units)은 study.html에서 같이 읽어요 ──

    private static void loadSa(Context c) {
        if (saCache != null) return;
        List<PItem> out = new ArrayList<>();
        List<String[]> cats = new ArrayList<>(), units = new ArrayList<>();
        try {
            String js = block(study(c), "lq-sa");
            if (js != null) {
                js = js.trim();
                JSONArray arr;
                if (js.startsWith("{")) {
                    JSONObject root = new JSONObject(js);
                    arr = root.getJSONArray("items");
                    JSONArray ca = root.optJSONArray("cats"), ua = root.optJSONArray("units");
                    if (ca != null) for (int i = 0; i < ca.length(); i++) {
                        JSONArray a = ca.getJSONArray(i);
                        cats.add(new String[]{a.getString(0), a.getString(1)});
                    }
                    if (ua != null) for (int i = 0; i < ua.length(); i++) {
                        JSONArray a = ua.getJSONArray(i);
                        units.add(new String[]{a.getString(0), a.optString(1, "")});
                    }
                } else {
                    arr = new JSONArray(js);
                }
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    PItem it = new PItem();
                    it.id = o.getString("i");
                    it.cat = o.optString("c", it.id.startsWith("rn") ? "rn" : it.id.startsWith("lc") ? "lc"
                            : it.id.startsWith("cd") ? "cd" : "bl");
                    it.unit = o.optInt("u", -1);
                    it.tag = o.optString("g", "통합사회2");
                    it.q = o.getString("q");
                    it.ask = o.optString("k", "");
                    it.x = o.optString("x", "");
                    it.a = o.getInt("a");
                    it.fixed = o.optInt("f", 0) == 1;
                    it.sp = (float) o.optDouble("z", 0);
                    JSONArray op = o.getJSONArray("o");
                    for (int j = 0; j < op.length(); j++) it.o.add(op.getString(j));
                    if (it.a >= 0 && it.a < it.o.size() && it.o.size() >= 2) out.add(it);
                }
            }
        } catch (Exception ignored) {
            // 내용이 잘못돼도 다른 과목은 그대로 나와요
        }
        if (cats.isEmpty() && !out.isEmpty()) {
            // 예전 study.html이라 종류 이름이 없으면 기본 이름으로
            cats.add(new String[]{"rn", "롤스·노직 O/X"});
            cats.add(new String[]{"lc", "자유주의·공동체주의 O/X"});
            cats.add(new String[]{"cd", "시민 불복종 O/X"});
            cats.add(new String[]{"bl", "교과서 요약 빈칸"});
        }
        saCache = out;
        saCats = cats;
        saUnits = units;
    }

    static synchronized List<PItem> saItems(Context c) { loadSa(c); return saCache; }

    /** 통합사회 문제 종류: {키, 이름} */
    static synchronized List<String[]> saCats(Context c) { loadSa(c); return saCats; }

    /** 통합사회 단원: {이름, 쪽} — 순서가 단원 번호 */
    static synchronized List<String[]> saUnits(Context c) { loadSa(c); return saUnits; }

    /** 설정에서 고른 종류·단원에 맞는 통합사회 문제 */
    static List<PItem> saPool(Context c) {
        SharedPreferences p = prefs(c);
        Set<String> units = p.getStringSet("sa_units", null);
        List<PItem> out = new ArrayList<>();
        for (PItem it : saItems(c)) {
            if (!p.getBoolean("sa_c_" + it.cat, true)) continue;
            if (units != null && it.unit >= 0 && !units.contains(String.valueOf(it.unit))) continue;
            out.add(it);
        }
        return out;
    }

    // ── 영어 ──

    static synchronized List<Word> enWords(Context c) {
        if (enCache != null) return enCache;
        List<Word> out = new ArrayList<>();
        try {
            String js = block(study(c), "lq-en");
            if (js != null) {
                JSONArray arr = new JSONArray(js);
                for (int i = 0; i < arr.length(); i++) {
                    JSONArray a = arr.getJSONArray(i);
                    Word w = new Word();
                    w.id = a.getInt(0);
                    w.w = a.getString(1);
                    w.m = a.getString(2);
                    w.ex = a.optString(3, "");
                    w.ko = a.optString(4, "");
                    String first = w.m.split(" ", 2)[0];
                    w.pos = first.endsWith(".") ? first : "";
                    w.day = (w.id - 1) / 30 + 1;          // VOCA 1800은 하루 30단어
                    w.sa = w.ex.indexOf('{');
                    w.sb = w.sa >= 0 ? w.ex.indexOf('}', w.sa + 1) : -1;
                    w.canS = w.sa >= 0 && w.sb > w.sa && w.ex.substring(w.sa + 1, w.sb).equalsIgnoreCase(w.w);
                    w.keys = meaningKeys(w.m);
                    out.add(w);
                }
            }
        } catch (Exception ignored) {
        }
        enCache = out;
        return out;
    }

    /** 단어장에 있는 Day 목록 (작은 것부터) */
    static List<Integer> enDays(Context c) {
        List<Integer> d = new ArrayList<>();
        for (Word w : enWords(c)) if (!d.contains(w.day)) d.add(w.day);
        Collections.sort(d);
        return d;
    }

    /** 문제 꼴: 0 뜻 고르기, 1 단어 고르기, 2 예문 빈칸 */
    static boolean enKind(Context c, int k) { return prefs(c).getBoolean("en_k" + k, true); }

    /** 잠금화면에 낼 낱말: 고른 Day·문제 꼴에서, '모르는 단어만'을 켰으면 외운 낱말을 빼요 (다 외웠으면 고른 범위 전체) */
    static List<Word> enPool(Context c) {
        List<Word> range = enRange(c);
        if (!enUnknownOnly(c)) return range;
        List<Word> out = enUnknown(c, range);
        return out.isEmpty() ? range : out;
    }

    /** 설정 화면용: {고른 범위 낱말 수, 그 가운데 아직 못 외운 낱말 수} */
    static int[] enCounts(Context c) {
        List<Word> range = enRange(c);
        return new int[]{range.size(), enUnknown(c, range).size()};
    }

    private static List<Word> enUnknown(Context c, List<Word> range) {
        Set<Integer> known = enKnown(c);
        List<Word> out = new ArrayList<>();
        for (Word w : range) if (!known.contains(w.id)) out.add(w);
        return out;
    }

    // ── 영어: 모르는 단어만 ──
    // 외운 단어는 단어장(공부 화면)과 같은 뜻: 3번 맞힌 낱말. 잠금화면에서 맞힌 것도 세요.
    // 잠금화면에서 푼 기록은 en_ev에 모아 두었다가 공부 화면이 열릴 때 단어장으로 넘겨요 (takeEnEvents).
    static final String EN_UNKNOWN = "en_unknown", EN_EV = "en_ev";
    static final int EN_MASTER = 3;
    private static final int EN_EV_MAX = 3000;
    private static long knownStamp = Long.MIN_VALUE;
    private static String knownEv;
    private static Set<Integer> knownCache;

    static boolean enUnknownOnly(Context c) { return prefs(c).getBoolean(EN_UNKNOWN, false); }

    /** en_ev 글자("1351:1,1352:0" = 번호:맞힘1/틀림0)를 [번호, 맞힘] 목록으로 */
    private static List<int[]> enEvents(String s) {
        List<int[]> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        for (String t : s.split(",")) {
            int i = t.indexOf(':');
            if (i <= 0) continue;
            try { out.add(new int[]{Integer.parseInt(t.substring(0, i)), "1".equals(t.substring(i + 1)) ? 1 : 0}); }
            catch (NumberFormatException ignored) {}
        }
        return out;
    }

    /** 외운 낱말 번호. 단어장 기록(공부 화면이 남긴 사본)에 아직 안 넘긴 잠금화면 기록을 더해서 셈해요 */
    static synchronized Set<Integer> enKnown(Context c) {
        long st = WebStore.stamp(c);
        String ev = prefs(c).getString(EN_EV, "");
        if (knownCache != null && st == knownStamp && ev.equals(knownEv)) return knownCache;
        Map<String, Integer> hits = new HashMap<>();
        try {
            String raw = WebStore.read(c);
            if (raw.length() > 0) {
                String h = new JSONObject(raw).optString("v1800b-hits", "");
                if (h.startsWith("{")) {
                    JSONObject o = new JSONObject(h);
                    java.util.Iterator<String> it = o.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        int n = o.optInt(k, 0);
                        if (n > 0) hits.put(k, n);
                    }
                }
            }
        } catch (Exception ignored) {
        }
        for (int[] e : enEvents(ev)) {
            String id = String.valueOf(e[0]);
            Integer n = hits.get(id);
            if (e[1] == 1) hits.put(id, (n == null ? 0 : n) + 1);
            else if (n != null && n >= EN_MASTER) hits.remove(id);   // 외운 낱말을 틀리면 다시 처음부터
        }
        Set<Integer> out = new HashSet<>();
        for (Map.Entry<String, Integer> e : hits.entrySet()) {
            if (e.getValue() < EN_MASTER) continue;
            try { out.add(Integer.parseInt(e.getKey())); } catch (NumberFormatException ignored) {}
        }
        knownStamp = st;
        knownEv = ev;
        knownCache = out;
        return out;
    }

    /** 잠금화면에서 푼 영어 낱말 하나를 단어장에 넘길 기록에 더해요 */
    private static synchronized void addEnEvent(Context c, int id, boolean ok) {
        SharedPreferences p = prefs(c);
        String s = p.getString(EN_EV, "");
        String t = id + ":" + (ok ? 1 : 0);
        s = s.isEmpty() ? t : s + "," + t;
        // 너무 쌓이면(공부 화면을 오래 안 열면) 오래된 것부터 버려요
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == ',') n++;
        if (n >= EN_EV_MAX) {
            int cut = 0;
            for (int k = 0; k <= n - EN_EV_MAX; k++) cut = s.indexOf(',', cut) + 1;
            s = s.substring(cut);
        }
        p.edit().putString(EN_EV, s).apply();
    }

    /** 공부 화면이 가져가는 잠금화면 영어 기록: [[번호, 1 맞힘 / 0 틀림], …] (가져가면 비워요) */
    static synchronized String takeEnEvents(Context c) {
        SharedPreferences p = prefs(c);
        List<int[]> ev = enEvents(p.getString(EN_EV, ""));
        StringBuilder b = new StringBuilder("[");
        for (int[] e : ev) {
            if (b.length() > 1) b.append(',');
            b.append('[').append(e[0]).append(',').append(e[1]).append(']');
        }
        b.append(']');
        p.edit().remove(EN_EV).apply();
        return b.toString();
    }

    /** 공부 화면이 닫혀 있을 때(동기화하기 전에) 잠금화면 영어 기록을 단어장 사본(webstore.json)에 바로 합쳐요.
     *  공부 화면의 __enSync와 같은 규칙: 맞히면 맞힌 횟수 +1·오답 노트에서 빼고, 틀리면 오답 노트에 넣고 외운 낱말이었으면 처음부터. */
    static synchronized boolean flushEnEventsToStore(Context c) {
        SharedPreferences p = prefs(c);
        List<int[]> ev = enEvents(p.getString(EN_EV, ""));
        if (ev.isEmpty()) return false;
        String raw = WebStore.read(c);
        Map<String, Object> snap = raw.isEmpty() ? new java.util.LinkedHashMap<String, Object>() : Json.objOf(raw);
        if (snap == null) return false;
        Object hv = snap.get("v1800b-hits"), wv = snap.get("v1800b-wrong");
        Map<String, Object> hits = hv instanceof String ? Json.objOf((String) hv) : null;
        if (hits == null) hits = new java.util.LinkedHashMap<>();
        List<Object> wl = wv instanceof String ? Json.arr(Json.tryParse((String) wv)) : null;
        java.util.LinkedHashSet<String> ws = new java.util.LinkedHashSet<>();
        if (wl != null) for (Object o : wl) ws.add(String.valueOf(o));
        for (int[] e : ev) {
            String id = String.valueOf(e[0]);
            Object n0 = hits.get(id);
            long n = n0 instanceof Number ? ((Number) n0).longValue() : 0;
            if (e[1] == 1) { ws.remove(id); hits.put(id, n + 1); }
            else { ws.add(id); if (n >= EN_MASTER) hits.remove(id); }
        }
        snap.put("v1800b-hits", Json.str(hits));
        snap.put("v1800b-wrong", Json.str(new ArrayList<Object>(ws)));
        WebStore.write(c, Json.str(snap));
        p.edit().remove(EN_EV).commit();
        knownCache = null;
        return true;
    }

    /** 고른 Day와 문제 꼴로 낼 수 있는 낱말 (외웠는지와 상관없이) */
    static List<Word> enRange(Context c) {
        SharedPreferences p = prefs(c);
        Set<String> days = p.getStringSet("en_days", null);
        boolean k0 = enKind(c, 0), k1 = enKind(c, 1), k2 = enKind(c, 2);
        List<Word> out = new ArrayList<>();
        if (!k0 && !k1 && !k2) return out;
        boolean onlyS = !k0 && !k1;
        for (Word w : enWords(c)) {
            if (days != null && !days.contains(String.valueOf(w.day))) continue;
            if (onlyS && !w.canS) continue;
            out.add(w);
        }
        return out;
    }

    private static Question nextSa(Context c, Random rnd) {
        List<PItem> pool = saPool(c);
        if (pool.isEmpty()) return null;
        SharedPreferences p = prefs(c);
        Set<String> wrong = p.getStringSet("wrong", new HashSet<String>());
        List<String> recent = recent(p);
        PItem pick = pickDue(pool, t -> "s:" + t.id, reviews(p), today(), rnd);
        boolean review = pick != null;
        if (pick == null && !wrong.isEmpty() && rnd.nextInt(100) < 25) {
            List<PItem> w = new ArrayList<>();
            for (PItem t : pool) if (wrong.contains("s:" + t.id)) w.add(t);
            if (!w.isEmpty()) pick = w.get(rnd.nextInt(w.size()));
        }
        if (pick == null) pick = pickWeighted(pool, t -> "s:" + t.id, Quiz::saUnit, recent, unitStats(c), rnd);
        Question q = saQuestion(pick, rnd);
        markReview(q, review);
        remember(p, q.key);
        return q;
    }

    private static String saUnit(PItem t) { return t.unit >= 0 ? "sa:" + t.unit : ""; }

    /** 통합사회 문제 하나로 카드 만들기 (O/X처럼 순서가 정해진 것 말고는 보기를 섞어요) */
    static Question saQuestion(PItem pick, Random rnd) {
        Question q = new Question();
        q.type = TYPE_TEXT;
        q.unit = saUnit(pick);
        q.key = "s:" + pick.id;
        q.tag = pick.tag;
        q.prompt = pick.q;
        q.ask = pick.ask;
        q.color = C_SA;
        q.promptSp = pick.sp;
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < pick.o.size(); i++) order.add(i);
        if (!pick.fixed) Collections.shuffle(order, rnd);
        for (int i : order) {
            q.options.add(pick.o.get(i));
            if (i == pick.a) q.answer = q.options.size() - 1;
        }
        q.explain = "정답: " + pick.o.get(pick.a) + (pick.x.length() > 0 ? "\n" + pick.x : "");
        return q;
    }

    /** 영어 낱말이 모음 소리로 시작하나 (an을 쓰나) */
    static boolean vowelSound(String w) {
        String s = w.toLowerCase(java.util.Locale.ROOT);
        if (s.isEmpty()) return false;
        if (s.startsWith("hour") || s.startsWith("honest") || s.startsWith("honor") || s.startsWith("honour") || s.startsWith("heir")) return true;
        if (s.startsWith("uni") || s.startsWith("use") || s.startsWith("usu") || s.startsWith("uti") || s.startsWith("eu")
                || s.startsWith("one") || s.startsWith("once") || s.startsWith("ura") || s.startsWith("uro")) return false;
        return "aeiou".indexOf(s.charAt(0)) >= 0;
    }

    private static Question nextEn(Context c, Random rnd) {
        List<Word> all = enWords(c);
        List<Word> pool = enPool(c);
        if (all.size() < 4 || pool.isEmpty()) return null;
        SharedPreferences p = prefs(c);
        Set<String> wrong = p.getStringSet("wrong", new HashSet<String>());
        List<String> recent = recent(p);
        Word pick = pickDue(pool, t -> "e:" + t.id, reviews(p), today(), rnd);
        boolean review = pick != null;
        if (pick == null && !wrong.isEmpty() && rnd.nextInt(100) < 25) {
            List<Word> w = new ArrayList<>();
            for (Word t : pool) if (wrong.contains("e:" + t.id)) w.add(t);
            if (!w.isEmpty()) pick = w.get(rnd.nextInt(w.size()));
        }
        if (pick == null) pick = pickWeighted(pool, t -> "e:" + t.id, t -> "en:" + t.day, recent, unitStats(c), rnd);
        // 고른 문제 꼴 가운데 하나 (예문 빈칸은 예문 속 낱말이 기본형 그대로일 때만)
        List<Integer> kinds = new ArrayList<>();
        if (enKind(c, 0)) kinds.add(0);
        if (enKind(c, 1)) kinds.add(1);
        if (enKind(c, 2) && pick.canS) kinds.add(2);
        if (kinds.isEmpty()) return null;
        int kind = kinds.get(rnd.nextInt(kinds.size()));
        Question q = enQuestion(all, pick, kind, rnd);
        markReview(q, review);
        remember(p, q.key);
        return q;
    }

    /** 영어 낱말 하나로 카드 만들기. kind 0: 뜻 고르기, 1: 단어 고르기, 2: 예문 빈칸 */
    static Question enQuestion(List<Word> all, Word pick, int kind, Random rnd) {
        // 예문 빈칸 바로 앞이 a / an이면 보기도 그 소리로 시작하는 낱말만 (an 뒤에 자음 낱말이 끼면 바로 지워져요)
        Boolean vowel = null;
        if (kind == 2) {
            String before = pick.ex.substring(0, pick.sa).trim();
            String lw = before.substring(before.lastIndexOf(' ') + 1).toLowerCase(java.util.Locale.ROOT);
            if (lw.equals("a")) vowel = false;
            else if (lw.equals("an")) vowel = true;
        }
        // 보기는 같은 품사에서 3개 (모자라면 아무 낱말). 답과 뜻이 겹치는 낱말은 빼요 (답이 둘이 되지 않게)
        List<Word> src = new ArrayList<>();
        for (Word w : all) if (w.id != pick.id && !overlaps(w, pick) && w.pos.equals(pick.pos) && (vowel == null || vowelSound(w.w) == vowel)) src.add(w);
        if (src.size() < 3 && vowel != null) {
            src.clear();
            for (Word w : all) if (w.id != pick.id && !overlaps(w, pick) && vowelSound(w.w) == vowel) src.add(w);
        }
        if (src.size() < 3) {
            src.clear();
            for (Word w : all) if (w.id != pick.id && !overlaps(w, pick) && w.pos.equals(pick.pos)) src.add(w);
        }
        if (src.size() < 3) {
            src.clear();
            for (Word w : all) if (w.id != pick.id && !overlaps(w, pick)) src.add(w);
        }
        Collections.shuffle(src, rnd);
        List<Word> opts = new ArrayList<>();
        opts.add(pick);
        for (Word w : src) {
            if (opts.size() == 4) break;
            String t = kind == 0 ? w.m : w.w;
            boolean dup = false;
            for (Word o : opts) if ((kind == 0 ? o.m : o.w).equalsIgnoreCase(t) || overlaps(o, w)) dup = true;   // 오답끼리도 뜻이 겹치지 않게
            if (!dup) opts.add(w);
        }
        Collections.shuffle(opts, rnd);
        Question q = new Question();
        q.type = TYPE_TEXT;
        q.key = "e:" + pick.id;
        q.unit = "en:" + pick.day;
        q.color = C_EN;
        q.tag = "영어 · Day " + pick.day + " · " + pick.id + "번";
        String exPlain = pick.ex.replace("{", "").replace("}", "");
        if (kind == 0) {
            q.prompt = pick.w;
            q.ask = "뜻으로 알맞은 것은?";
            q.promptSp = 30;
        } else if (kind == 1) {
            q.prompt = pick.m;
            q.ask = "이 뜻을 가진 단어는?";
            q.promptSp = 22;
        } else {
            q.prompt = (pick.ex.substring(0, pick.sa) + "_____" + pick.ex.substring(pick.sb + 1)).replace("{", "").replace("}", "");
            q.ask = "빈칸에 알맞은 단어는?  (" + pick.ko + ")";
            q.promptSp = 19;
        }
        for (Word w : opts) {
            q.options.add(kind == 0 ? w.m : w.w);
            if (w.id == pick.id) q.answer = q.options.size() - 1;
        }
        q.explain = pick.w + "  " + pick.m + (exPlain.length() > 0 ? "\n" + exPlain : "") + (pick.ko.length() > 0 ? "\n" + pick.ko : "");
        return q;
    }

    /** 한국사 문제 (연표·순서·교과서) */
    private static Question nextKs(Context c, Random rnd) {
        List<Row> all = rows(c);
        SharedPreferences p = prefs(c);
        Range g = range(c);
        boolean when = p.getBoolean("t_when", true);
        boolean what = p.getBoolean("t_what", true);
        boolean ord = p.getBoolean("t_order", true);
        boolean txt = p.getBoolean("t_text", true);

        List<Integer> pool = (when || what) && all.size() >= 8 ? rowPool(c, g) : new ArrayList<Integer>();
        List<OQ> opool = ord ? orderPool(c, g) : new ArrayList<OQ>();
        List<TItem> tpool = txt ? textPool(c, g) : new ArrayList<TItem>();
        boolean useRows = !pool.isEmpty(), useOrder = !opool.isEmpty(), useText = !tpool.isEmpty();
        if (!useRows && !useOrder && !useText) return null;
        // 켜진 종류 가운데 하나를 고르게 고른다
        List<Integer> kinds = new ArrayList<>();
        if (useRows) kinds.add(0);
        if (useOrder) kinds.add(1);
        if (useText) kinds.add(2);
        int kind = kinds.get(rnd.nextInt(kinds.size()));
        useRows = kind == 0; useOrder = kind == 1; useText = kind == 2;

        Set<String> wrong = p.getStringSet("wrong", new HashSet<String>());
        List<String> recent = recent(p);
        Map<String, int[]> rv = reviews(p);
        Map<String, Object> ust = unitStats(c);
        int today = today();
        boolean review;
        Question q;

        if (useText) {
            TItem pick = pickDue(tpool, t -> "x:" + t.id, rv, today, rnd);
            review = pick != null;
            if (pick == null && !wrong.isEmpty() && rnd.nextInt(100) < 25) {
                List<TItem> w = new ArrayList<>();
                for (TItem t : tpool) if (wrong.contains("x:" + t.id)) w.add(t);
                if (!w.isEmpty()) pick = w.get(rnd.nextInt(w.size()));
            }
            if (pick == null) pick = pickWeighted(tpool, t -> "x:" + t.id, t -> ksUnit(t.ch), recent, ust, rnd);
            q = buildText(pick);
            q.unit = ksUnit(pick.ch);
        } else if (useOrder) {
            OQ pick = pickDue(opool, o -> "o:" + o.id, rv, today, rnd);
            review = pick != null;
            // 틀린 문제는 가끔 다시 나와요
            if (pick == null && !wrong.isEmpty() && rnd.nextInt(100) < 25) {
                List<OQ> w = new ArrayList<>();
                for (OQ o : opool) if (wrong.contains("o:" + o.id)) w.add(o);
                if (!w.isEmpty()) pick = w.get(rnd.nextInt(w.size()));
            }
            if (pick == null) pick = pickWeighted(opool, o -> "o:" + o.id, Quiz::orderUnit, recent, ust, rnd);
            q = buildOrder(pick, rnd);
            q.unit = orderUnit(pick);
        } else {
            Integer due = pickDue(pool, i -> String.valueOf(all.get(i).n), rv, today, rnd);
            review = due != null;
            int idx = due == null ? -1 : due;
            if (idx < 0 && !wrong.isEmpty() && rnd.nextInt(100) < 25) {
                List<Integer> w = new ArrayList<>();
                for (int i : pool) if (wrong.contains(String.valueOf(all.get(i).n))) w.add(i);
                if (!w.isEmpty()) idx = w.get(rnd.nextInt(w.size()));
            }
            if (idx < 0) idx = pickWeighted(pool, i -> String.valueOf(all.get(i).n), i -> ksUnit(all.get(i).ch), recent, ust, rnd);
            int type;
            if (when && what) type = rnd.nextBoolean() ? TYPE_WHEN : TYPE_WHAT;
            else if (what) type = TYPE_WHAT;
            else type = TYPE_WHEN;
            q = build(all, idx, type, rnd);
            if (q == null) q = build(all, idx, type == TYPE_WHEN ? TYPE_WHAT : TYPE_WHEN, rnd);
            // 연도 문제로 못 내는 줄('1970년대 말' 같은)이면 다른 줄로
            for (int tries = 0; q == null && tries < 15; tries++) q = build(all, pool.get(rnd.nextInt(pool.size())), type, rnd);
            if (q != null && q.row != null) q.unit = ksUnit(q.row.ch);
            if (q != null && q.row != null && q.row.n != all.get(idx).n) review = false;
        }
        if (q != null) {
            markReview(q, review);
            remember(p, q.key);
        }
        return q;
    }

    private static String orderUnit(OQ o) {
        Set<String> ch = new HashSet<>();
        for (OEvent e : o.ev) ch.addAll(e.ch);
        return ksUnit(ch);
    }

    /** 한국사 단원 이름표: 가장 앞 중단원 */
    static String ksUnit(Set<String> ch) {
        String best = null;
        for (String x : ch) if (best == null || x.compareTo(best) < 0) best = x;
        return best == null ? "" : "ks:" + best;
    }

    private static void markReview(Question q, boolean review) {
        q.review = review;
        if (review) q.tag = "복습 · " + q.tag;
    }

    // ───────── 복습 간격 · 약한 단원 ─────────

    /** 틀린 문제는 1일 → 3일 → 7일 뒤에 다시 내요. 세 번 제때 맞히면 복습이 끝나요 */
    static final int[] RV_GAP = {1, 3, 7};
    static final String RV = "rv", UST = "ust";

    static int today() { return Integer.parseInt(dayKey()); }

    static int addDays(int ymd, int days) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.clear();
        cal.set(ymd / 10000, ymd / 100 % 100 - 1, ymd % 100);
        cal.add(java.util.Calendar.DAY_OF_MONTH, days);
        return cal.get(java.util.Calendar.YEAR) * 10000 + (cal.get(java.util.Calendar.MONTH) + 1) * 100 + cal.get(java.util.Calendar.DAY_OF_MONTH);
    }

    /** 복습 표: 문제 → {단계, 다시 낼 날 yyyyMMdd}.
     *  두 기기에서 따로 바뀌어 한 문제가 두 줄이면 더 이른 단계(더 자주 복습하는 쪽)를 따라요 */
    static Map<String, int[]> reviews(SharedPreferences p) {
        Map<String, int[]> m = new HashMap<>();
        for (String x : p.getStringSet(RV, new HashSet<String>())) {
            String[] f = x.split("\t");
            if (f.length != 3) continue;
            try {
                int st = Integer.parseInt(f[1]), due = Integer.parseInt(f[2]);
                int[] old = m.get(f[0]);
                if (old == null || st < old[0] || (st == old[0] && due < old[1])) m.put(f[0], new int[]{st, due});
            } catch (NumberFormatException ignored) {
            }
        }
        return m;
    }

    private static Set<String> reviewSet(Map<String, int[]> m) {
        Set<String> out = new HashSet<>();
        for (Map.Entry<String, int[]> e : m.entrySet()) out.add(e.getKey() + "\t" + e.getValue()[0] + "\t" + e.getValue()[1]);
        return out;
    }

    /** {오늘 복습할 수, 복습 중인 모든 수} */
    static int[] reviewCounts(Context c) {
        int t = today(), due = 0;
        Map<String, int[]> m = reviews(prefs(c));
        for (int[] e : m.values()) if (e[1] <= t) due++;
        return new int[]{due, m.size()};
    }

    /** 단원별로 맞힌 수·푼 수: {"ks:3": {"o": 5, "n": 9}, …} (두 기기에서 푼 만큼 동기화 때 더해져요) */
    static Map<String, Object> unitStats(Context c) {
        Map<String, Object> m = Json.objOf(prefs(c).getString(UST, ""));
        return m == null ? new java.util.LinkedHashMap<String, Object>() : m;
    }

    /** 약한 정도 1~3: 5문제 넘게 푼 단원만, 정답률이 낮을수록 커요 */
    static float weakness(Map<String, Object> ust, String unit) {
        Map<String, Object> st = Json.obj(ust.get(unit));
        long n = Json.l(st, "n"), o = Json.l(st, "o");
        if (n < 5) return 1f;
        return 1f + 2f * (1f - Math.min(1f, o / (float) n));
    }

    /** 단원 이름: "ks:3" → "II-03 민주화를 위한 노력", "sa:1" → "Ⅱ. 사회정의와 불평등", "en:47" → "Day 47" */
    static String unitName(Context c, String unit) {
        try {
            if (unit.startsWith("ks:")) {
                String code = unit.substring(3);
                for (Chapter ch : chapters(c)) if (ch.c.equals(code)) return ch.name;
            } else if (unit.startsWith("sa:")) {
                int i = Integer.parseInt(unit.substring(3));
                List<String[]> us = saUnits(c);
                if (i >= 0 && i < us.size()) return us.get(i)[0];
            } else if (unit.startsWith("en:")) {
                return "Day " + unit.substring(3);
            }
        } catch (Exception ignored) {
        }
        return unit;
    }

    /** 약한 단원: 5문제 넘게 풀었고 정답률이 80%보다 낮은 단원을 낮은 순으로. {단원, 이름, 정답률(%), 푼 수} */
    static List<String[]> weakUnits(Context c, int max) {
        List<Object[]> rows = new ArrayList<>();
        for (Map.Entry<String, Object> e : unitStats(c).entrySet()) {
            Map<String, Object> st = Json.obj(e.getValue());
            long n = Json.l(st, "n"), o = Json.l(st, "o");
            if (n < 5) continue;
            double r = o / (double) n;
            if (r >= 0.8) continue;
            rows.add(new Object[]{e.getKey(), r, n});
        }
        Collections.sort(rows, (x, y) -> Double.compare((Double) x[1], (Double) y[1]));
        List<String[]> out = new ArrayList<>();
        for (Object[] r : rows) {
            if (out.size() >= max) break;
            String u = (String) r[0];
            out.add(new String[]{u, unitName(c, u), String.valueOf(Math.round((Double) r[1] * 100)), String.valueOf(r[2])});
        }
        return out;
    }

    private interface KeyOf<T> { String key(T t); }

    /** 오늘 복습할 문제가 있으면 60% 확률로 그중에서 골라요 */
    private static <T> T pickDue(List<T> pool, KeyOf<T> kf, Map<String, int[]> rv, int today, Random rnd) {
        if (rv.isEmpty() || rnd.nextInt(100) >= 60) return null;
        List<T> due = new ArrayList<>();
        for (T t : pool) {
            int[] e = rv.get(kf.key(t));
            if (e != null && e[1] <= today) due.add(t);
        }
        return due.isEmpty() ? null : due.get(rnd.nextInt(due.size()));
    }

    /** 아무 문제나 고를 때: 최근에 낸 건 피하고, 약한 단원 문제는 더 자주 (최대 3배) */
    private static <T> T pickWeighted(List<T> pool, KeyOf<T> kf, KeyOf<T> uf, List<String> recent, Map<String, Object> ust, Random rnd) {
        T pick = null;
        for (int tries = 0; tries < 40; tries++) {
            T t = pool.get(rnd.nextInt(pool.size()));
            if (tries < 30 && recent.contains(kf.key(t))) continue;
            pick = t;
            if (rnd.nextFloat() * 3f < weakness(ust, uf.key(t))) break;
        }
        return pick != null ? pick : pool.get(rnd.nextInt(pool.size()));
    }

    /** 기록 이름으로 그 문제의 단원 ("ks:3" 같은). 모르면 빈 글자 */
    static String unitOf(Context c, String key) {
        if (key == null) return "";
        try {
            if (key.startsWith("s:")) {
                String id = key.substring(2);
                for (PItem t : saItems(c)) if (t.id.equals(id)) return saUnit(t);
                return "";
            }
            if (key.startsWith("e:")) {
                int id = Integer.parseInt(key.substring(2));
                for (Word w : enWords(c)) if (w.id == id) return "en:" + w.day;
                return "";
            }
            if (key.startsWith("x:")) {
                String id = key.substring(2);
                for (TItem t : texts(c)) if (t.id.equals(id)) return ksUnit(t.ch);
                return "";
            }
            if (key.startsWith("o:")) {
                String id = key.substring(2);
                for (OQ o : orders(c)) if (o.id.equals(id)) return orderUnit(o);
                return "";
            }
            int n = Integer.parseInt(key);
            for (Row r : rows(c)) if (r.n == n) return ksUnit(r.ch);
        } catch (Exception ignored) {
        }
        return "";
    }

    /** 오답 노트: 기록 이름으로 그 문제를 다시 만들어요 (없어진 문제면 null) */
    static Question byKey(Context c, String key, Random rnd) {
        try {
            if (key.startsWith("s:")) {
                String id = key.substring(2);
                for (PItem t : saItems(c)) if (t.id.equals(id)) return saQuestion(t, rnd);
                return null;
            }
            if (key.startsWith("e:")) {
                int id = Integer.parseInt(key.substring(2));
                List<Word> all = enWords(c);
                for (Word w : all) if (w.id == id) return all.size() >= 4 ? enQuestion(all, w, 0, rnd) : null;
                return null;
            }
            if (key.startsWith("x:")) {
                String id = key.substring(2);
                for (TItem t : texts(c)) if (t.id.equals(id)) { Question q = buildText(t); q.unit = ksUnit(t.ch); return q; }
                return null;
            }
            if (key.startsWith("o:")) {
                String id = key.substring(2);
                for (OQ o : orders(c)) if (o.id.equals(id)) { Question q = buildOrder(o, rnd); q.unit = orderUnit(o); return q; }
                return null;
            }
            int n = Integer.parseInt(key);
            List<Row> all = rows(c);
            for (int i = 0; i < all.size(); i++) {
                if (all.get(i).n != n) continue;
                Question q = build(all, i, TYPE_WHAT, rnd);
                if (q == null) q = build(all, i, TYPE_WHEN, rnd);
                if (q != null) q.unit = ksUnit(all.get(i).ch);
                return q;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String typeName(String t) {
        switch (t) {
            case "mc": return "일반";
            case "term": return "용어";
            case "gov": return "어느 정부";
            case "when": return "몇 년";
            case "ox": return "O·X";
            default: return "교과서";
        }
    }

    private static Question buildText(TItem t) {
        Question q = new Question();
        q.item = t;
        q.type = TYPE_TEXT;
        q.key = "x:" + t.id;
        StringBuilder pg = new StringBuilder();
        for (int i = 0; i < t.pages.length; i++) { if (i > 0) pg.append("·"); pg.append(t.pages[i]); }
        q.tag = "교과서 · " + (t.tn.length() > 0 ? t.tn : typeName(t.type)) + (pg.length() > 0 ? " · " + pg + "쪽" : "");
        q.prompt = t.q;
        q.ask = t.ask;
        q.options.addAll(t.o);
        q.answer = t.a;
        q.explain = "정답: " + t.o.get(t.a) + "\n" + t.x + (pg.length() > 0 ? "\n(교과서 " + pg + "쪽)" : "");
        return q;
    }

    private static Question build(List<Row> all, int idx, int type, Random rnd) {
        Row row = all.get(idx);
        Question q = new Question();
        q.row = row;
        q.type = type;
        q.key = String.valueOf(row.n);
        q.tag = "한국사2 연표 " + row.n + "번" + (row.world ? " · 세계사" : "");
        // 보기와 문제에는 연도만 보여 줘요. '1·4 후퇴'처럼 이름에 달·날짜가 들어간 사건은
        // 보기에 달이 있으면 그것만 맞춰 봐도 답이 나와서예요. 오답은 늘 다른 해라서 연도만으로 충분해요.
        boolean byYear = row.year != 0;
        if (byYear && !row.exact) return null;     // 해가 딱 정해지지 않은 줄은 연도 문제로 내지 않아요
        if (type == TYPE_WHAT && row.world) return null;   // 세계사 줄 하나만 끼면 그게 답인 게 보여서 '언제' 문제로만
        String correct;
        if (type == TYPE_WHEN) {
            q.prompt = hideYears(row.text);
            q.ask = !byYear ? "언제 있었던 일일까요?" : row.yearTo > row.year ? "몇 년에 시작된 일일까요?" : "몇 년에 있었던 일일까요?";
            correct = byYear ? row.year + "년" : row.ctx;
        } else {
            q.prompt = byYear ? row.year + "년" : row.ctx;
            q.ask = byYear ? "이 해에 있었던 일은 무엇일까요?" : "이때 있었던 일은 무엇일까요?";
            correct = hideYears(row.text);
        }

        // 오답 후보: 가까운 줄부터, 정답과 연도가 다른 것만 (헷갈리되 답이 둘이 되지 않게)
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) if (i != idx) order.add(i);
        final int center = idx;
        Collections.sort(order, (a, b) -> Integer.compare(Math.abs(a - center), Math.abs(b - center)));

        List<String> cands = new ArrayList<>();
        for (int i : order) {
            Row o = all.get(i);
            if (byYear) {
                if (o.year == 0) continue;
                if (type == TYPE_WHEN) {
                    if (o.year >= row.year && o.year <= row.yearTo) continue;   // 정답 사건이 이어지던 해는 오답으로 안 써요
                } else {
                    if (!o.exact || o.world) continue;
                    if (row.year >= o.year && row.year <= o.yearTo) continue;   // 그 해에도 이어지던 사건은 오답으로 안 써요
                }
            } else if (o.ctx.equals(row.ctx)) continue;
            String label = type == TYPE_WHEN ? (byYear ? o.year + "년" : o.ctx) : hideYears(o.text);
            if (label.equals(correct) || cands.contains(label)) continue;
            cands.add(label);
            if (cands.size() >= 12) break;
        }
        if (cands.size() < 3) return null;
        Collections.shuffle(cands, rnd);

        q.options.add(correct);
        q.options.addAll(cands.subList(0, 3));
        Collections.shuffle(q.options, rnd);
        q.answer = q.options.indexOf(correct);
        q.explain = row.ctx + "  " + row.text;
        return q;
    }

    private static final java.util.regex.Pattern YEAR = java.util.regex.Pattern.compile("(?<!\\d)(1[89]\\d\\d|20\\d\\d)(?!\\d)");
    private static final java.util.regex.Pattern SPAN_END = java.util.regex.Pattern.compile("~\\s*(1[89]\\d\\d|20\\d\\d)");

    /** 사건 글 속 연도 숫자는 가려요 (예: '1949년 8월로 단축' → '○○○○년 8월로 단축') */
    private static String hideYears(String text) {
        return YEAR.matcher(text).replaceAll("○○○○");
    }

    /** '(~1978)', '(1972~1981)'처럼 이어진 사건의 끝난 해 */
    private static int spanEnd(String text, int from) {
        int to = from;
        java.util.regex.Matcher m = SPAN_END.matcher(text);
        while (m.find()) to = Math.max(to, Integer.parseInt(m.group(1)));
        return to;
    }

    /** 순서 문제: 사건을 섞어 ㄱ·ㄴ·ㄷ(·ㄹ)을 붙이고, 시험처럼 순서 보기 5개 중에서 고르게 해요 */
    private static Question buildOrder(OQ oq, Random rnd) {
        int n = oq.ev.size();
        List<Integer> disp = new ArrayList<>();          // disp.get(k) = 화면 k번째 사건의 실제 순서
        for (int i = 0; i < n; i++) disp.add(i);
        Collections.shuffle(disp, rnd);
        List<Integer> answer = new ArrayList<>();        // 정답: 일어난 순서대로 화면 번호
        for (int r = 0; r < n; r++) answer.add(disp.indexOf(r));

        List<List<Integer>> wrongs = new ArrayList<>();
        permute(new ArrayList<Integer>(), new ArrayList<>(answer), wrongs);
        wrongs.removeIf(x -> x.equals(answer));
        List<List<Integer>> near = new ArrayList<>();
        for (List<Integer> x : wrongs) {
            int diff = 0;
            for (int i = 0; i < n; i++) if (!x.get(i).equals(answer.get(i))) diff++;
            if (diff == 2) near.add(x);
        }
        Collections.shuffle(near, rnd);
        Collections.shuffle(wrongs, rnd);
        List<List<Integer>> picks = new ArrayList<>();
        for (List<Integer> x : near) if (picks.size() < 2) picks.add(x);
        for (List<Integer> x : wrongs) if (picks.size() < 4 && !picks.contains(x)) picks.add(x);
        picks.add(answer);
        Collections.sort(picks, (a, b) -> seq(a).compareTo(seq(b)));

        Question q = new Question();
        q.oq = oq;
        q.type = TYPE_ORDER;
        q.key = "o:" + oq.id;
        q.tag = "교과서 순서 · 사건 " + n + "개";
        q.prompt = "일어난 순서대로 옳게 나열한 것은?";
        q.ask = "";
        for (int k = 0; k < n; k++) q.lines.add(KL[k] + ". " + oq.ev.get(disp.get(k)).text);
        for (List<Integer> x : picks) q.options.add(seq(x));
        q.answer = picks.indexOf(answer);
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < n; r++) {
            OEvent e = oq.ev.get(r);
            if (r > 0) sb.append('\n');
            sb.append(KL[answer.get(r)]).append("  ").append(e.disp).append("  ").append(e.text)
              .append(" (교과서 ").append(pagesText(e.pages)).append("쪽)");
        }
        q.explain = sb.toString();
        return q;
    }

    private static void permute(List<Integer> pre, List<Integer> rest, List<List<Integer>> out) {
        if (rest.isEmpty()) { out.add(new ArrayList<>(pre)); return; }
        for (int i = 0; i < rest.size(); i++) {
            List<Integer> p2 = new ArrayList<>(pre);
            p2.add(rest.get(i));
            List<Integer> r2 = new ArrayList<>(rest);
            r2.remove(i);
            permute(p2, r2, out);
        }
    }

    private static String seq(List<Integer> s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.size(); i++) {
            if (i > 0) b.append(" → ");
            b.append(KL[s.get(i)]);
        }
        return b.toString();
    }

    private static String pagesText(int[] pages) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < pages.length; i++) {
            if (i > 0) b.append('·');
            b.append(pages[i]);
        }
        return b.toString();
    }

    private static List<String> recent(SharedPreferences p) {
        List<String> out = new ArrayList<>();
        String s = p.getString("recent", "");
        if (s.length() == 0) return out;
        Collections.addAll(out, s.split(","));
        return out;
    }

    private static void remember(SharedPreferences p, String key) {
        List<String> r = recent(p);
        r.remove(key);
        r.add(key);
        while (r.size() > 40) r.remove(0);
        p.edit().putString("recent", String.join(",", r)).apply();
    }

    // ───────── 기록 ─────────

    /** 잠금화면 기록을 고치는 동안 동기화가 같이 쓰지 않게 잡는 자물쇠 */
    static final Object PLOCK = new Object();

    static void record(Context c, String key, boolean ok) {
        if (key != null && key.startsWith("e:")) {
            try { addEnEvent(c, Integer.parseInt(key.substring(2)), ok); } catch (NumberFormatException ignored) {}
        }
        String unit = unitOf(c, key);
        synchronized (PLOCK) { recordLocked(c, key, ok, unit); }
    }

    private static void recordLocked(Context c, String key, boolean ok, String unit) {
        SharedPreferences p = prefs(c);
        // 복습 표: 틀리면 내일부터 다시, 복습할 날에 맞히면 다음 단계로 (세 번이면 끝)
        Map<String, int[]> rv = reviews(p);
        int t = today();
        if (!ok) {
            rv.put(key, new int[]{0, addDays(t, RV_GAP[0])});
        } else {
            int[] e = rv.get(key);
            if (e != null && e[1] <= t) {
                int st = e[0] + 1;
                if (st >= RV_GAP.length) rv.remove(key);
                else rv.put(key, new int[]{st, addDays(t, RV_GAP[st])});
            }
        }
        // 단원별 정답률
        Map<String, Object> ust = unitStats(c);
        if (unit != null && !unit.isEmpty()) {
            Map<String, Object> st = Json.obj(ust.get(unit));
            if (st == null) st = new java.util.LinkedHashMap<>();
            st.put("o", Json.l(st, "o") + (ok ? 1 : 0));
            st.put("n", Json.l(st, "n") + 1);
            ust.put(unit, st);
        }
        Set<String> wrong = new HashSet<>(p.getStringSet("wrong", new HashSet<String>()));
        if (ok) wrong.remove(key);
        else wrong.add(key);
        String day = dayKey();
        int dayN = day.equals(p.getString("day", "")) ? p.getInt("day_n", 0) + 1 : 1;
        p.edit()
                .putInt("total", p.getInt("total", 0) + 1)
                .putInt("correct", p.getInt("correct", 0) + (ok ? 1 : 0))
                .putInt("streak", ok ? p.getInt("streak", 0) + 1 : 0)
                .putStringSet("wrong", wrong)
                .putString("day", day)
                .putInt("day_n", dayN)
                .putStringSet(RV, reviewSet(rv))
                .putString(UST, Json.str(ust))
                .apply();
    }

    /** 오늘 잠금화면에서 푼 문제 수 */
    static int today(Context c) {
        SharedPreferences p = prefs(c);
        return dayKey().equals(p.getString("day", "")) ? p.getInt("day_n", 0) : 0;
    }

    /** 하루 목표 (링이 다 차는 수) */
    static final int DAY_GOAL = 5;

    private static String dayKey() {
        return new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.KOREA).format(new java.util.Date());
    }

    static int total(Context c) { return prefs(c).getInt("total", 0); }
    static int correct(Context c) { return prefs(c).getInt("correct", 0); }
    static int streak(Context c) { return prefs(c).getInt("streak", 0); }
    static int wrongCount(Context c) { return prefs(c).getStringSet("wrong", new HashSet<String>()).size(); }

    static void resetStats(Context c) {
        prefs(c).edit().remove("total").remove("correct").remove("streak").remove("wrong").remove("recent").remove(RV).remove(UST).apply();
    }

    // ───────── 설정 ─────────

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("quiz", Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) { return prefs(c).getBoolean("enabled", false); }

    static void setEnabled(Context c, boolean on) { prefs(c).edit().putBoolean("enabled", on).apply(); }

    /** 문제 사이 최소 간격(분). 0이면 화면을 켤 때마다. */
    static int intervalMin(Context c) { return prefs(c).getInt("interval", 0); }

    static void setIntervalMin(Context c, int m) { prefs(c).edit().putInt("interval", m).apply(); }

    static boolean dueNow(Context c) {
        long last = prefs(c).getLong("last", 0);
        long gap = intervalMin(c) * 60_000L;
        long now = System.currentTimeMillis();
        return gap == 0 || now - last >= gap || now < last;
    }

    static void markShown(Context c) { prefs(c).edit().putLong("last", System.currentTimeMillis()).apply(); }
}
