package com.js.hanguksaquiz;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** 연표 데이터(assets/quiz.json)로 문제를 만들고, 설정과 기록을 저장해요. */
final class Quiz {

    static final class Row {
        int n;          // 빈칸표 번호 (1~289)
        String date;    // 빈칸표에 적힌 날짜 칸 ("1948. 5.", "→" 등)
        String text;    // 사건
        String ctx;     // 실제 시기 ("→"는 위 칸의 날짜로 채워 둠)
        boolean world;  // 세계사 줄
        int year;       // ctx 앞 네 자리
    }

    static final class Question {
        Row row;
        int type;               // TYPE_WHEN 또는 TYPE_WHAT
        String prompt;          // 큰 글씨 문제
        String ask;             // 작은 질문 문구
        List<String> options = new ArrayList<>();
        int answer;             // options 안의 정답 위치
    }

    static final int TYPE_WHEN = 0; // 사건을 보고 시기 맞히기
    static final int TYPE_WHAT = 1; // 시기를 보고 사건 맞히기

    private static List<Row> cache;

    private Quiz() {}

    static synchronized List<Row> rows(Context c) {
        if (cache != null) return cache;
        List<Row> list = new ArrayList<>();
        try (InputStream in = c.getAssets().open("quiz.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int k;
            while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
            JSONArray arr = new JSONArray(new String(out.toByteArray(), StandardCharsets.UTF_8));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Row r = new Row();
                r.n = o.getInt("n");
                r.date = o.getString("d");
                r.text = o.getString("t");
                r.ctx = o.getString("c");
                r.world = o.optInt("w", 0) == 1;
                r.year = yearOf(r.ctx);
                list.add(r);
            }
        } catch (Exception e) {
            // 데이터가 깨졌을 때는 빈 목록 (화면에서 안내)
        }
        cache = list;
        return list;
    }

    private static int yearOf(String s) {
        int y = 0, digits = 0;
        for (int i = 0; i < s.length() && digits < 4; i++) {
            char ch = s.charAt(i);
            if (ch >= '0' && ch <= '9') {
                y = y * 10 + (ch - '0');
                digits++;
            } else if (digits > 0) {
                break;
            }
        }
        return digits == 4 ? y : 0;
    }

    // ───────── 문제 만들기 ─────────

    static Question next(Context c, Random rnd) {
        List<Row> all = rows(c);
        if (all.size() < 8) return null;
        SharedPreferences p = prefs(c);
        boolean withWorld = p.getBoolean("world", true);

        List<Integer> pool = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) {
            if (withWorld || !all.get(i).world) pool.add(i);
        }
        if (pool.isEmpty()) return null;

        // 틀린 문제는 35% 확률로 다시 나와요
        int idx = -1;
        Set<String> wrong = p.getStringSet("wrong", new HashSet<String>());
        if (!wrong.isEmpty() && rnd.nextInt(100) < 35) {
            List<Integer> w = new ArrayList<>();
            for (int i : pool) if (wrong.contains(String.valueOf(all.get(i).n))) w.add(i);
            if (!w.isEmpty()) idx = w.get(rnd.nextInt(w.size()));
        }
        if (idx < 0) {
            List<String> recent = recent(p);
            for (int tries = 0; tries < 30; tries++) {
                idx = pool.get(rnd.nextInt(pool.size()));
                if (!recent.contains(String.valueOf(all.get(idx).n))) break;
            }
        }

        boolean when = p.getBoolean("t_when", true);
        boolean what = p.getBoolean("t_what", true);
        int type;
        if (when && what) type = rnd.nextBoolean() ? TYPE_WHEN : TYPE_WHAT;
        else if (what) type = TYPE_WHAT;
        else type = TYPE_WHEN;

        Question q = build(all, idx, type, rnd);
        if (q == null) q = build(all, idx, type == TYPE_WHEN ? TYPE_WHAT : TYPE_WHEN, rnd);
        if (q != null) remember(p, q.row.n);
        return q;
    }

    private static Question build(List<Row> all, int idx, int type, Random rnd) {
        Row row = all.get(idx);
        Question q = new Question();
        q.row = row;
        q.type = type;
        String correct;
        if (type == TYPE_WHEN) {
            q.prompt = row.text;
            q.ask = "언제 있었던 일일까요?";
            correct = row.ctx;
        } else {
            q.prompt = row.ctx;
            q.ask = "이때 있었던 일은 무엇일까요?";
            correct = row.text;
        }

        // 오답 후보: 가까운 줄부터, 정답과 연도가 다른 것만 (헷갈리되 답이 둘이 되지 않게)
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) if (i != idx) order.add(i);
        final int center = idx;
        Collections.sort(order, (a, b) -> Integer.compare(Math.abs(a - center), Math.abs(b - center)));

        List<String> cands = new ArrayList<>();
        for (int i : order) {
            Row o = all.get(i);
            if (row.year != 0 && o.year == row.year) continue;
            if (row.year == 0 && o.ctx.equals(row.ctx)) continue;
            String label = type == TYPE_WHEN ? o.ctx : o.text;
            if (label.equals(correct) || cands.contains(label)) continue;
            cands.add(label);
            if (cands.size() >= 12) break;
        }
        if (cands.size() < 3) return null;
        Collections.shuffle(cands, rnd);

        q.options.add(correct);
        q.options.addAll(cands.subList(0, 3));
        Collections.shuffle(q.options, rnd);
        q.answer = q.options.indexOf(correct);
        return q;
    }

    private static List<String> recent(SharedPreferences p) {
        List<String> out = new ArrayList<>();
        String s = p.getString("recent", "");
        if (s.length() == 0) return out;
        Collections.addAll(out, s.split(","));
        return out;
    }

    private static void remember(SharedPreferences p, int n) {
        List<String> r = recent(p);
        r.remove(String.valueOf(n));
        r.add(String.valueOf(n));
        while (r.size() > 40) r.remove(0);
        p.edit().putString("recent", String.join(",", r)).apply();
    }

    // ───────── 기록 ─────────

    static void record(Context c, int n, boolean ok) {
        SharedPreferences p = prefs(c);
        Set<String> wrong = new HashSet<>(p.getStringSet("wrong", new HashSet<String>()));
        if (ok) wrong.remove(String.valueOf(n));
        else wrong.add(String.valueOf(n));
        p.edit()
                .putInt("total", p.getInt("total", 0) + 1)
                .putInt("correct", p.getInt("correct", 0) + (ok ? 1 : 0))
                .putInt("streak", ok ? p.getInt("streak", 0) + 1 : 0)
                .putStringSet("wrong", wrong)
                .apply();
    }

    static int total(Context c) { return prefs(c).getInt("total", 0); }
    static int correct(Context c) { return prefs(c).getInt("correct", 0); }
    static int streak(Context c) { return prefs(c).getInt("streak", 0); }
    static int wrongCount(Context c) { return prefs(c).getStringSet("wrong", new HashSet<String>()).size(); }

    static void resetStats(Context c) {
        prefs(c).edit().remove("total").remove("correct").remove("streak").remove("wrong").remove("recent").apply();
    }

    // ───────── 설정 ─────────

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("quiz", Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) { return prefs(c).getBoolean("enabled", false); }

    static void setEnabled(Context c, boolean on) { prefs(c).edit().putBoolean("enabled", on).apply(); }

    /** 문제 사이 최소 간격(분). 0이면 화면을 켤 때마다. */
    static int intervalMin(Context c) { return prefs(c).getInt("interval", 0); }

    static void setIntervalMin(Context c, int m) { prefs(c).edit().putInt("interval", m).apply(); }

    static boolean dueNow(Context c) {
        long last = prefs(c).getLong("last", 0);
        long gap = intervalMin(c) * 60_000L;
        long now = System.currentTimeMillis();
        return gap == 0 || now - last >= gap || now < last;
    }

    static void markShown(Context c) { prefs(c).edit().putLong("last", System.currentTimeMillis()).apply(); }
}
