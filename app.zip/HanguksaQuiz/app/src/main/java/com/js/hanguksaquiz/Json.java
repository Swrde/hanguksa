package com.js.hanguksaquiz;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 동기화에 쓰는 작은 JSON 읽기·쓰기.
 * 객체는 순서를 지키는 Map, 배열은 List, 정수는 Long, 소수는 Double, null 값은 Json.NULL이에요.
 * (휴대폰과 시험용 컴퓨터에서 똑같이 돌게 안드로이드 org.json을 쓰지 않아요)
 */
final class Json {
    /** JSON의 null 값 (자바 null은 '값이 없음'으로 따로 써요) */
    static final Object NULL = new Object() {
        @Override public String toString() { return "null"; }
    };

    private Json() {}

    static Object parse(String s) {
        Reader r = new Reader(s);
        r.ws();
        Object v = r.value();
        r.ws();
        if (r.i != s.length()) throw new IllegalArgumentException("JSON 뒤에 글자가 남았어요");
        return v;
    }

    /** 읽을 수 없으면 null */
    static Object tryParse(String s) {
        if (s == null) return null;
        try { return parse(s); } catch (RuntimeException e) { return null; }
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> obj(Object o) { return o instanceof Map ? (Map<String, Object>) o : null; }

    @SuppressWarnings("unchecked")
    static List<Object> arr(Object o) { return o instanceof List ? (List<Object>) o : null; }

    static Map<String, Object> objOf(String s) { return obj(tryParse(s)); }

    static String str(Object v) {
        StringBuilder b = new StringBuilder();
        write(b, v);
        return b.toString();
    }

    static String s(Map<String, Object> m, String k) { Object v = m == null ? null : m.get(k); return v instanceof String ? (String) v : ""; }

    static long l(Map<String, Object> m, String k) { Object v = m == null ? null : m.get(k); return v instanceof Number ? ((Number) v).longValue() : 0; }

    static boolean b(Map<String, Object> m, String k) { Object v = m == null ? null : m.get(k); return v instanceof Boolean && (Boolean) v; }

    /** 값이 같은지 (수는 크기로, 객체는 열쇠 순서와 상관없이) */
    static boolean eq(Object a, Object b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        if (a == NULL || b == NULL) return false;
        if (a instanceof Number && b instanceof Number) {
            Number x = (Number) a, y = (Number) b;
            if (x instanceof Double || x instanceof Float || y instanceof Double || y instanceof Float) return x.doubleValue() == y.doubleValue();
            return x.longValue() == y.longValue();
        }
        Map<String, Object> ma = obj(a), mb = obj(b);
        if (ma != null || mb != null) {
            if (ma == null || mb == null || ma.size() != mb.size()) return false;
            for (Map.Entry<String, Object> e : ma.entrySet()) {
                if (!mb.containsKey(e.getKey()) || !eq(e.getValue(), mb.get(e.getKey()))) return false;
            }
            return true;
        }
        List<Object> la = arr(a), lb = arr(b);
        if (la != null || lb != null) {
            if (la == null || lb == null || la.size() != lb.size()) return false;
            for (int i = 0; i < la.size(); i++) if (!eq(la.get(i), lb.get(i))) return false;
            return true;
        }
        return a.equals(b);
    }

    private static void write(StringBuilder b, Object v) {
        if (v == null || v == NULL) {
            b.append("null");
        } else if (v instanceof String) {
            quote(b, (String) v);
        } else if (v instanceof Boolean) {
            b.append(((Boolean) v) ? "true" : "false");
        } else if (v instanceof Double || v instanceof Float) {
            double d = ((Number) v).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) b.append("null");
            else if (d == Math.rint(d) && Math.abs(d) < 1e15) b.append((long) d);
            else b.append(d);
        } else if (v instanceof Number) {
            b.append(((Number) v).longValue());
        } else if (v instanceof Map) {
            b.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) v).entrySet()) {
                if (!first) b.append(',');
                first = false;
                quote(b, String.valueOf(e.getKey()));
                b.append(':');
                write(b, e.getValue());
            }
            b.append('}');
        } else if (v instanceof Collection) {
            b.append('[');
            boolean first = true;
            for (Object o : (Collection<?>) v) {
                if (!first) b.append(',');
                first = false;
                write(b, o);
            }
            b.append(']');
        } else {
            quote(b, v.toString());
        }
    }

    private static void quote(StringBuilder b, String s) {
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                case '\b': b.append("\\b"); break;
                case '\f': b.append("\\f"); break;
                default:
                    // 줄 바꿈 문자(U+2028·2029)도 이스케이프해야 자바스크립트 안에 그대로 넣어도 안전해요
                    if (c < 0x20 || c == ' ' || c == ' ') b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        b.append('"');
    }

    private static final class Reader {
        final String s;
        int i;

        Reader(String s) { this.s = s; }

        void ws() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') i++;
                else break;
            }
        }

        IllegalArgumentException bad(String what) { return new IllegalArgumentException(what + " (" + i + "번째 글자)"); }

        Object value() {
            if (i >= s.length()) throw bad("JSON이 끝났어요");
            char c = s.charAt(i);
            if (c == '{') return object();
            if (c == '[') return array();
            if (c == '"') return string();
            if (c == 't' && s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (c == 'f' && s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            if (c == 'n' && s.startsWith("null", i)) { i += 4; return NULL; }
            if (c == '-' || (c >= '0' && c <= '9')) return number();
            throw bad("알 수 없는 글자");
        }

        Map<String, Object> object() {
            Map<String, Object> m = new LinkedHashMap<>();
            i++;
            ws();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (true) {
                ws();
                if (i >= s.length() || s.charAt(i) != '"') throw bad("열쇠가 필요해요");
                String k = string();
                ws();
                if (i >= s.length() || s.charAt(i) != ':') throw bad("':'가 필요해요");
                i++;
                ws();
                m.put(k, value());
                ws();
                if (i >= s.length()) throw bad("객체가 끝나지 않았어요");
                char c = s.charAt(i++);
                if (c == '}') return m;
                if (c != ',') throw bad("','가 필요해요");
            }
        }

        List<Object> array() {
            List<Object> a = new ArrayList<>();
            i++;
            ws();
            if (i < s.length() && s.charAt(i) == ']') { i++; return a; }
            while (true) {
                ws();
                a.add(value());
                ws();
                if (i >= s.length()) throw bad("배열이 끝나지 않았어요");
                char c = s.charAt(i++);
                if (c == ']') return a;
                if (c != ',') throw bad("','가 필요해요");
            }
        }

        String string() {
            i++;
            StringBuilder b = null;
            int start = i;
            while (true) {
                if (i >= s.length()) throw bad("글자가 끝나지 않았어요");
                char c = s.charAt(i);
                if (c == '"') {
                    String out = b == null ? s.substring(start, i) : b.append(s, start, i).toString();
                    i++;
                    return out;
                }
                if (c == '\\') {
                    if (b == null) b = new StringBuilder();
                    b.append(s, start, i);
                    i++;
                    if (i >= s.length()) throw bad("이스케이프가 끝났어요");
                    char e = s.charAt(i++);
                    switch (e) {
                        case '"': b.append('"'); break;
                        case '\\': b.append('\\'); break;
                        case '/': b.append('/'); break;
                        case 'b': b.append('\b'); break;
                        case 'f': b.append('\f'); break;
                        case 'n': b.append('\n'); break;
                        case 'r': b.append('\r'); break;
                        case 't': b.append('\t'); break;
                        case 'u':
                            if (i + 4 > s.length()) throw bad("\\u가 짧아요");
                            b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            i += 4;
                            break;
                        default: throw bad("알 수 없는 이스케이프");
                    }
                    start = i;
                } else {
                    i++;
                }
            }
        }

        Object number() {
            int start = i;
            boolean frac = false;
            if (s.charAt(i) == '-') i++;
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c >= '0' && c <= '9') i++;
                else if (c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-') { frac = true; i++; }
                else break;
            }
            String t = s.substring(start, i);
            if (t.equals("-") || t.isEmpty()) throw bad("수가 잘못됐어요");
            try {
                if (!frac) return Long.parseLong(t);
            } catch (NumberFormatException ignored) {
                // 아주 큰 정수는 소수로
            }
            try {
                return Double.parseDouble(t);
            } catch (NumberFormatException e) {
                throw bad("수가 잘못됐어요");
            }
        }
    }
}
