package com.js.hanguksaquiz;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;

/**
 * 화면이 켜지는 순간(SCREEN_ON)을 듣고 있다가 잠금화면 위에 문제를 띄워요.
 * SCREEN_ON은 앱이 실행 중일 때만 받을 수 있어서, 알림을 하나 띄운 채로 계속 실행돼요.
 */
public class QuizService extends Service {

    private static final String CHANNEL = "quiz_running";
    private static final int NOTI_ID = 1;

    private final BroadcastReceiver screenOn = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) maybeShow();
        }
    };

    /** 설정에 맞춰 서비스를 켜거나 꺼요. */
    static void sync(Context c) {
        Intent i = new Intent(c, QuizService.class);
        if (Quiz.enabled(c)) {
            try {
                c.startForegroundService(i);
            } catch (Exception e) {
                // 백그라운드에서 시작이 막힌 경우: 다음에 앱을 열 때 다시 시도돼요
            }
        } else {
            c.stopService(i);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        goForeground();
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenOn, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(screenOn, f);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // startForegroundService()로 불릴 때마다 바로 알림을 걸어야 앱이 꺼지지 않아요
        goForeground();
        if (!Quiz.enabled(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void goForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "잠금화면 문제 실행 중", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("화면을 켤 때 한국사 문제를 띄우려면 이 알림이 켜져 있어야 해요.");
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);

        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, SettingsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("화면을 켜면 한국사 문제가 나와요")
                .setContentText("눌러서 설정 바꾸기")
                .setContentIntent(open)
                .setOngoing(true)
                .setShowWhen(false)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTI_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTI_ID, n);
        }
    }

    private void maybeShow() {
        if (!Quiz.enabled(this)) return;
        if (!Settings.canDrawOverlays(this)) return; // 이 권한이 있어야 잠금화면 위에 띄울 수 있어요
        if (busy()) return;
        if (!Quiz.dueNow(this)) return;
        Quiz.markShown(this);
        Intent i = new Intent(this, LockQuizActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    /** 통화 중이거나 전화가 울릴 때는 문제를 띄우지 않아요. */
    private boolean busy() {
        AudioManager am = getSystemService(AudioManager.class);
        if (am == null) return false;
        int m = am.getMode();
        return m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION || m == AudioManager.MODE_RINGTONE;
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(screenOn);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
