package com.js.hanguksaquiz;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;

/**
 * 앱 화면 모양: 세 과목 색 빛이 번진 바탕 위 유리판(리퀴드 글라스).
 * 잠금화면 문제는 휴대폰 배경화면 위에 어두운 유리판을 띄운다.
 */
final class Glass {
    private Glass() {}

    // 과목 색 (애플 기본 색)
    static final int INDIGO = 0xFF5E5CE6, GREEN = 0xFF30D158, ORANGE = 0xFFFF9F0A;

    /** 공부 화면에서 고른 화면 모드(자동/라이트/다크)를 따라 지금 어두운 화면인지 */
    static boolean isDark(Context c) {
        String t = c.getSharedPreferences("ui", Context.MODE_PRIVATE).getString("theme", "auto");
        boolean night = (c.getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        return "dark".equals(t) || (!"light".equals(t) && night);
    }

    /** 앱이 열릴 때 바탕색 (홈 화면 바탕색과 같게) */
    static int bg(boolean dark) { return dark ? 0xFF06070D : 0xFFE8EBF3; }

    /** 바탕: 바닥색 + 세 과목 색이 은은하게 번진 빛 (홈 화면과 같음) */
    static Drawable background(Context c, boolean dark) {
        int w = c.getResources().getDisplayMetrics().widthPixels;
        if (dark) {
            return layers(0xFF06070D,
                    glow(0x735E5CE6, 0.08f, 0.04f, w * 0.95f),
                    glow(0x3330D158, 1.0f, 0.42f, w * 0.85f),
                    glow(0x33FF9F0A, 0.12f, 0.94f, w * 0.95f));
        }
        return layers(0xFFE8EBF3,
                glow(0x575E5CE6, 0.08f, 0.04f, w * 0.95f),
                glow(0x4230D158, 1.0f, 0.42f, w * 0.85f),
                glow(0x47FF9F0A, 0.12f, 0.94f, w * 0.95f));
    }

    private static Drawable layers(int base, Drawable... glows) {
        Drawable[] ds = new Drawable[glows.length + 1];
        ds[0] = new ColorDrawable(base);
        System.arraycopy(glows, 0, ds, 1, glows.length);
        return new LayerDrawable(ds);
    }

    private static Drawable glow(int color, float cx, float cy, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setColors(new int[]{color, color & 0x00FFFFFF});
        g.setGradientCenter(cx, cy);
        g.setGradientRadius(radius);
        return g;
    }

    /** 유리판: 반투명 + 밝은 테두리 (가장자리에 맺히는 빛) */
    static GradientDrawable card(Context c, boolean dark, float radiusDp) {
        return panel(c, dark ? 0x14FFFFFF : 0x8CFFFFFF, dark ? 0x1FFFFFFF : 0xCCFFFFFF, radiusDp);
    }

    /** 잠금화면: 배경화면을 어둡게 눌러 글자가 어떤 배경화면에서도 잘 보이게 (위는 조금, 아래는 더) */
    static Drawable lockScrim() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x66000000, 0x80000000, 0xA6000000});
        return g;
    }

    /** 잠금화면 유리판: 어두운 반투명 + 밝은 머리카락 테두리 */
    static GradientDrawable lockPlate(Context c, float radiusDp) {
        GradientDrawable g = panel(c, 0x5C121214, 0, radiusDp);
        g.setStroke(Math.max(1, Ui.dp(c, 0.8f)), 0x33FFFFFF);
        return g;
    }

    static GradientDrawable panel(Context c, int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(Ui.dp(c, radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, Ui.dp(c, 1)), stroke);
        return g;
    }

    /** 애플워치 같은 진도 링 */
    static final class Ring extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private int color;
        private float pct, strokeDp;

        Ring(Context c, int color, float strokeDp) {
            super(c);
            this.color = color;
            this.strokeDp = strokeDp;
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        }

        void set(float pct) {
            this.pct = Math.max(0f, Math.min(1f, pct));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float sw = Ui.dp(getContext(), strokeDp);
            float size = Math.min(getWidth(), getHeight());
            float l = (getWidth() - size) / 2 + sw / 2, t = (getHeight() - size) / 2 + sw / 2;
            r.set(l, t, l + size - sw, t + size - sw);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(sw);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor((color & 0x00FFFFFF) | 0x59000000);
            cv.drawArc(r, 0, 360, false, paint);
            if (pct > 0) {
                paint.setColor(color);
                cv.drawArc(r, -90, 360 * pct, false, paint);
            }
        }
    }
}
