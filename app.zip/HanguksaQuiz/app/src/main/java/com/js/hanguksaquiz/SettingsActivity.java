package com.js.hanguksaquiz;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** 잠금화면 문제 설정: 켜기, 과목, 얼마나 자주, 과목마다 낼 문제(종류·범위), 기록, 권한, 앱 정보 */
public class SettingsActivity extends Activity {

    private static final int[] INTERVALS = {0, 3, 10, 30};
    private static final String[] INTERVAL_NAMES = {"켤 때마다", "3분", "10분", "30분"};
    private static final String[] SUB_KEYS = {Quiz.S_KS, Quiz.S_SA, Quiz.S_EN};
    private static final String[] SUB_NAMES = {"한국사2", "통합사회2", "영어 단어"};
    private static final String[] MODES = {Quiz.MODE_ALL, Quiz.MODE_YEAR, Quiz.MODE_CH, Quiz.MODE_PAGE};
    private static final String[] MODE_NAMES = {"전체", "연도", "단원", "쪽"};

    // 색 (공부 화면에서 고른 라이트/다크를 따라가요)
    private boolean dark;
    private int cBg, cCard, cInk, cSoft, cRule, cTint, cSeg, cPen, cOk, cOff, cKnobOff, cKnobOn, cBox;
    private int[] cSub;

    private Toggle master;
    private TextView heroSub, heroWarnText;
    private LinearLayout heroWarn;
    private final Toggle[] subToggles = new Toggle[3];
    private final TextView[] subInfo = new TextView[3];
    private final View[] subHead = new View[3], subCard = new View[3];
    private LinearLayout yearBox, chBox, pageBox;
    private TextView rangeCount, saCount, enCount, statTotal, statRate, statStreak, statWrong, statWeak;
    private final List<TextView> dayChips = new ArrayList<>();
    private final List<Integer> dayNums = new ArrayList<>();
    private TextView overlayState, batteryState, notiState;
    private TextView overlayBtn, batteryBtn, notiBtn;
    private View notiRow, notiLine;
    private View lastHead;

    private LinearLayout headBar;
    private TextView headTitle;
    private View headLine;
    private boolean headSolid;

    @Override
    protected void onCreate(Bundle saved) {
        palette();
        setTheme(dark ? android.R.style.Theme_Material_NoActionBar : android.R.style.Theme_Material_Light_NoActionBar);
        super.onCreate(saved);
        getWindow().getDecorView().setBackgroundColor(cBg);
        getWindow().setBackgroundDrawable(Glass.background(this, dark));

        // 아이폰 설정 앱처럼: 큰 제목이 위로 올라가면, 위에 떠 있는 반투명 막대에 작은 제목이 나타나요
        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.setBackground(Glass.background(this, dark));
        ScrollView sv = new ScrollView(this);
        sv.setClipToPadding(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(52), dp(16), dp(36));
        sv.addView(col);
        root.addView(sv, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView big = Ui.text(this, "잠금화면 문제", 30, cInk, true);
        big.setLetterSpacing(-0.02f);
        LinearLayout.LayoutParams bigp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bigp.setMargins(dp(4), dp(4), dp(4), dp(6));
        col.addView(big, bigp);

        buildHero(col);
        buildSubjects(col);
        buildInterval(col);
        buildKs(col);
        buildSa(col);
        buildEn(col);
        buildStats(col);
        buildPerms(col);
        buildAccount(col);
        buildApp(col);

        // 떠 있는 막대: 뒤로 + 작은 제목
        headBar = new LinearLayout(this);
        headBar.setOrientation(LinearLayout.VERTICAL);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(6), 0, dp(16), 0);
        ImageView back = new ImageView(this);
        back.setImageResource(R.drawable.ic_back);
        back.setImageTintList(ColorStateList.valueOf(cSub[0]));
        back.setScaleType(ImageView.ScaleType.CENTER);
        back.setContentDescription("뒤로");
        back.setBackground(ripple(true));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        headTitle = Ui.text(this, "잠금화면 문제", 17, cInk, true);
        headTitle.setGravity(Gravity.CENTER);
        headTitle.setAlpha(0f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tp.rightMargin = dp(28);
        head.addView(headTitle, tp);
        headBar.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        headLine = new View(this);
        headLine.setBackgroundColor(cRule);
        headLine.setAlpha(0f);
        headBar.addView(headLine, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(0.5f))));
        root.addView(headBar, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.setOnScrollChangeListener((v, x, y, ox, oy) -> setHeadSolid(y > dp(30)));

        setContentView(root);
        Ui.edgeToEdge(this, root, !dark);
    }

    /** 내용이 막대 밑으로 지나가면 막대를 반투명하게 채우고 작은 제목을 보여요 */
    private void setHeadSolid(boolean on) {
        if (on == headSolid) return;
        headSolid = on;
        headBar.setBackgroundColor(on ? (dark ? 0xD90D0E16 : 0xD9F0F1F6) : 0);
        headTitle.animate().alpha(on ? 1f : 0f).setDuration(160).start();
        headLine.setAlpha(on ? 1f : 0f);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        paintAccount();
        QuizService.sync(this);
    }

    private void palette() {
        String t = getSharedPreferences("ui", MODE_PRIVATE).getString("theme", "auto");
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        dark = "dark".equals(t) || (!"light".equals(t) && night);
        // 홈 화면과 같은 유리: 세 과목 색 빛이 번진 바탕 위 반투명 판
        if (dark) {
            cBg = 0xFF06070D; cCard = 0xFF2C2C2E; cInk = 0xFFFFFFFF; cSoft = 0xFFA1A1A8;
            cRule = 0x1AFFFFFF; cTint = 0x3D767680; cSeg = 0x33FFFFFF; cPen = 0xFFFF6961; cOk = 0xFF30D158;
            cOff = 0x52787880; cKnobOff = 0xFFFFFFFF; cKnobOn = 0xFFFFFFFF; cBox = 0xFF636366;
            cSub = new int[]{0xFF7D7AFF, 0xFF30D158, 0xFFFF9F0A};
        } else {
            cBg = 0xFFE8EBF3; cCard = 0xFFFFFFFF; cInk = 0xFF000000; cSoft = 0xFF5E5E66;
            cRule = 0x213C3C43; cTint = 0x1C767680; cSeg = 0xF0FFFFFF; cPen = 0xFFD70015; cOk = 0xFF17803A;
            cOff = 0x3D787880; cKnobOff = 0xFFFFFFFF; cKnobOn = 0xFFFFFFFF; cBox = 0xFFC7C7CC;
            cSub = new int[]{0xFF5E5CE6, 0xFF17803A, 0xFFC55300};
        }
    }

    // ───────── 켜기 ─────────

    private void buildHero(LinearLayout col) {
        LinearLayout c = card(col);
        ((LinearLayout.LayoutParams) c.getLayoutParams()).topMargin = dp(8);
        master = new Toggle(this, false).colors(cSub[0], cOff, 0xFFFFFFFF, cKnobOff);
        master.setOnChange((t, on) -> {
            Quiz.setEnabled(this, on);
            if (on) askNeeded();
            QuizService.sync(this);
            refresh();
        });
        heroSub = sub("");
        LinearLayout r = switchRow(c, null, "화면 켤 때 문제 풀기", heroSub, master);
        ((TextView) ((LinearLayout) r.getChildAt(0)).getChildAt(0)).setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        ((TextView) ((LinearLayout) r.getChildAt(0)).getChildAt(0)).setTypeface(Typeface.DEFAULT_BOLD);
        r.setPadding(dp(18), dp(16), dp(10), dp(16));

        // 권한이 없으면 바로 여기서 알려 줘요
        heroWarn = new LinearLayout(this);
        heroWarn.setGravity(Gravity.CENTER_VERTICAL);
        heroWarn.setBackground(Ui.box(this, dark ? 0x26FF8077 : 0x14D23B32, 0, 12));
        heroWarn.setPadding(dp(14), dp(10), dp(10), dp(10));
        heroWarnText = Ui.text(this, "다른 앱 위에 표시가 꺼져 있어서 문제가 안 떠요.", 14, cPen, false);
        heroWarnText.setLineSpacing(0, 1.15f);
        heroWarn.addView(heroWarnText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView fix = chip("허용하기");
        fix.setOnClickListener(v -> openOverlay());
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.leftMargin = dp(10);
        heroWarn.addView(fix, fp);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wp.setMargins(dp(14), 0, dp(14), dp(14));
        c.addView(heroWarn, wp);
    }

    // ───────── 과목 ─────────

    private void buildSubjects(LinearLayout col) {
        LinearLayout c = section(col, "과목");
        for (int i = 0; i < 3; i++) {
            final int k = i;
            View bar = new View(this);
            bar.setBackground(Ui.box(this, cSub[i], 0, 2));
            bar.setLayoutParams(new LinearLayout.LayoutParams(dp(4), dp(30)));
            subInfo[i] = sub("");
            Toggle t = new Toggle(this, false).colors(cSub[i], cOff, cKnobOn, cKnobOff);
            t.setChecked(Quiz.subjectOn(this, SUB_KEYS[i]));
            t.setOnChange((tg, on) -> {
                if (!on) {
                    boolean any = false;
                    for (int j = 0; j < 3; j++) if (j != k && subToggles[j].isChecked()) any = true;
                    if (!any) {
                        tg.setChecked(true);
                        toast("과목은 하나 이상 켜 둬야 해요");
                        return;
                    }
                }
                Quiz.setSubject(this, SUB_KEYS[k], on);
                showSub(k, on);
            });
            subToggles[i] = t;
            if (i > 0) divider(c);
            switchRow(c, bar, SUB_NAMES[i], subInfo[i], t);
        }
    }

    // ───────── 얼마나 자주 ─────────

    private void buildInterval(LinearLayout col) {
        LinearLayout c = section(col, "얼마나 자주");
        int cur = Quiz.intervalMin(this), sel = 0;
        for (int i = 0; i < INTERVALS.length; i++) if (INTERVALS[i] == cur) sel = i;
        LinearLayout seg = segmented(INTERVAL_NAMES, sel, pos -> { Quiz.setIntervalMin(this, INTERVALS[pos]); refresh(); });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.setMargins(dp(12), dp(12), dp(12), dp(6));
        c.addView(seg, sp);
        TextView n = note("화면을 켜도 이 시간이 지나기 전에는 문제가 다시 뜨지 않아요.");
        n.setPadding(dp(16), dp(4), dp(16), dp(14));
        c.addView(n);
    }

    // ───────── 한국사 ─────────

    private void buildKs(LinearLayout col) {
        final SharedPreferences p = Quiz.prefs(this);
        LinearLayout c = section(col, "한국사2 문제");
        subHead[0] = lastHead;
        subCard[0] = c;

        c.addView(label("문제 종류"));
        final String[] keys = {"t_when", "t_what", "t_order", "t_text"};
        final String[] names = {"연표: 사건 보고 시기 맞히기", "연표: 시기 보고 사건 맞히기", "교과서 사건 순서 맞히기", "교과서 문제 (용어, 정부, O/X 등)"};
        final Toggle[] kinds = new Toggle[keys.length];
        for (int i = 0; i < keys.length; i++) {
            final int k = i;
            kinds[i] = new Toggle(this, true).colors(cSub[0], cBox, cKnobOn, 0);
            kinds[i].setChecked(p.getBoolean(keys[i], true));
            kinds[i].setOnChange((t, on) -> {
                boolean any = false;
                for (int j = 0; j < kinds.length; j++) if (j != k && kinds[j].isChecked()) any = true;
                if (!on && !any) {
                    t.setChecked(true);
                    toast("하나는 켜 둬야 해요");
                    return;
                }
                p.edit().putBoolean(keys[k], on).apply();
                updateCounts();
            });
            checkRow(c, names[i], kinds[i]);
        }
        Toggle world = new Toggle(this, true).colors(cSub[0], cBox, cKnobOn, 0);
        world.setChecked(p.getBoolean("world", true));
        world.setOnChange((t, on) -> { p.edit().putBoolean("world", on).apply(); updateCounts(); });
        checkRow(c, "연표의 세계사 줄도 내기", world);

        divider(c);
        c.addView(label("범위"));
        String cur = p.getString("rmode", Quiz.MODE_ALL);
        int sel = 0;
        for (int i = 0; i < MODES.length; i++) if (MODES[i].equals(cur)) sel = i;
        LinearLayout seg = segmented(MODE_NAMES, sel, pos -> {
            p.edit().putString("rmode", MODES[pos]).apply();
            showRangeBox(MODES[pos]);
            updateCounts();
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.setMargins(dp(12), dp(2), dp(12), dp(4));
        c.addView(seg, sp);

        // 연도
        yearBox = pairBox();
        List<String> years = new ArrayList<>();
        for (int y = Quiz.YEAR_MIN; y <= Quiz.YEAR_MAX; y++) years.add(y + "년");
        yearBox.addView(spinner(years, p.getInt("ry0", 1945) - Quiz.YEAR_MIN, pos -> { p.edit().putInt("ry0", Quiz.YEAR_MIN + pos).apply(); updateCounts(); }), weight());
        yearBox.addView(tilde());
        yearBox.addView(spinner(years, p.getInt("ry1", Quiz.YEAR_MAX) - Quiz.YEAR_MIN, pos -> { p.edit().putInt("ry1", Quiz.YEAR_MIN + pos).apply(); updateCounts(); }), weight());
        c.addView(yearBox);

        // 교과서 단원
        chBox = new LinearLayout(this);
        chBox.setOrientation(LinearLayout.VERTICAL);
        chBox.setPadding(0, dp(4), 0, 0);
        Set<String> def = new HashSet<>(Arrays.asList("1", "2", "3", "4", "5", "6"));
        final Set<String> chosen = new HashSet<>(p.getStringSet("rchs", def));
        for (Quiz.Chapter ch : Quiz.chapters(this)) {
            final String code = ch.c;
            Toggle t = new Toggle(this, true).colors(cSub[0], cBox, cKnobOn, 0);
            t.setChecked(chosen.contains(code));
            t.setOnChange((tg, on) -> {
                if (on) chosen.add(code); else chosen.remove(code);
                p.edit().putStringSet("rchs", new HashSet<>(chosen)).apply();
                updateCounts();
            });
            checkRow(chBox, ch.name + "  " + ch.from + "~" + ch.to + "쪽", t);
        }
        c.addView(chBox);

        // 교과서 쪽
        pageBox = pairBox();
        final List<String> pages = new ArrayList<>();
        for (int pg : Quiz.PAGES) pages.add(pg + "쪽");
        pageBox.addView(spinner(pages, pageIndex(p.getInt("rp0", 66)), pos -> { p.edit().putInt("rp0", Quiz.PAGES[pos]).apply(); updateCounts(); }), weight());
        pageBox.addView(tilde());
        pageBox.addView(spinner(pages, pageIndex(p.getInt("rp1", 137)), pos -> { p.edit().putInt("rp1", Quiz.PAGES[pos]).apply(); updateCounts(); }), weight());
        c.addView(pageBox);

        rangeCount = Ui.text(this, "", 14, cSoft, false);
        rangeCount.setLineSpacing(0, 1.2f);
        rangeCount.setPadding(dp(16), dp(10), dp(16), dp(16));
        c.addView(rangeCount);

        showRangeBox(cur);
        showSub(0, Quiz.subjectOn(this, Quiz.S_KS));
    }

    /** 과목을 끄면 그 과목의 문제 고르기도 숨겨요 */
    private void showSub(int k, boolean on) {
        int v = on ? View.VISIBLE : View.GONE;
        if (subHead[k] != null) subHead[k].setVisibility(v);
        if (subCard[k] != null) subCard[k].setVisibility(v);
    }

    private void showRangeBox(String mode) {
        yearBox.setVisibility(Quiz.MODE_YEAR.equals(mode) ? View.VISIBLE : View.GONE);
        chBox.setVisibility(Quiz.MODE_CH.equals(mode) ? View.VISIBLE : View.GONE);
        pageBox.setVisibility(Quiz.MODE_PAGE.equals(mode) ? View.VISIBLE : View.GONE);
    }

    private static int pageIndex(int page) {
        for (int i = 0; i < Quiz.PAGES.length; i++) if (Quiz.PAGES[i] == page) return i;
        return 0;
    }

    // ───────── 통합사회 ─────────

    private void buildSa(LinearLayout col) {
        final SharedPreferences p = Quiz.prefs(this);
        LinearLayout c = section(col, "통합사회2 문제");
        subHead[1] = lastHead;
        subCard[1] = c;

        c.addView(label("문제 종류"));
        final List<String[]> cats = Quiz.saCats(this);
        final Toggle[] kinds = new Toggle[cats.size()];
        for (int i = 0; i < cats.size(); i++) {
            final int k = i;
            final String key = "sa_c_" + cats.get(i)[0];
            kinds[i] = new Toggle(this, true).colors(cSub[1], cBox, cKnobOn, 0);
            kinds[i].setChecked(p.getBoolean(key, true));
            kinds[i].setOnChange((t, on) -> {
                if (!on && !anyOther(kinds, k)) {
                    t.setChecked(true);
                    toast("하나는 켜 둬야 해요");
                    return;
                }
                p.edit().putBoolean(key, on).apply();
                updateCounts();
            });
            checkRow(c, cats.get(i)[1], kinds[i]);
        }

        final List<String[]> units = Quiz.saUnits(this);
        if (!units.isEmpty()) {
            divider(c);
            c.addView(label("단원"));
            Set<String> all = new HashSet<>();
            for (int i = 0; i < units.size(); i++) all.add(String.valueOf(i));
            final Set<String> chosen = new HashSet<>(p.getStringSet("sa_units", all));
            final Toggle[] ut = new Toggle[units.size()];
            for (int i = 0; i < units.size(); i++) {
                final int k = i;
                final String code = String.valueOf(i);
                ut[i] = new Toggle(this, true).colors(cSub[1], cBox, cKnobOn, 0);
                ut[i].setChecked(chosen.contains(code));
                ut[i].setOnChange((t, on) -> {
                    if (!on && !anyOther(ut, k)) {
                        t.setChecked(true);
                        toast("단원은 하나 이상 골라야 해요");
                        return;
                    }
                    if (on) chosen.add(code); else chosen.remove(code);
                    p.edit().putStringSet("sa_units", new HashSet<>(chosen)).apply();
                    updateCounts();
                });
                String[] u = units.get(i);
                checkRow(c, u[0] + (u[1].length() > 0 ? "  " + u[1] : ""), ut[i]);
            }
        }

        saCount = countLine(c);
        showSub(1, Quiz.subjectOn(this, Quiz.S_SA));
    }

    // ───────── 영어 ─────────

    private void buildEn(LinearLayout col) {
        final SharedPreferences p = Quiz.prefs(this);
        LinearLayout c = section(col, "영어 단어 문제");
        subHead[2] = lastHead;
        subCard[2] = c;

        c.addView(label("문제 종류"));
        final String[] names = {"뜻 고르기 (단어 보고 뜻)", "단어 고르기 (뜻 보고 단어)", "예문 빈칸 채우기"};
        final Toggle[] kinds = new Toggle[names.length];
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            kinds[i] = new Toggle(this, true).colors(cSub[2], cBox, cKnobOn, 0);
            kinds[i].setChecked(Quiz.enKind(this, i));
            kinds[i].setOnChange((t, on) -> {
                if (!on && !anyOther(kinds, k)) {
                    t.setChecked(true);
                    toast("하나는 켜 둬야 해요");
                    return;
                }
                p.edit().putBoolean("en_k" + k, on).apply();
                updateCounts();
            });
            checkRow(c, names[i], kinds[i]);
        }

        final List<Integer> days = Quiz.enDays(this);
        if (!days.isEmpty()) {
            divider(c);
            LinearLayout head = new LinearLayout(this);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.setPadding(0, 0, dp(12), 0);
            head.addView(label("Day"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            TextView allBtn = chip("모두 고르기");
            allBtn.setMinHeight(dp(32));
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ap.topMargin = dp(8);
            head.addView(allBtn, ap);
            c.addView(head);

            Set<String> all = new HashSet<>();
            for (int d : days) all.add(String.valueOf(d));
            final Set<String> chosen = new HashSet<>(p.getStringSet("en_days", all));
            dayNums.clear();
            dayChips.clear();
            LinearLayout grid = new LinearLayout(this);
            grid.setOrientation(LinearLayout.VERTICAL);
            grid.setPadding(dp(12), dp(6), dp(12), 0);
            LinearLayout row = null;
            final int perRow = 5;
            for (int i = 0; i < days.size(); i++) {
                if (i % perRow == 0) {
                    row = new LinearLayout(this);
                    LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    if (i > 0) rp.topMargin = dp(8);
                    grid.addView(row, rp);
                }
                final String code = String.valueOf(days.get(i));
                TextView chip = Ui.text(this, code, 15, cInk, true);
                chip.setGravity(Gravity.CENTER);
                chip.setMinHeight(dp(44));
                chip.setClickable(true);
                chip.setFocusable(true);
                chip.setOnClickListener(v -> {
                    if (chosen.contains(code)) {
                        if (chosen.size() == 1) { toast("Day는 하나 이상 골라야 해요"); return; }
                        chosen.remove(code);
                    } else {
                        chosen.add(code);
                    }
                    p.edit().putStringSet("en_days", new HashSet<>(chosen)).apply();
                    paintDays(chosen);
                    updateCounts();
                });
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
                if (i % perRow > 0) cp.leftMargin = dp(8);
                row.addView(chip, cp);
                dayChips.add(chip);
                dayNums.add(days.get(i));
            }
            // 마지막 줄이 덜 차면 빈 칸으로 맞춰 칸 너비를 같게
            int left = (perRow - days.size() % perRow) % perRow;
            for (int i = 0; i < left; i++) {
                View sp = new View(this);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, 1, 1);
                cp.leftMargin = dp(8);
                row.addView(sp, cp);
            }
            c.addView(grid);
            allBtn.setOnClickListener(v -> {
                chosen.addAll(all);
                p.edit().putStringSet("en_days", new HashSet<>(chosen)).apply();
                paintDays(chosen);
                updateCounts();
            });
            paintDays(chosen);
        }

        // 모르는 단어만: 외운 단어(단어장과 같이 3번 맞힌 단어)는 잠금화면에 안 내요
        divider(c);
        Toggle unk = new Toggle(this, false).colors(cSub[2], cOff, cKnobOn, cKnobOff);
        unk.setChecked(Quiz.enUnknownOnly(this));
        unk.setOnChange((t, on) -> {
            p.edit().putBoolean(Quiz.EN_UNKNOWN, on).apply();
            updateCounts();
        });
        switchRow(c, null, "모르는 단어만", sub("외운 단어(3번 맞힌 단어)는 빼고 내요. 잠금화면에서 맞힌 것도 세요."), unk);

        enCount = countLine(c);
        showSub(2, Quiz.subjectOn(this, Quiz.S_EN));
    }

    private void paintDays(Set<String> chosen) {
        for (int i = 0; i < dayChips.size(); i++) {
            TextView t = dayChips.get(i);
            boolean on = chosen.contains(String.valueOf(dayNums.get(i)));
            t.setBackground(Ui.box(this, on ? cSub[2] : cTint, 0, 12));
            t.setTextColor(on ? cKnobOn : cSoft);
            t.setSelected(on);
            t.setContentDescription("Day " + dayNums.get(i) + (on ? ", 고름" : ", 안 고름"));
        }
    }

    private static boolean anyOther(Toggle[] ts, int skip) {
        for (int j = 0; j < ts.length; j++) if (j != skip && ts[j].isChecked()) return true;
        return false;
    }

    private TextView countLine(LinearLayout c) {
        TextView t = Ui.text(this, "", 14, cSoft, false);
        t.setLineSpacing(0, 1.2f);
        t.setPadding(dp(16), dp(12), dp(16), dp(16));
        c.addView(t);
        return t;
    }

    /** 과목 줄의 문제 수와 한국사 범위 안내를 새로 써요 */
    private void updateCounts() {
        SharedPreferences p = Quiz.prefs(this);
        int[] n = Quiz.countInRange(this);
        int[] s = Quiz.subjectCounts(this);
        subInfo[0].setText(s[0] > 0 ? "고른 범위에서 " + num(s[0]) + "문제" : "고른 범위에 낼 문제가 없어요");
        subInfo[0].setTextColor(s[0] > 0 ? cSoft : cPen);
        subInfo[1].setText(s[1] > 0 ? "고른 범위에서 " + num(s[1]) + "문제" : "고른 범위에 낼 문제가 없어요");
        subInfo[1].setTextColor(s[1] > 0 ? cSoft : cPen);
        int[] ec = Quiz.enCounts(this);   // {고른 범위, 그 가운데 못 외운 단어}
        boolean unk = Quiz.enUnknownOnly(this);
        subInfo[2].setText(s[2] == 0 ? "고른 범위에 낼 문제가 없어요"
                : unk && ec[1] > 0 ? "못 외운 단어 " + num(ec[1]) + "개" : "고른 Day에서 " + num(s[2]) + "단어");
        subInfo[2].setTextColor(s[2] > 0 ? cSoft : cPen);
        if (saCount != null) {
            int ox = 0, bl = 0;
            for (Quiz.PItem it : Quiz.saPool(this)) if ("bl".equals(it.cat)) bl++; else ox++;
            saCount.setText(s[1] == 0 ? "이 범위에는 낼 문제가 없어요. 종류나 단원을 더 골라 주세요."
                    : "이 범위에서 O/X " + num(ox) + "문제, 교과서 빈칸 " + num(bl) + "문제가 나와요.");
            saCount.setTextColor(s[1] == 0 ? cPen : cSoft);
        }
        if (enCount != null) {
            int nd = 0;
            Set<String> ds = p.getStringSet("en_days", null);
            for (int d : dayNums) if (ds == null || ds.contains(String.valueOf(d))) nd++;
            int known = ec[0] - ec[1];
            enCount.setText(s[2] == 0 ? "고른 Day에는 낼 문제가 없어요."
                    : !unk ? "Day " + nd + "개, " + num(ec[0]) + "단어에서 나와요." + (known > 0 ? " 외운 단어 " + num(known) + "개도 섞여요." : "")
                    : ec[1] == 0 ? "고른 Day 단어를 다 외웠어요. 그래서 " + num(ec[0]) + "단어 전체에서 나와요."
                    : "Day " + nd + "개 " + num(ec[0]) + "단어 가운데 못 외운 " + num(ec[1]) + "단어에서 나와요.");
            enCount.setTextColor(s[2] == 0 ? cPen : cSoft);
        }
        if (rangeCount == null) return;
        boolean rowsOn = p.getBoolean("t_when", true) || p.getBoolean("t_what", true);
        boolean ordOn = p.getBoolean("t_order", true);
        boolean txtOn = p.getBoolean("t_text", true);
        String t = "이 범위에서 연표 " + (rowsOn ? num(n[0]) + "개" : "꺼짐")
                + ", 사건 순서 " + (ordOn ? num(n[1]) + "개" : "꺼짐")
                + ", 교과서 문제 " + (txtOn ? num(n[2]) + "개" : "꺼짐") + "가 나와요.";
        if (s[0] == 0) t = "이 범위에는 낼 문제가 없어요. 범위를 넓혀 주세요.";
        rangeCount.setText(t);
        rangeCount.setTextColor(s[0] == 0 ? cPen : cSoft);
    }

    // ───────── 기록 ─────────

    private void buildStats(LinearLayout col) {
        LinearLayout c = section(col, "기록");
        LinearLayout nums = new LinearLayout(this);
        nums.setPadding(dp(16), dp(16), dp(16), dp(4));
        statTotal = stat(nums, "푼 문제");
        statRate = stat(nums, "정답률");
        statStreak = stat(nums, "연속 정답");
        c.addView(nums);
        statWrong = Ui.text(this, "", 14, cSoft, false);
        statWrong.setPadding(dp(16), dp(8), dp(16), dp(4));
        statWrong.setLineSpacing(0, 1.2f);
        c.addView(statWrong);
        // 약한 단원: 정답률이 낮은 단원 (잠금화면에서 더 자주 나와요)
        statWeak = Ui.text(this, "", 14, cSoft, false);
        statWeak.setPadding(dp(16), dp(8), dp(16), dp(4));
        statWeak.setLineSpacing(0, 1.25f);
        c.addView(statWeak);

        LinearLayout btns = new LinearLayout(this);
        btns.setPadding(dp(14), dp(10), dp(14), dp(14));
        TextView tryBtn = button("지금 한 문제 풀기", cSub[0], 0xFFFFFFFF);
        tryBtn.setOnClickListener(v -> startActivity(new Intent(this, LockQuizActivity.class)));
        btns.addView(tryBtn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView reset = button("기록 지우기", cTint, cInk);
        reset.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("푼 기록, 다시 나올 틀린 문제와 복습 일정, 단원별 정답률을 모두 지울까요?")
                .setPositiveButton("지우기", (d, w) -> { Quiz.resetStats(this); refresh(); toast("기록을 지웠어요"); })
                .setNegativeButton("취소", null)
                .show());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.leftMargin = dp(8);
        btns.addView(reset, rp);
        c.addView(btns);
    }

    private TextView stat(LinearLayout parent, String name) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        TextView v = Ui.text(this, "0", 24, cInk, true);
        b.addView(v);
        b.addView(Ui.text(this, name, 13, cSoft, false));
        parent.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return v;
    }

    // ───────── 권한 ─────────

    private void buildPerms(LinearLayout col) {
        LinearLayout c = section(col, "권한");
        overlayState = sub("");
        overlayBtn = chip("허용하기");
        overlayBtn.setOnClickListener(v -> openOverlay());
        permRow(c, "다른 앱 위에 표시", overlayState, overlayBtn);
        divider(c);
        batteryState = sub("");
        batteryBtn = chip("설정하기");
        batteryBtn.setOnClickListener(v -> openBattery());
        permRow(c, "배터리 최적화 제외", batteryState, batteryBtn);
        notiLine = divider(c);
        notiState = sub("");
        notiBtn = chip("허용하기");
        notiBtn.setOnClickListener(v -> askNoti());
        notiRow = permRow(c, "알림", notiState, notiBtn);
        TextView n = note("삼성 갤럭시는 설정 > 배터리 > 백그라운드 사용 제한 > 절전 예외 앱에도 이 앱을 넣어 두면 문제가 끊기지 않아요.");
        n.setPadding(dp(16), dp(2), dp(16), dp(16));
        c.addView(n);
    }

    private View permRow(LinearLayout card, String title, TextView state, TextView btn) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(60));
        r.setPadding(dp(16), dp(12), dp(14), dp(12));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(Ui.text(this, title, 16, cInk, false));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(2);
        txt.addView(state, sp);
        r.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.leftMargin = dp(10);
        r.addView(btn, bp);
        card.addView(r);
        return r;
    }

    // ───────── 계정 ─────────

    private TextView acctState;

    private void buildAccount(LinearLayout col) {
        LinearLayout c = section(col, "계정");
        acctState = sub("");
        TextView btn = chip("열기");
        btn.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        View r = permRow(c, "기기끼리 기록 잇기", acctState, btn);
        r.setForeground(ripple(false));
        r.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        paintAccount();
    }

    private void paintAccount() {
        if (acctState == null) return;
        acctState.setText(Account.loggedIn(this) ? Account.label(this) + " · " + Sync.status(this) : Sync.status(this));
    }

    // ───────── 앱 정보 ─────────

    private void buildApp(LinearLayout col) {
        LinearLayout c = section(col, "앱 정보");
        LinearLayout ver = new LinearLayout(this);
        ver.setGravity(Gravity.CENTER_VERTICAL);
        ver.setMinimumHeight(dp(52));
        ver.setPadding(dp(16), dp(12), dp(16), dp(12));
        ver.addView(Ui.text(this, "앱 버전", 16, cInk, false), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        ver.addView(Ui.text(this, BuildConfig.VERSION_NAME, 15, cSoft, false));
        c.addView(ver);
        if (BuildConfig.CONTENT_URL.length() > 0) {
            divider(c);
            TextView btn = chip("확인");
            btn.setOnClickListener(v -> {
                toast("확인하는 중…");
                ContentSync.check(this, r -> {
                    if (r == ContentSync.UPDATED) { toast("새 내용을 받았어요. 다음 문제부터 바뀌어요"); updateCounts(); }
                    else if (r == ContentSync.UNCHANGED) toast("이미 최신 내용이에요");
                    else toast("확인하지 못했어요. 인터넷 연결을 확인해 주세요");
                });
            });
            permRow(c, "공부 내용 새로 받기", sub("앱을 열 때 인터넷이 되면 자동으로 받아요"), btn);
        }
        if (BuildConfig.UPDATE_URL.length() > 0) {
            divider(c);
            TextView btn = chip("받기");
            btn.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.UPDATE_URL)));
                } catch (Exception e) {
                    toast("인터넷 브라우저를 열 수 없어요");
                }
            });
            permRow(c, "새 버전 받기", sub("기능이 바뀐 새 APK가 나왔을 때만 받으면 돼요. 기록과 설정은 그대로 남아요."), btn);
        }
    }

    // ───────── 새로 고침 ─────────

    private void refresh() {
        boolean en = Quiz.enabled(this);
        master.setChecked(en);
        boolean overlay = Settings.canDrawOverlays(this);
        int iv = Quiz.intervalMin(this);
        heroSub.setText(!en ? "꺼져 있어요"
                : iv == 0 ? "켜져 있어요. 화면을 켤 때마다 한 문제씩 나와요."
                : "켜져 있어요. 화면을 켜면 " + iv + "분에 한 번 문제가 나와요.");
        heroWarn.setVisibility(en && !overlay ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 3; i++) subToggles[i].setChecked(Quiz.subjectOn(this, SUB_KEYS[i]));

        overlayState.setText(overlay ? "허용됨" : "꺼져 있어요. 꼭 켜야 문제가 떠요.");
        overlayState.setTextColor(overlay ? cOk : cPen);
        overlayBtn.setVisibility(overlay ? View.GONE : View.VISIBLE);

        PowerManager pm = getSystemService(PowerManager.class);
        boolean battery = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        batteryState.setText(battery ? "제외됨" : "최적화 중이라 문제가 가끔 안 뜰 수 있어요.");
        batteryState.setTextColor(battery ? cOk : cSoft);
        batteryBtn.setVisibility(battery ? View.GONE : View.VISIBLE);

        if (Build.VERSION.SDK_INT >= 33) {
            boolean noti = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            notiState.setText(noti ? "허용됨" : "꺼져 있어요. 없어도 문제는 떠요.");
            notiState.setTextColor(noti ? cOk : cSoft);
            notiBtn.setVisibility(noti ? View.GONE : View.VISIBLE);
        } else {
            notiRow.setVisibility(View.GONE);
            notiLine.setVisibility(View.GONE);
        }

        int total = Quiz.total(this), ok = Quiz.correct(this);
        statTotal.setText(num(total));
        statRate.setText(total > 0 ? Math.round(ok * 100f / total) + "%" : "-");
        statStreak.setText(num(Quiz.streak(this)));
        int w = Quiz.wrongCount(this);
        int[] rv = Quiz.reviewCounts(this);
        String wt = w > 0 ? "틀린 문제 " + num(w) + "개가 나중에 다시 나와요." : "다시 나올 틀린 문제가 없어요.";
        if (rv[1] > 0) wt += "\n복습: 오늘 " + num(rv[0]) + "개 · 모두 " + num(rv[1]) + "개 (틀린 문제를 1일·3일·7일 뒤에 다시 내요)";
        statWrong.setText(wt);
        List<String[]> weak = Quiz.weakUnits(this, 3);
        if (weak.isEmpty()) {
            statWeak.setText("약한 단원: 아직 없어요 (단원마다 5문제 넘게 풀면 정답률을 셈해요)");
        } else {
            StringBuilder b = new StringBuilder("약한 단원 (더 자주 나와요)");
            for (String[] u : weak) b.append("\n· ").append(u[1]).append("  ").append(u[2]).append("% (").append(u[3]).append("문제)");
            statWeak.setText(b.toString());
        }
        updateCounts();
    }

    private void askNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNoti();
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("목록에서 '서진이의 공부노트'를 찾아 허용을 켜 주세요");
            openOverlay();
        }
    }

    private void askNoti() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
        QuizService.sync(this);
    }

    private void openOverlay() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private void openBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
                toast("설정 > 배터리에서 직접 바꿔 주세요");
            }
        }
    }

    // ───────── 화면 조각 ─────────

    private int dp(float v) { return Ui.dp(this, v); }

    private static String num(int n) { return String.format(Locale.KOREA, "%,d", n); }

    private LinearLayout card(LinearLayout col) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Glass.card(this, dark, 24));
        c.setClipToOutline(true);
        col.addView(c, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return c;
    }

    /** 작은 제목 + 카드 */
    private LinearLayout section(LinearLayout col, String title) {
        TextView h = Ui.text(this, title, 13.5f, cSoft, false);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.setMargins(dp(6), dp(26), dp(6), dp(8));
        col.addView(h, hp);
        lastHead = h;
        return card(col);
    }

    private View divider(LinearLayout card) {
        View d = new View(this);
        d.setBackgroundColor(cRule);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(0.7f)));
        p.leftMargin = dp(16);
        p.rightMargin = dp(16);
        card.addView(d, p);
        return d;
    }

    private TextView label(String s) {
        TextView t = Ui.text(this, s, 13, cSoft, true);
        t.setPadding(dp(16), dp(14), dp(16), dp(4));
        return t;
    }

    private TextView sub(String s) {
        TextView t = Ui.text(this, s, 13.5f, cSoft, false);
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 13, cSoft, false);
        t.setLineSpacing(0, 1.25f);
        return t;
    }

    /** 제목(+설명) 왼쪽, 스위치 오른쪽. 줄 어디를 눌러도 켜고 꺼요. */
    private LinearLayout switchRow(LinearLayout card, View lead, String title, TextView subText, Toggle t) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(60));
        r.setPadding(dp(16), dp(12), dp(10), dp(12));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(Ui.text(this, title, 16, cInk, false));
        if (subText != null) {
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            sp.topMargin = dp(3);
            txt.addView(subText, sp);
        }
        r.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (lead != null) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) lead.getLayoutParams();
            lp.rightMargin = dp(12);
            r.addView(lead, 0, lp);
        }
        r.addView(t);
        t.setContentDescription(title);
        r.setForeground(ripple(false));
        r.setOnClickListener(v -> t.toggle());
        card.addView(r);
        return r;
    }

    /** 체크 상자 왼쪽, 글 오른쪽 */
    private void checkRow(LinearLayout parent, String title, Toggle t) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(48));
        r.setPadding(dp(6), 0, dp(16), 0);
        r.addView(t);
        TextView tt = Ui.text(this, title, 15.5f, cInk, false);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tp.leftMargin = dp(4);
        r.addView(tt, tp);
        t.setContentDescription(title);
        r.setForeground(ripple(false));
        r.setOnClickListener(v -> t.toggle());
        parent.addView(r);
    }

    private interface OnPick { void picked(int pos); }

    /** 가로로 붙은 고르기 단추 */
    private LinearLayout segmented(String[] names, int sel, OnPick cb) {
        LinearLayout g = new LinearLayout(this);
        g.setBackground(Ui.box(this, cTint, 0, 12));
        int p = dp(4);
        g.setPadding(p, p, p, p);
        final TextView[] items = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            TextView t = Ui.text(this, names[i], 15, cSoft, false);
            t.setGravity(Gravity.CENTER);
            t.setMinHeight(dp(40));
            t.setClickable(true);
            t.setFocusable(true);
            t.setOnClickListener(v -> { segStyle(items, k); cb.picked(k); });
            items[i] = t;
            g.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        }
        segStyle(items, sel);
        return g;
    }

    private void segStyle(TextView[] items, int sel) {
        for (int i = 0; i < items.length; i++) {
            boolean on = i == sel;
            items[i].setBackground(on ? Ui.box(this, cSeg, 0, 9) : null);
            items[i].setTextColor(on ? cInk : cSoft);
            items[i].setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            items[i].setSelected(on);
        }
    }

    private LinearLayout pairBox() {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(12), dp(10), dp(12), 0);
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
    }

    private TextView tilde() {
        TextView t = Ui.text(this, "~", 16, cSoft, false);
        t.setPadding(dp(10), 0, dp(10), 0);
        return t;
    }

    private Spinner spinner(List<String> items, int sel, OnPick cb) {
        Spinner sp = new Spinner(this, Spinner.MODE_DROPDOWN);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextColor(cInk);
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                t.setPadding(dp(14), dp(11), dp(10), dp(11));
                t.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_down, 0);
                t.setCompoundDrawableTintList(ColorStateList.valueOf(cSoft));
                return t;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(position, convertView, parent);
                t.setTextColor(cInk);
                t.setBackgroundColor(cCard);
                return t;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        sp.setBackground(Ui.box(this, cTint, 0, 12));
        sp.setPopupBackgroundDrawable(Ui.box(this, cCard, cRule, 12));
        sp.setSelection(Math.max(0, Math.min(items.size() - 1, sel)), false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { cb.picked(position); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        return sp;
    }

    /** 작은 둥근 단추 (허용하기, 확인 같은) */
    private TextView chip(String s) {
        TextView b = Ui.text(this, s, 14, cInk, true);
        b.setBackground(Ui.box(this, cTint, 0, 18));
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(36));
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setClickable(true);
        b.setFocusable(true);
        b.setForeground(ripple(false));
        return b;
    }

    private TextView button(String s, int fill, int ink) {
        TextView b = Ui.text(this, s, 15, ink, true);
        b.setBackground(Ui.box(this, fill, 0, 12));
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(48));
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setClickable(true);
        b.setFocusable(true);
        b.setForeground(ripple(false));
        return b;
    }

    private android.graphics.drawable.Drawable ripple(boolean borderless) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(borderless ? android.R.attr.selectableItemBackgroundBorderless
                : android.R.attr.selectableItemBackground, tv, true);
        return getDrawable(tv.resourceId);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
