package com.js.hanguksaquiz;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** 잠금화면 문제를 켜고, 필요한 권한을 하나씩 안내하는 화면 */
public class SettingsActivity extends Activity {

    private static final int[] INTERVALS = {0, 3, 10, 30};
    private static final String[] INTERVAL_NAMES = {"화면 켤 때마다", "3분에 한 번", "10분에 한 번", "30분에 한 번"};

    private Switch master;
    private TextView overlayState, batteryState, notiState, stats;
    private TextView overlayBtn, batteryBtn, notiBtn;
    private LinearLayout notiRow;
    private boolean binding;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.DESK);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 16);
        col.setPadding(pad, pad, pad, Ui.dp(this, 28));
        sv.addView(col);

        // 제목 줄
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = Ui.text(this, "←", 22, Ui.INK, true);
        back.setPadding(0, 0, Ui.dp(this, 14), 0);
        back.setOnClickListener(v -> finish());
        head.addView(back);
        head.addView(Ui.text(this, "잠금화면 문제 설정", 21, Ui.INK, true));
        col.addView(head);

        // 1. 켜기
        LinearLayout c1 = card(col);
        master = new Switch(this);
        master.setText("화면을 켤 때 한국사 문제 풀기");
        master.setTextSize(17);
        master.setTextColor(Ui.INK);
        master.setOnCheckedChangeListener((b, on) -> {
            if (binding) return;
            Quiz.setEnabled(this, on);
            if (on) askNeeded();
            QuizService.sync(this);
            refresh();
        });
        c1.addView(master);
        c1.addView(note("켜 두면 휴대폰 화면을 켤 때마다 잠금화면 위에 빈칸표 문제가 하나 나와요. 푼 다음 '닫기'를 누르면 원래 잠금화면으로 돌아가요."));

        // 2. 권한
        LinearLayout c2 = card(col);
        c2.addView(Ui.text(this, "꼭 필요한 설정", 16, Ui.INK, true));
        overlayState = Ui.text(this, "", 15, Ui.INK, false);
        overlayBtn = smallBtn("허용하러 가기");
        overlayBtn.setOnClickListener(v -> openOverlay());
        c2.addView(row("다른 앱 위에 표시 (필수)", overlayState, overlayBtn));
        batteryState = Ui.text(this, "", 15, Ui.INK, false);
        batteryBtn = smallBtn("설정하기");
        batteryBtn.setOnClickListener(v -> openBattery());
        c2.addView(row("배터리 최적화 제외 (권장)", batteryState, batteryBtn));
        notiState = Ui.text(this, "", 15, Ui.INK, false);
        notiBtn = smallBtn("허용하기");
        notiBtn.setOnClickListener(v -> askNoti());
        notiRow = row("알림 (실행 중 표시)", notiState, notiBtn);
        c2.addView(notiRow);
        c2.addView(note("삼성 갤럭시는 '설정 > 배터리 > 백그라운드 사용 제한 > 절전 예외 앱'에도 이 앱을 넣어 두면 문제가 끊기지 않아요."));

        // 3. 얼마나 자주
        LinearLayout c3 = card(col);
        c3.addView(Ui.text(this, "얼마나 자주", 16, Ui.INK, true));
        RadioGroup rg = new RadioGroup(this);
        int cur = Quiz.intervalMin(this);
        for (int i = 0; i < INTERVALS.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(View.generateViewId());
            rb.setText(INTERVAL_NAMES[i]);
            rb.setTextSize(16);
            rb.setTextColor(Ui.INK);
            final int m = INTERVALS[i];
            rg.addView(rb);
            if (m == cur) rb.setChecked(true);
            rb.setOnCheckedChangeListener((b, on) -> { if (on) Quiz.setIntervalMin(this, m); });
        }
        c3.addView(rg);

        // 4. 문제 종류
        LinearLayout c4 = card(col);
        c4.addView(Ui.text(this, "문제 종류", 16, Ui.INK, true));
        final SharedPreferences p = Quiz.prefs(this);
        final CheckBox when = check("사건 보고 시기 맞히기", p.getBoolean("t_when", true));
        final CheckBox what = check("시기 보고 사건 맞히기", p.getBoolean("t_what", true));
        final CheckBox world = check("세계사 줄도 내기", p.getBoolean("world", true));
        when.setOnCheckedChangeListener((b, on) -> {
            if (!on && !what.isChecked()) { b.setChecked(true); toast("둘 중 하나는 켜 둬야 해요"); return; }
            p.edit().putBoolean("t_when", on).apply();
        });
        what.setOnCheckedChangeListener((b, on) -> {
            if (!on && !when.isChecked()) { b.setChecked(true); toast("둘 중 하나는 켜 둬야 해요"); return; }
            p.edit().putBoolean("t_what", on).apply();
        });
        world.setOnCheckedChangeListener((b, on) -> p.edit().putBoolean("world", on).apply());
        c4.addView(when);
        c4.addView(what);
        c4.addView(world);

        // 5. 기록
        LinearLayout c5 = card(col);
        c5.addView(Ui.text(this, "내 기록", 16, Ui.INK, true));
        stats = Ui.text(this, "", 15, Ui.INK, false);
        stats.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        c5.addView(stats);
        LinearLayout btns = new LinearLayout(this);
        TextView tryBtn = smallBtn("지금 한 문제 풀기");
        tryBtn.setOnClickListener(v -> startActivity(new Intent(this, LockQuizActivity.class)));
        btns.addView(tryBtn);
        TextView reset = smallBtn("기록 지우기");
        reset.setOnClickListener(v -> { Quiz.resetStats(this); refresh(); toast("기록을 지웠어요"); });
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.leftMargin = Ui.dp(this, 8);
        btns.addView(reset, rp);
        c5.addView(btns);

        // 6. 앱 업데이트
        LinearLayout c6 = card(col);
        c6.addView(Ui.text(this, "앱 버전 " + BuildConfig.VERSION_NAME, 16, Ui.INK, true));
        if (BuildConfig.UPDATE_URL.length() > 0) {
            c6.addView(note("새 버전을 받아 설치하면 지금 앱 위에 덮어써지고, 푼 기록과 설정은 그대로 남아요."));
            TextView up = smallBtn("새 버전 받기");
            up.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.UPDATE_URL)));
                } catch (Exception e) {
                    toast("인터넷 브라우저를 열 수 없어요");
                }
            });
            LinearLayout.LayoutParams up2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            up2.topMargin = Ui.dp(this, 8);
            c6.addView(up, up2);
        }

        setContentView(sv);
        Ui.edgeToEdge(this, sv, true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        QuizService.sync(this);
    }

    private void refresh() {
        binding = true;
        master.setChecked(Quiz.enabled(this));
        binding = false;

        boolean overlay = Settings.canDrawOverlays(this);
        overlayState.setText(overlay ? "✓ 허용됨" : "⚠ 아직 안 됨");
        overlayState.setTextColor(overlay ? Ui.OK : Ui.PEN);
        overlayBtn.setVisibility(overlay ? View.GONE : View.VISIBLE);

        PowerManager pm = getSystemService(PowerManager.class);
        boolean battery = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        batteryState.setText(battery ? "✓ 제외됨" : "⚠ 최적화 중 (문제가 가끔 안 나올 수 있어요)");
        batteryState.setTextColor(battery ? Ui.OK : Ui.PEN);
        batteryBtn.setVisibility(battery ? View.GONE : View.VISIBLE);

        if (Build.VERSION.SDK_INT >= 33) {
            boolean noti = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            notiState.setText(noti ? "✓ 허용됨" : "⚠ 꺼짐 (알림 없이도 동작은 해요)");
            notiState.setTextColor(noti ? Ui.OK : Ui.INK_SOFT);
            notiBtn.setVisibility(noti ? View.GONE : View.VISIBLE);
        } else {
            notiRow.setVisibility(View.GONE);
        }

        int total = Quiz.total(this), ok = Quiz.correct(this);
        String s = "푼 문제 " + total + "개";
        if (total > 0) s += " · 정답률 " + Math.round(ok * 100f / total) + "%";
        s += "\n연속 정답 " + Quiz.streak(this) + " · 다시 나올 틀린 문제 " + Quiz.wrongCount(this) + "개";
        stats.setText(s);
    }

    private void askNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNoti();
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("목록에서 '한국사 잠금퀴즈'를 찾아 허용을 켜 주세요");
            openOverlay();
        }
    }

    private void askNoti() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
        QuizService.sync(this);
    }

    private void openOverlay() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private void openBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
                toast("설정 > 배터리에서 직접 바꿔 주세요");
            }
        }
    }

    // ───────── 화면 조각 ─────────

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.box(this, Ui.PAPER, Ui.RULE, 6));
        int p = Ui.dp(this, 14);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 12);
        parent.addView(c, lp);
        return c;
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 14, Ui.INK_SOFT, false);
        t.setLineSpacing(0, 1.2f);
        t.setPadding(0, Ui.dp(this, 6), 0, 0);
        return t;
    }

    private LinearLayout row(String title, TextView state, TextView btn) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 4));
        r.addView(Ui.text(this, title, 15, Ui.INK, false));
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.addView(state, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        line.addView(btn);
        r.addView(line);
        return r;
    }

    private TextView smallBtn(String s) {
        TextView b = Ui.button(this, s, Ui.TINT, Ui.RULE, Ui.INK);
        b.setTextSize(14);
        int h = Ui.dp(this, 12), v = Ui.dp(this, 8);
        b.setPadding(h, v, h, v);
        return b;
    }

    private CheckBox check(String s, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextSize(16);
        c.setTextColor(Ui.INK);
        c.setChecked(on);
        return c;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
