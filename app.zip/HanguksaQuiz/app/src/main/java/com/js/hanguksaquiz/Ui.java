package com.js.hanguksaquiz;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.TextView;

/** 화면 그리기를 돕는 작은 함수들 */
final class Ui {
    // 빈칸표 페이지와 같은 색
    static final int PAPER = 0xFFFFFFFF;
    static final int DESK = 0xFFE9E7E2;
    static final int INK = 0xFF151413;
    static final int INK_SOFT = 0xFF5F5A56;
    static final int RULE = 0xFFAAA5A0;
    static final int TINT = 0xFFF1EFEA;
    static final int PEN = 0xFFCC2119;
    static final int OK = 0xFF1E7A46;

    // 잠금화면(어두운 화면) 색
    static final int D_BG = 0xFF0E0F10;
    static final int D_CARD = 0xFF17181A;
    static final int D_INK = 0xFFEBE9E6;
    static final int D_SOFT = 0xFFA7A29C;
    static final int D_RULE = 0xFF4C4945;
    static final int D_PEN = 0xFFFF8A80;
    static final int D_OK = 0xFF7DD3A0;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    static GradientDrawable box(Context c, int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(dp(c, 1), stroke);
        return g;
    }

    /** 누를 수 있는 네모 버튼 (글자 대문자 변환 같은 기본 버튼 스타일 없이) */
    static TextView button(Context c, String s, int fill, int stroke, int ink) {
        TextView b = text(c, s, 16, ink, true);
        b.setBackground(box(c, fill, stroke, 6));
        int h = dp(c, 14), v = dp(c, 12);
        b.setPadding(h, v, h, v);
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    /** 상태바·내비게이션바 뒤까지 그리고, 그만큼 안쪽 여백을 줘요. */
    @SuppressWarnings("deprecation")
    static void edgeToEdge(Activity a, View root, boolean lightBars) {
        Window w = a.getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController ic = w.getInsetsController();
            if (ic != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                ic.setSystemBarsAppearance(lightBars ? mask : 0, mask);
            }
        } else {
            int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if (lightBars) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(f);
        }
        final int l = root.getPaddingLeft(), t = root.getPaddingTop(), r = root.getPaddingRight(), b = root.getPaddingBottom();
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int il, it, ir, ib;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets s = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                il = s.left; it = s.top; ir = s.right; ib = s.bottom;
            } else {
                il = insets.getSystemWindowInsetLeft();
                it = insets.getSystemWindowInsetTop();
                ir = insets.getSystemWindowInsetRight();
                ib = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l + il, t + it, r + ir, b + ib);
            return insets;
        });
        root.requestApplyInsets();
    }
}
