package com.js.hanguksaquiz;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * 공부 화면의 기록(localStorage) 사본을 앱 저장소 파일에 둬요.
 * 앱을 껐다 켰을 때 WebView 쪽 기록이 비어 있어도, 페이지가 이 사본으로 다시 채워요.
 */
final class WebStore {
    private static final Object LOCK = new Object();

    private WebStore() {}

    private static File file(Context c) { return new File(c.getFilesDir(), "webstore.json"); }

    private static long gen = 0;   // 이 앱이 켜진 동안 저장한 횟수

    /** 사본이 바뀌었는지 알아보는 값 (저장 횟수·바뀐 때·크기). 잠금화면이 외운 단어를 다시 셈할지 정할 때 써요 */
    static long stamp(Context c) {
        synchronized (LOCK) {
            File f = file(c);
            return gen * 1000003L + (f.exists() ? f.lastModified() * 31 + f.length() : 0);
        }
    }

    /** 저장해 둔 기록 (없으면 빈 글자) */
    static String read(Context c) {
        synchronized (LOCK) {
            File f = file(c);
            if (!f.exists()) return "";
            try (FileInputStream in = new FileInputStream(f)) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] b = new byte[16384];
                int n;
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            } catch (Exception e) {
                return "";
            }
        }
    }

    /** 기록 통째로 저장 (끝까지 써진 다음에 바꿔 넣어서, 쓰다 꺼져도 예전 기록은 남아요) */
    static void write(Context c, String json) {
        if (json == null || !json.startsWith("{")) return;
        synchronized (LOCK) {
            File f = file(c), tmp = new File(c.getFilesDir(), "webstore.json.part");
            try (FileOutputStream out = new FileOutputStream(tmp)) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
            } catch (Exception e) {
                tmp.delete();
                return;
            }
            if (!tmp.renameTo(f)) {
                f.delete();
                tmp.renameTo(f);
            }
            gen++;
        }
    }
}
