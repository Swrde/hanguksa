package com.js.hanguksaquiz;

import android.app.Activity;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import java.util.concurrent.Executor;

/**
 * '구글로 로그인' 창 (안드로이드 Credential Manager).
 * 구글이 준 ID 토큰을 Account가 Firebase 계정으로 바꿔요. 휴대폰에 등록된 구글 계정 중에서 골라요.
 */
final class GoogleLogin {
    private GoogleLogin() {}

    interface Cb {
        void ok(String idToken, String name, String mail);

        /** cancelled: 사람이 창을 닫았을 때 (그때는 아무 말도 안 해요) */
        void fail(String msg, boolean cancelled);
    }

    static void start(Activity a, Cb cb) {
        if (!Fb.googleReady()) {
            cb.fail("이 버전에는 구글 로그인 설정이 아직 없어요", false);
            return;
        }
        try {
            GetSignInWithGoogleOption opt = new GetSignInWithGoogleOption.Builder(Fb.WEB_CLIENT).build();
            GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
            CredentialManager cm = CredentialManager.create(a);
            final Handler h = new Handler(Looper.getMainLooper());
            Executor main = h::post;
            cm.getCredentialAsync(a, req, new CancellationSignal(), main,
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override
                        public void onResult(GetCredentialResponse r) {
                            handle(r, cb);
                        }

                        @Override
                        public void onError(GetCredentialException e) {
                            if (e instanceof GetCredentialCancellationException) {
                                cb.fail("", true);
                            } else if (e instanceof NoCredentialException) {
                                cb.fail("이 휴대폰에 구글 계정이 없어요. 휴대폰 설정에서 구글 계정을 먼저 추가해 주세요", false);
                            } else {
                                String m = String.valueOf(e.getMessage());
                                String hint = m.contains("28444") || m.toLowerCase(java.util.Locale.ROOT).contains("developer")
                                        ? " Firebase에 패키지 이름과 SHA-1을 넣었는지 확인해 주세요." : "";
                                cb.fail("구글 로그인이 안 됐어요." + hint, false);
                            }
                        }
                    });
        } catch (Throwable t) {
            cb.fail("구글 로그인 창을 열지 못했어요", false);
        }
    }

    private static void handle(GetCredentialResponse r, Cb cb) {
        Credential c = r.getCredential();
        if (c instanceof CustomCredential && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
            try {
                GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(((CustomCredential) c).getData());
                String name = g.getDisplayName(), mail = g.getId();
                cb.ok(g.getIdToken(), name == null ? "" : name, mail == null ? "" : mail);
            } catch (Exception e) {
                cb.fail("구글 로그인 정보를 읽지 못했어요", false);
            }
            return;
        }
        cb.fail("구글 계정 로그인 정보가 아니에요", false);
    }
}
