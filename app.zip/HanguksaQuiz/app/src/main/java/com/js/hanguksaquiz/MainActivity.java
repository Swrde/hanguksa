package com.js.hanguksaquiz;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;

/** 빈칸표·모의고사·암기 퀴즈 페이지를 인터넷 없이 여는 화면 (앱 안에 들어 있는 study.html) */
public class MainActivity extends Activity {

    private static final int REQ_FILE = 11;
    private static final String STUDY_URL = "file:///android_asset/study.html";
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    /**
     * 공부 화면 열기. 자동 업데이트로 받은 study.html이 있으면 그 내용을 직접 띄워요.
     * (file:///android_asset 주소는 shouldInterceptRequest를 거치지 않을 수 있어서, 받은 파일을 주소는 그대로 둔 채
     *  loadDataWithBaseURL로 넣어요. 주소가 같아서 모의고사 기록·교과서 그림 같은 저장된 내용도 그대로예요)
     */
    private void loadStudy() {
        if (ContentSync.hasLocal(this)) {
            try {
                String html = new String(ContentSync.readLocal(this), java.nio.charset.StandardCharsets.UTF_8);
                web.loadDataWithBaseURL(STUDY_URL, html, "text/html", "utf-8", STUDY_URL);
                return;
            } catch (Exception ignored) {
            }
        }
        web.loadUrl(STUDY_URL);
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.PAPER);

        // 위 막대: 잠금화면 문제 설정으로 가는 버튼
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int h = Ui.dp(this, 14);
        bar.setPadding(h, Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
        TextView title = Ui.text(this, "한국사2 공부", 16, Ui.INK, true);
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        TextView lock = Ui.button(this, "잠금화면 문제 ⚙", Ui.TINT, Ui.RULE, Ui.INK);
        lock.setTextSize(14);
        lock.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7));
        lock.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        bar.addView(lock);
        root.addView(bar);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);     // 페이지의 진행 기록(localStorage)·교과서 그림(IndexedDB) 저장
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            // 자동 업데이트로 받은 study.html이 있으면, 주소는 그대로 두고 내용만 새 파일로 바꿔서 보여 줘요
            // (주소가 같아야 모의고사 기록·교과서 그림 같은 저장된 내용이 그대로 남아요)
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (STUDY_URL.equals(request.getUrl().toString()) && ContentSync.hasLocal(MainActivity.this)) {
                    try {
                        return new WebResourceResponse("text/html", "utf-8",
                                new ByteArrayInputStream(ContentSync.readLocal(MainActivity.this)));
                    } catch (Exception ignored) {
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {
                    }
                    return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            // 교과서 탭의 '파일 고르기' 버튼이 휴대폰 파일 선택 창을 열게 해요
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent pick = params.createIntent();
                    pick.setType("*/*");
                    startActivityForResult(pick, REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);
        Ui.edgeToEdge(this, root, true);

        if (saved != null) web.restoreState(saved);
        if (web.getUrl() == null) loadStudy();

        // 저장소에 새 공부 내용이 올라왔는지 확인해서, 바뀌었으면 받아 와 바로 다시 열어요
        ContentSync.check(this, r -> {
            if (r == ContentSync.UPDATED && !isFinishing()) {
                web.clearCache(false);
                loadStudy();
                Toast.makeText(this, "공부 내용이 새로 바뀌었어요", Toast.LENGTH_SHORT).show();
            }
        });

        // 처음 열었을 때는 잠금화면 문제 설정부터 보여 줘요
        if (!Quiz.prefs(this).getBoolean("intro_done", false)) {
            Quiz.prefs(this).edit().putBoolean("intro_done", true).apply();
            startActivity(new Intent(this, SettingsActivity.class));
        }
        QuizService.sync(this);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
