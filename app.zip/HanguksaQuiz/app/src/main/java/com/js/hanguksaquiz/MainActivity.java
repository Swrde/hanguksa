package com.js.hanguksaquiz;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;

/** 빈칸표·모의고사·암기 퀴즈 페이지를 인터넷 없이 여는 화면 (앱 안에 들어 있는 study.html) */
public class MainActivity extends Activity {

    private static final int REQ_FILE = 11;
    private static final String STUDY_URL = "file:///android_asset/study.html";
    private WebView web;
    private LinearLayout bar;

    // 페이지가 쓰는 작은 다리: 새 페이지는 자기 홈 화면에 잠금화면 설정 버튼을 두므로 위 막대를 숨겨요.
    // (옛 페이지가 열리면 pageReady를 부르지 않으니 막대가 그대로 남아 설정으로 갈 수 있어요)
    public class AppBridge {
        @android.webkit.JavascriptInterface
        public void pageReady() {
            runOnUiThread(() -> { if (bar != null) bar.setVisibility(android.view.View.GONE); });
        }

        @android.webkit.JavascriptInterface
        public void openLockSettings() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, SettingsActivity.class)));
        }

        /** 공부 화면에서 고른 화면 모드(auto/light/dark)를 설정 창도 따라가게 저장해요 */
        @android.webkit.JavascriptInterface
        public void setTheme(String t) {
            if (!"light".equals(t) && !"dark".equals(t)) t = "auto";
            getSharedPreferences("ui", MODE_PRIVATE).edit().putString("theme", t).apply();
            // 상태바 글자색도 화면 모드에 맞춰요 (다크에서 검은 시계가 안 보이지 않게)
            runOnUiThread(() -> Ui.lightBars(MainActivity.this, !Glass.isDark(MainActivity.this)));
        }
    }
    private ValueCallback<Uri[]> fileCallback;

    /**
     * 공부 화면 열기. 자동 업데이트로 받은 study.html이 있으면 그 내용을 직접 띄워요.
     * (file:///android_asset 주소는 shouldInterceptRequest를 거치지 않을 수 있어서, 받은 파일을 주소는 그대로 둔 채
     *  loadDataWithBaseURL로 넣어요. 주소가 같아서 모의고사 기록·교과서 그림 같은 저장된 내용도 그대로예요)
     */
    private void loadStudy() {
        if (bar != null) bar.setVisibility(android.view.View.VISIBLE);   // 새 페이지면 곧 pageReady로 다시 숨어요
        if (ContentSync.hasLocal(this)) {
            try {
                String html = new String(ContentSync.readLocal(this), java.nio.charset.StandardCharsets.UTF_8);
                web.loadDataWithBaseURL(STUDY_URL, html, "text/html", "utf-8", STUDY_URL);
                return;
            } catch (Exception ignored) {
            }
        }
        web.loadUrl(STUDY_URL);
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        final boolean dark = Glass.isDark(this);
        final int bg = Glass.bg(dark);     // 홈 화면 바탕색과 같게 (열릴 때 흰 화면이 번쩍이지 않게)
        root.setBackgroundColor(bg);

        // 위 막대: 잠금화면 문제 설정으로 가는 버튼
        bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int h = Ui.dp(this, 14);
        bar.setPadding(h, Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
        TextView title = Ui.text(this, "서진이의 공부노트", 16, dark ? 0xFFFFFFFF : Ui.INK, true);
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        TextView lock = dark
                ? Ui.button(this, "잠금화면 문제", 0x1AFFFFFF, 0x1FFFFFFF, 0xFFFFFFFF)
                : Ui.button(this, "잠금화면 문제", 0xA6FFFFFF, 0x1F3C3C43, Ui.INK);
        lock.setBackground(Glass.panel(this, dark ? 0x3D767680 : 0x1F767680, 0, 999));
        lock.setTextSize(14);
        lock.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7));
        lock.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        bar.addView(lock);
        root.addView(bar);

        web = new WebView(this);
        web.setBackgroundColor(bg);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);     // 페이지의 진행 기록(localStorage)·교과서 그림(IndexedDB) 저장
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.addJavascriptInterface(new AppBridge(), "AppBridge");
        web.setWebViewClient(new WebViewClient() {
            // 자동 업데이트로 받은 study.html이 있으면, 주소는 그대로 두고 내용만 새 파일로 바꿔서 보여 줘요
            // (주소가 같아야 모의고사 기록·교과서 그림 같은 저장된 내용이 그대로 남아요)
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (STUDY_URL.equals(request.getUrl().toString()) && ContentSync.hasLocal(MainActivity.this)) {
                    try {
                        return new WebResourceResponse("text/html", "utf-8",
                                new ByteArrayInputStream(ContentSync.readLocal(MainActivity.this)));
                    } catch (Exception ignored) {
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {
                    }
                    return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            // 교과서 탭의 '파일 고르기' 버튼이 휴대폰 파일 선택 창을 열게 해요
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent pick = params.createIntent();
                    pick.setType("*/*");
                    startActivityForResult(pick, REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);
        Ui.edgeToEdge(this, root, !dark);

        loadStudy();

        // 저장소에 새 공부 내용이 올라왔는지 확인해서, 바뀌었으면 받아 와 바로 다시 열어요
        ContentSync.check(this, r -> {
            if (r == ContentSync.UPDATED && !isFinishing()) {
                web.clearCache(false);
                loadStudy();
                Toast.makeText(this, "공부 내용이 새로 바뀌었어요", Toast.LENGTH_SHORT).show();
            }
        });

        // 처음 열었을 때는 잠금화면 문제 설정부터 보여 줘요
        if (!Quiz.prefs(this).getBoolean("intro_done", false)) {
            Quiz.prefs(this).edit().putBoolean("intro_done", true).apply();
            startActivity(new Intent(this, SettingsActivity.class));
        }
        QuizService.sync(this);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        // 화면 상태(web.saveState)는 저장하지 않아요. 받은 공부 내용(2MB 넘음)을 통째로 넣게 돼서
        // 설정 화면으로 넘어갈 때 저장 한도(1MB)를 넘어 앱이 꺼졌어요. 푼 기록은 페이지가 따로 저장해요.
    }

    // 뒤로가기: 먼저 페이지에 물어봐요(열린 창 닫기 → 과목에서 홈으로).
    // 홈 화면이면 한 번 더 눌렀을 때 앱을 닫아요.
    private long lastBack = 0;

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript(
                "(function(){try{return !!(window.appBack&&window.appBack());}catch(e){return false;}})()",
                value -> {
                    if ("true".equals(value)) return;
                    long now = System.currentTimeMillis();
                    if (now - lastBack < 2000) {
                        finish();
                    } else {
                        lastBack = now;
                        Toast.makeText(this, "한 번 더 누르면 앱을 닫아요", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
