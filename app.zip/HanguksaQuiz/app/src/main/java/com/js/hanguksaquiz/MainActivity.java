package com.js.hanguksaquiz;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.util.List;

/** 빈칸표·모의고사·암기 퀴즈 페이지를 인터넷 없이 여는 화면 (앱 안에 들어 있는 study.html) */
public class MainActivity extends Activity implements Sync.Host {

    private static final int REQ_FILE = 11;
    private static final String STUDY_URL = "file:///android_asset/study.html";
    private WebView web;
    private LinearLayout bar;

    // 영어 발음 듣기: 처음 누를 때 안드로이드 음성 엔진을 켜고, 준비되면 기다리던 말을 읽어요
    private android.speech.tts.TextToSpeech tts;
    private boolean ttsReady;
    private String ttsPending;

    private void speakNow(String text) {
        if (tts == null) {
            ttsPending = text;
            tts = new android.speech.tts.TextToSpeech(getApplicationContext(), status -> {
                if (status != android.speech.tts.TextToSpeech.SUCCESS || tts == null) return;
                tts.setLanguage(java.util.Locale.US);
                tts.setSpeechRate(0.9f);
                ttsReady = true;
                if (ttsPending != null) { tts.speak(ttsPending, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "say"); ttsPending = null; }
            });
            return;
        }
        if (!ttsReady) { ttsPending = text; return; }
        tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "say");
    }

    // 페이지가 쓰는 작은 다리: 새 페이지는 자기 홈 화면에 잠금화면 설정 버튼을 두므로 위 막대를 숨겨요.
    // (옛 페이지가 열리면 pageReady를 부르지 않으니 막대가 그대로 남아 설정으로 갈 수 있어요)
    public class AppBridge {
        /** 영어 낱말·예문 읽어 주기 */
        @android.webkit.JavascriptInterface
        public void speak(String text) {
            if (text == null) return;
            String t = text.length() > 300 ? text.substring(0, 300) : text;
            runOnUiThread(() -> speakNow(t));
        }

        @android.webkit.JavascriptInterface
        public void pageReady() {
            runOnUiThread(() -> { if (bar != null) bar.setVisibility(android.view.View.GONE); });
        }

        @android.webkit.JavascriptInterface
        public void openLockSettings() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, SettingsActivity.class)));
        }

        /** 공부 화면에서 고른 화면 모드(auto/light/dark)를 설정 창도 따라가게 저장해요 */
        @android.webkit.JavascriptInterface
        public void setTheme(String t) {
            if (!"light".equals(t) && !"dark".equals(t)) t = "auto";
            getSharedPreferences("ui", MODE_PRIVATE).edit().putString("theme", t).apply();
            // 상태바 글자색도 화면 모드에 맞춰요 (다크에서 검은 시계가 안 보이지 않게)
            runOnUiThread(() -> Ui.lightBars(MainActivity.this, !Glass.isDark(MainActivity.this)));
        }

        /** 공부 기록(푼 문제·진행 상황) 사본 읽기: 페이지가 열릴 때 비어 있는 기록을 다시 채워요 */
        @android.webkit.JavascriptInterface
        public String storeGet() {
            return WebStore.read(getApplicationContext());
        }

        /** 공부 기록 사본 저장: 앱을 껐다 켜도 진행 상황이 남게 앱 저장소에도 둬요 */
        @android.webkit.JavascriptInterface
        public void storeSet(String json) {
            WebStore.write(getApplicationContext(), json);
        }

        /** 잠금화면에서 푼 영어 낱말 기록 가져가기: 단어장의 외운 단어·오답 노트에 합쳐요 (가져가면 비워요) */
        @android.webkit.JavascriptInterface
        public String takeEnEvents() {
            return Quiz.takeEnEvents(getApplicationContext());
        }

        /** 홈의 '계정' 버튼 */
        @android.webkit.JavascriptInterface
        public void openAccount() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, AccountActivity.class)));
        }

        /** 홈의 계정 칸에 쓸 글: {"on": 로그인했는지, "t": 제목, "s": 작은 글} */
        @android.webkit.JavascriptInterface
        public String accountLine() {
            android.content.Context c = getApplicationContext();
            java.util.Map<String, Object> m = new java.util.LinkedHashMap<>();
            boolean on = Account.loggedIn(c);
            m.put("on", on);
            m.put("t", on ? Account.label(c) : "계정");
            m.put("s", Sync.status(c));
            return Json.str(m);
        }

        /** 오답 노트: 잠금화면에서 틀린 문제를 문제 모양 그대로 (과목 s: ks/sa/en) */
        @android.webkit.JavascriptInterface
        public String lockWrongItems() {
            android.content.Context c = getApplicationContext();
            java.util.Random rnd = new java.util.Random();
            java.util.List<Object> out = new java.util.ArrayList<>();
            java.util.List<String> keys = new java.util.ArrayList<>(Quiz.prefs(c).getStringSet("wrong", new java.util.HashSet<String>()));
            java.util.Collections.sort(keys);
            java.util.Map<String, int[]> rv = Quiz.reviews(Quiz.prefs(c));
            int today = Quiz.today();
            for (String k : keys) {
                if (out.size() >= 400) break;
                Quiz.Question q = Quiz.byKey(c, k, rnd);
                if (q == null) continue;
                java.util.Map<String, Object> m = new java.util.LinkedHashMap<>();
                m.put("k", k);
                m.put("s", k.startsWith("s:") ? "sa" : k.startsWith("e:") ? "en" : "ks");
                m.put("g", q.tag == null ? "" : q.tag);
                m.put("p", q.prompt == null ? "" : q.prompt);
                m.put("a", q.ask == null ? "" : q.ask);
                m.put("l", q.lines);
                m.put("o", q.options);
                m.put("r", q.answer);
                m.put("x", q.explain == null ? "" : q.explain);
                m.put("u", q.unit.isEmpty() ? "" : Quiz.unitName(c, q.unit));
                int[] e = rv.get(k);
                m.put("d", e != null && e[1] <= today);   // 오늘 복습할 문제
                out.add(m);
            }
            return Json.str(out);
        }

        /** 홈의 오답 노트 칸: 잠금화면에서 틀린 문제 수 (문제를 만들지 않아 빨라요) */
        @android.webkit.JavascriptInterface
        public int lockWrongCount() {
            return Quiz.wrongCount(getApplicationContext());
        }

        /** 오답 노트에서 다시 푼 결과 (잠금화면에서 푼 것과 똑같이 기록돼요) */
        @android.webkit.JavascriptInterface
        public void lockAnswer(String key, boolean ok) {
            Quiz.record(getApplicationContext(), key, ok);
            Sync.soon(getApplicationContext(), 60000);
        }

        /** 단원별 정답률 (잠금화면): [{"s": 과목, "u": 단원 이름, "o": 맞힘, "n": 푼 수}] */
        @android.webkit.JavascriptInterface
        public String unitStats() {
            android.content.Context c = getApplicationContext();
            java.util.List<Object> out = new java.util.ArrayList<>();
            for (java.util.Map.Entry<String, Object> e : Quiz.unitStats(c).entrySet()) {
                java.util.Map<String, Object> st = Json.obj(e.getValue());
                java.util.Map<String, Object> m = new java.util.LinkedHashMap<>();
                String u = e.getKey();
                m.put("s", u.startsWith("sa:") ? "sa" : u.startsWith("en:") ? "en" : "ks");
                m.put("u", Quiz.unitName(c, u));
                m.put("o", Json.l(st, "o"));
                m.put("n", Json.l(st, "n"));
                out.add(m);
            }
            return Json.str(out);
        }

        /** 복습: {"due": 오늘 복습할 수, "all": 복습 중인 수} */
        @android.webkit.JavascriptInterface
        public String reviewInfo() {
            int[] r = Quiz.reviewCounts(getApplicationContext());
            return "{\"due\":" + r[0] + ",\"all\":" + r[1] + "}";
        }

        /** 동기화용 빈 화면이 다 열렸어요 (공부 화면이 들고 있던 기록은 이미 저장됨) */
        @android.webkit.JavascriptInterface
        public void prepReady() {
            Runnable r = prepReady;
            prepReady = null;
            if (r != null) r.run();
        }
    }

    // ───────── 동기화 (Sync.Host) ─────────
    // 다른 기기 기록을 넣을 때는, 공부 화면이 들고 있던 기록이 나중에 덮어쓰지 않게 화면을 잠깐 빈 화면으로 바꾼 뒤 넣고 다시 열어요.
    private volatile Runnable prepReady;
    private boolean syncHold;          // 동기화가 화면을 비운 동안엔 다른 곳에서 공부 화면을 다시 열지 않아요
    private final Runnable acctPaint = () -> {
        if (web != null) web.evaluateJavascript("(function(){try{window.__acctPaint&&window.__acctPaint();}catch(e){}})()", null);
    };

    /** 공부 화면과 주소가 같은 빈 화면 (그래서 같은 저장소를 써요). 바탕색만 칠하고, 열리면 앱에 알려요 */
    private String prepHtml() {
        int bg = Glass.bg(Glass.isDark(this)) & 0xFFFFFF;
        return "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width\"></head>"
                + "<body style=\"margin:0;background:#" + String.format("%06x", bg) + "\">"
                + "<script>try{AppBridge.prepReady();}catch(e){}</script></body></html>";
    }

    private static String deleteJs(List<String> keys) {
        return "(function(d){for(var i=0;i<d.length;i++){try{localStorage.removeItem(d[i]);}catch(e){}}})(" + Json.str(keys) + ")";
    }

    @Override
    public void unloadPage(Runnable ready) {
        runOnUiThread(() -> {
            if (web == null || isFinishing()) { ready.run(); return; }
            syncHold = true;
            prepReady = ready;
            web.loadDataWithBaseURL(STUDY_URL, prepHtml(), "text/html", "utf-8", null);
        });
    }

    @Override
    public void reloadPage(List<String> deleted, boolean fromOther) {
        runOnUiThread(() -> {
            syncHold = false;
            if (web == null || isFinishing()) return;
            web.evaluateJavascript(deleteJs(deleted), v -> {
                loadStudyNow();
                if (fromOther) Toast.makeText(this, "다른 기기에서 공부한 기록을 받아 왔어요", Toast.LENGTH_SHORT).show();
            });
        });
    }
    private ValueCallback<Uri[]> fileCallback;

    /**
     * 공부 화면 열기. 자동 업데이트로 받은 study.html이 있으면 그 내용을 직접 띄워요.
     * (file:///android_asset 주소는 shouldInterceptRequest를 거치지 않을 수 있어서, 받은 파일을 주소는 그대로 둔 채
     *  loadDataWithBaseURL로 넣어요. 주소가 같아서 모의고사 기록·교과서 그림 같은 저장된 내용도 그대로예요)
     */
    private void loadStudy() {
        if (syncHold) return;     // 동기화가 곧 다시 열어요
        // 공부 화면이 닫혀 있을 때 다른 기기에서 지운 기록이 있으면, WebView 저장소에서도 지운 다음 열어요
        final List<String> del = Sync.takePendingDeletes(this);
        if (!del.isEmpty()) {
            prepReady = () -> runOnUiThread(() -> { if (web != null) web.evaluateJavascript(deleteJs(del), v -> loadStudyNow()); });
            web.loadDataWithBaseURL(STUDY_URL, prepHtml(), "text/html", "utf-8", null);
            return;
        }
        loadStudyNow();
    }

    private void loadStudyNow() {
        if (web == null) return;
        if (bar != null) bar.setVisibility(android.view.View.VISIBLE);   // 새 페이지면 곧 pageReady로 다시 숨어요
        if (ContentSync.hasLocal(this)) {
            try {
                String html = new String(ContentSync.readLocal(this), java.nio.charset.StandardCharsets.UTF_8);
                web.loadDataWithBaseURL(STUDY_URL, html, "text/html", "utf-8", STUDY_URL);
                return;
            } catch (Exception ignored) {
            }
        }
        web.loadUrl(STUDY_URL);
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        final boolean dark = Glass.isDark(this);
        final int bg = Glass.bg(dark);     // 홈 화면 바탕색과 같게 (열릴 때 흰 화면이 번쩍이지 않게)
        root.setBackgroundColor(bg);

        // 위 막대: 잠금화면 문제 설정으로 가는 버튼
        bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int h = Ui.dp(this, 14);
        bar.setPadding(h, Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
        TextView title = Ui.text(this, "서진이의 공부노트", 16, dark ? 0xFFFFFFFF : Ui.INK, true);
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        TextView lock = dark
                ? Ui.button(this, "잠금화면 문제", 0x1AFFFFFF, 0x1FFFFFFF, 0xFFFFFFFF)
                : Ui.button(this, "잠금화면 문제", 0xA6FFFFFF, 0x1F3C3C43, Ui.INK);
        lock.setBackground(Glass.panel(this, dark ? 0x3D767680 : 0x1F767680, 0, 999));
        lock.setTextSize(14);
        lock.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7));
        lock.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        bar.addView(lock);
        root.addView(bar);

        web = new WebView(this);
        web.setBackgroundColor(bg);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);     // 페이지의 진행 기록(localStorage)·교과서 그림(IndexedDB) 저장
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.addJavascriptInterface(new AppBridge(), "AppBridge");
        web.setWebViewClient(new WebViewClient() {
            // 자동 업데이트로 받은 study.html이 있으면, 주소는 그대로 두고 내용만 새 파일로 바꿔서 보여 줘요
            // (주소가 같아야 모의고사 기록·교과서 그림 같은 저장된 내용이 그대로 남아요)
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (STUDY_URL.equals(request.getUrl().toString()) && ContentSync.hasLocal(MainActivity.this)) {
                    try {
                        return new WebResourceResponse("text/html", "utf-8",
                                new ByteArrayInputStream(ContentSync.readLocal(MainActivity.this)));
                    } catch (Exception ignored) {
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {
                    }
                    return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            // 교과서 탭의 '파일 고르기' 버튼이 휴대폰 파일 선택 창을 열게 해요
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent pick = params.createIntent();
                    pick.setType("*/*");
                    startActivityForResult(pick, REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);
        Ui.edgeToEdge(this, root, !dark);

        Sync.setHost(this);       // 화면을 열기 전에: 그사이 동기화가 사본 파일을 바로 고치지 않게
        loadStudy();
        Sync.listen(acctPaint);
        Sync.soon(this, 1500);    // 로그인돼 있으면 열자마자 다른 기기 기록을 맞춰요

        // 저장소에 새 공부 내용이 올라왔는지 확인해서, 바뀌었으면 받아 와 바로 다시 열어요
        ContentSync.check(this, r -> {
            if (r == ContentSync.UPDATED && !isFinishing()) {
                web.clearCache(false);
                loadStudy();
                Toast.makeText(this, "공부 내용이 새로 바뀌었어요", Toast.LENGTH_SHORT).show();
            }
        });

        // 처음 열었을 때는 잠금화면 문제 설정부터 보여 줘요
        if (!Quiz.prefs(this).getBoolean("intro_done", false)) {
            Quiz.prefs(this).edit().putBoolean("intro_done", true).apply();
            startActivity(new Intent(this, SettingsActivity.class));
        }
        QuizService.sync(this);

        // 새 앱 버전이 나왔으면 물어보고 앱 안에서 바로 업데이트해요 (6시간에 한 번 확인)
        AppUpdate.autoCheck(this);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        // 화면 상태(web.saveState)는 저장하지 않아요. 받은 공부 내용(2MB 넘음)을 통째로 넣게 돼서
        // 설정 화면으로 넘어갈 때 저장 한도(1MB)를 넘어 앱이 꺼졌어요. 푼 기록은 페이지가 따로 저장해요.
    }

    // 뒤로가기: 먼저 페이지에 물어봐요(열린 창 닫기 → 과목에서 홈으로).
    // 홈 화면이면 한 번 더 눌렀을 때 앱을 닫아요.
    private long lastBack = 0;

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript(
                "(function(){try{return !!(window.appBack&&window.appBack());}catch(e){return false;}})()",
                value -> {
                    if ("true".equals(value)) return;
                    long now = System.currentTimeMillis();
                    if (now - lastBack < 2000) {
                        finish();
                    } else {
                        lastBack = now;
                        Toast.makeText(this, "한 번 더 누르면 앱을 닫아요", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 잠금화면에서 풀고 돌아오면, 그동안 푼 영어 낱말을 단어장에 바로 합쳐요
        if (web != null) {
            web.evaluateJavascript("(function(){try{window.__enSync&&window.__enSync();}catch(e){}})()", null);
        }
        acctPaint.run();
        Sync.soonIfStale(this, 800, 20000);   // 다른 기기를 쓰다 왔을 수 있으니 (20초 안에 했으면 건너뛰어요)
    }

    @Override
    protected void onPause() {
        // 화면을 떠날 때(홈 버튼, 앱 전환, 잠금) 공부 기록을 바로 앱 저장소에 남겨요
        if (web != null) {
            web.evaluateJavascript("(function(){try{window.__appSave&&window.__appSave();}catch(e){}})()", null);
        }
        Sync.soon(this, 2000);    // 저장이 끝난 뒤에 올려요
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        Sync.unlisten(acctPaint);
        Sync.clearHost(this);
        if (tts != null) { tts.shutdown(); tts = null; }
        if (web != null) web.destroy();
        web = null;
        super.onDestroy();
    }
}
